import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const defaultPort = isProduction ? parseInt(process.env.PORT || '3000', 10) : 3000;

// Load Firebase configuration for server-side token validation and Firestore persistence
let firebaseConfig: {
  apiKey?: string;
  projectId?: string;
  firestoreDatabaseId?: string;
} = {};
try {
  const rawConfig = fs.readFileSync(path.resolve(__dirname, 'firebase-config.json'), 'utf8');
  firebaseConfig = JSON.parse(rawConfig);
} catch (e) {
  console.warn('[CoinEdu Server] Warning: Could not read firebase-config.json', e);
}

// 1. Designated Primary Owner (Retains full ownership and staff management permissions)
export const PRIMARY_ADMIN_EMAIL = 'rakshiths056@gmail.com';

// 2. Persistent Additional Administrator(s) (Survives Render/Cloud Run restarts & redeployments)
export interface AuthorizedStaffRecord {
  uid: string;
  email: string;
  name: string;
  role: 'admin';
  isPrimaryOwner: false;
  addedBy: string;
  addedAt: string;
}

export const BUILTIN_ADDITIONAL_ADMINS: AuthorizedStaffRecord[] = [
  {
    uid: 'liDG3eSTJuS8eTxin2JWt6SpqvD2',
    email: 'jeffery158540@gmail.com',
    name: 'Additional Administrator',
    role: 'admin',
    isPrimaryOwner: false,
    addedBy: PRIMARY_ADMIN_EMAIL,
    addedAt: '2026-10-26T00:00:00.000Z',
  },
];

const PERSISTENT_STAFF_FILE = path.resolve(__dirname, 'authorized-admins.json');

interface PersistedAdminState {
  staff: Record<string, AuthorizedStaffRecord>;
  revokedUids: string[];
}

// Map of authorized additional administrators (UID -> Record) and set of explicitly revoked UIDs
const authorizedStaffMap = new Map<string, AuthorizedStaffRecord>();
const revokedStaffUids = new Set<string>();

function loadPersistedAdminState(): void {
  // Always seed built-in additional administrators first
  for (const admin of BUILTIN_ADDITIONAL_ADMINS) {
    authorizedStaffMap.set(admin.uid, { ...admin });
  }

  try {
    if (fs.existsSync(PERSISTENT_STAFF_FILE)) {
      const raw = fs.readFileSync(PERSISTENT_STAFF_FILE, 'utf8');
      const parsed = JSON.parse(raw) as Partial<PersistedAdminState>;
      if (Array.isArray(parsed.revokedUids)) {
        for (const uid of parsed.revokedUids) {
          revokedStaffUids.add(uid);
          authorizedStaffMap.delete(uid);
        }
      }
      if (parsed.staff && typeof parsed.staff === 'object') {
        for (const [uid, record] of Object.entries(parsed.staff)) {
          if (!revokedStaffUids.has(uid) && record && typeof record.uid === 'string') {
            authorizedStaffMap.set(uid, record);
          }
        }
      }
    }
  } catch (err) {
    console.warn('[CoinEdu Server] Could not read authorized-admins.json, using default baseline:', err);
  }
}

function savePersistedAdminState(): void {
  try {
    const state: PersistedAdminState = {
      staff: Object.fromEntries(authorizedStaffMap.entries()),
      revokedUids: Array.from(revokedStaffUids),
    };
    fs.writeFileSync(PERSISTENT_STAFF_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch (err) {
    console.warn('[CoinEdu Server] Could not write authorized-admins.json:', err);
  }
}

loadPersistedAdminState();

// Sync additional admin record to Firestore /admins/{uid} using the Primary Owner's Firebase ID token
async function upsertAdminInFirestore(idToken: string, record: AuthorizedStaffRecord): Promise<void> {
  if (!firebaseConfig.projectId) return;
  const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
  const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${dbId}/documents/admins/${encodeURIComponent(record.uid)}`;
  try {
    await fetch(url, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${idToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fields: {
          userId: { stringValue: record.uid },
          email: { stringValue: record.email || '' },
          role: { stringValue: 'admin' },
          createdAt: { stringValue: record.addedAt },
        },
      }),
    });
  } catch (err) {
    console.warn('[CoinEdu Server] Could not sync admin record to Firestore:', err);
  }
}

async function deleteAdminFromFirestore(idToken: string, staffUid: string): Promise<void> {
  if (!firebaseConfig.projectId) return;
  const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
  const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${dbId}/documents/admins/${encodeURIComponent(staffUid)}`;
  try {
    await fetch(url, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${idToken}`,
      },
    });
  } catch (err) {
    console.warn('[CoinEdu Server] Could not delete admin record from Firestore:', err);
  }
}

export function checkAdminAuthorization(user: {
  localId: string;
  email: string;
  emailVerified: boolean;
}): {
  authorized: boolean;
  isPrimaryOwner: boolean;
  adminTier: 'primary_owner' | 'additional_admin' | 'none';
} {
  const normalizedEmail = (user.email || '').toLowerCase().trim();

  // 1. Primary Owner check (rakshiths056@gmail.com)
  if (normalizedEmail === PRIMARY_ADMIN_EMAIL && user.emailVerified) {
    return {
      authorized: true,
      isPrimaryOwner: true,
      adminTier: 'primary_owner',
    };
  }

  // 2. Additional Administrator check (by UID or verified email, unless revoked by Primary Owner)
  if (revokedStaffUids.has(user.localId)) {
    return {
      authorized: false,
      isPrimaryOwner: false,
      adminTier: 'none',
    };
  }

  const matchedByUid = authorizedStaffMap.get(user.localId);
  if (matchedByUid) {
    return {
      authorized: true,
      isPrimaryOwner: false,
      adminTier: 'additional_admin',
    };
  }

  if (user.emailVerified && normalizedEmail) {
    for (const staff of authorizedStaffMap.values()) {
      if (staff.email && staff.email.toLowerCase().trim() === normalizedEmail && !revokedStaffUids.has(staff.uid)) {
        return {
          authorized: true,
          isPrimaryOwner: false,
          adminTier: 'additional_admin',
        };
      }
    }
  }

  return {
    authorized: false,
    isPrimaryOwner: false,
    adminTier: 'none',
  };
}

interface VerifiedFirebaseUser {
  localId: string;
  email: string;
  emailVerified: boolean;
  displayName?: string;
}

// Verify Firebase ID Token via Google Identity Toolkit
async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedFirebaseUser | null> {
  if (!idToken || !firebaseConfig.apiKey) {
    return null;
  }
  try {
    const response = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${firebaseConfig.apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      }
    );

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    if (!data.users || data.users.length === 0) {
      return null;
    }

    const user = data.users[0];
    return {
      localId: user.localId,
      email: (user.email || '').toLowerCase().trim(),
      emailVerified: Boolean(user.emailVerified),
      displayName: user.displayName,
    };
  } catch (error) {
    console.error('[CoinEdu Server] Error verifying Firebase token with Google Identity Toolkit:', error);
    return null;
  }
}

async function startServer() {
  const app = express();

  // Basic middleware
  app.use(express.json());

  // Security headers middleware
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    next();
  });

  // Health check endpoint for Cloud Run / Render
  app.get('/api/health', (req, res) => {
    res.status(200).json({
      status: 'ok',
      service: 'coinedu',
      app: 'CoinEdu Platform',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      uptime: Math.floor(process.uptime()),
      environment: process.env.NODE_ENV || 'development',
    });
  });

  // Server-Side Strict Admin Role Verification
  // Supports both Primary Owner (rakshiths056@gmail.com) and Additional Administrator (jeffery158540@gmail.com / liDG3eSTJuS8eTxin2JWt6SpqvD2)
  app.post('/api/admin/verify', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ authorized: false, error: 'Unauthorized: No token provided' });
    }

    const token = authHeader.split(' ')[1];
    const verifiedUser = await verifyFirebaseIdToken(token);

    if (!verifiedUser) {
      return res.status(401).json({
        authorized: false,
        error: 'Invalid or expired Firebase authentication token',
      });
    }

    const authResult = checkAdminAuthorization(verifiedUser);

    if (!authResult.authorized) {
      return res.status(403).json({
        authorized: false,
        error: 'Forbidden: You do not have administrator permissions for CoinEdu',
      });
    }

    // If Primary Owner signs in, ensure built-in additional admins are also synced to Firestore /admins
    if (authResult.isPrimaryOwner) {
      for (const staff of authorizedStaffMap.values()) {
        upsertAdminInFirestore(token, staff).catch(() => null);
      }
    }

    return res.status(200).json({
      authorized: true,
      user: {
        id: verifiedUser.localId,
        email: verifiedUser.email,
        name: verifiedUser.displayName || 'Administrator',
        role: 'admin',
        isPrimaryOwner: authResult.isPrimaryOwner,
        adminTier: authResult.adminTier,
      },
    });
  });

  // Trusted Server-Side Admin Staff Management API
  // Readable by any authorized administrator; mutations (grant/revoke) strictly restricted to Primary Owner only
  app.get('/api/admin/staff', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const token = authHeader.split(' ')[1];
    const verifiedUser = await verifyFirebaseIdToken(token);

    if (!verifiedUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const authResult = checkAdminAuthorization(verifiedUser);
    if (!authResult.authorized) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const staffRecords = Array.from(authorizedStaffMap.values());

    return res.status(200).json({
      primaryOwner: PRIMARY_ADMIN_EMAIL,
      staffCount: staffRecords.length,
      staffUids: staffRecords.map((s) => s.uid),
      staffRecords,
    });
  });

  app.post('/api/admin/staff/grant', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const token = authHeader.split(' ')[1];
    const verifiedUser = await verifyFirebaseIdToken(token);

    // STRICT GUARD: Only the designated primary owner can grant admin staff privileges
    if (!verifiedUser || verifiedUser.email !== PRIMARY_ADMIN_EMAIL || !verifiedUser.emailVerified) {
      return res.status(403).json({
        error: 'Only the primary owner (rakshiths056@gmail.com) may grant administrator privileges',
      });
    }

    const { staffUid, staffEmail, staffName } = req.body;
    if (!staffUid || typeof staffUid !== 'string' || staffUid.trim().length === 0 || staffUid.length > 128) {
      return res.status(400).json({ error: 'A valid Firebase UID is required' });
    }

    const trimmedUid = staffUid.trim();
    const trimmedEmail =
      typeof staffEmail === 'string' && staffEmail.trim()
        ? staffEmail.toLowerCase().trim()
        : BUILTIN_ADDITIONAL_ADMINS.find((a) => a.uid === trimmedUid)?.email || '';

    const record: AuthorizedStaffRecord = {
      uid: trimmedUid,
      email: trimmedEmail,
      name:
        typeof staffName === 'string' && staffName.trim()
          ? staffName.trim()
          : 'Additional Administrator',
      role: 'admin',
      isPrimaryOwner: false,
      addedBy: PRIMARY_ADMIN_EMAIL,
      addedAt: new Date().toISOString(),
    };

    revokedStaffUids.delete(trimmedUid);
    authorizedStaffMap.set(trimmedUid, record);
    savePersistedAdminState();
    await upsertAdminInFirestore(token, record);

    return res.status(200).json({
      success: true,
      message: `Admin privileges granted to ${trimmedEmail ? `${trimmedEmail} (${trimmedUid})` : `UID ${trimmedUid}`}`,
      staffCount: authorizedStaffMap.size,
      staffRecords: Array.from(authorizedStaffMap.values()),
    });
  });

  app.post('/api/admin/staff/revoke', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const token = authHeader.split(' ')[1];
    const verifiedUser = await verifyFirebaseIdToken(token);

    // STRICT GUARD: Only the designated primary owner can revoke admin staff privileges
    if (!verifiedUser || verifiedUser.email !== PRIMARY_ADMIN_EMAIL || !verifiedUser.emailVerified) {
      return res.status(403).json({
        error: 'Only the primary owner (rakshiths056@gmail.com) may revoke administrator privileges',
      });
    }

    const { staffUid } = req.body;
    if (!staffUid || typeof staffUid !== 'string') {
      return res.status(400).json({ error: 'Staff UID is required' });
    }

    const trimmedUid = staffUid.trim();

    // Prevent revoking or demoting the primary owner
    if (
      trimmedUid === verifiedUser.localId ||
      trimmedUid.toLowerCase() === PRIMARY_ADMIN_EMAIL
    ) {
      return res.status(400).json({
        error: 'Cannot revoke or demote the primary owner account',
      });
    }

    authorizedStaffMap.delete(trimmedUid);
    revokedStaffUids.add(trimmedUid);
    savePersistedAdminState();
    await deleteAdminFromFirestore(token, trimmedUid);

    return res.status(200).json({
      success: true,
      message: `Admin privileges revoked for UID ${trimmedUid}`,
      staffCount: authorizedStaffMap.size,
      staffRecords: Array.from(authorizedStaffMap.values()),
    });
  });

  if (!isProduction) {
    // Development mode with Vite dev middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: defaultPort,
      },
      appType: 'spa',
    });

    app.use(vite.middlewares);
  } else {
    // Production mode: Serve built static files from dist
    const distPath = path.resolve(__dirname, 'dist');
    app.use(
      express.static(distPath, {
        maxAge: '1h',
        index: false,
      })
    );

    // Client-side routing fallback: serve index.html for all non-API GET requests
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(defaultPort, '0.0.0.0', () => {
    console.log(
      `[CoinEdu Server] Running in ${isProduction ? 'production' : 'development'} mode on port ${defaultPort}`
    );
  });

  server.on('error', (err: NodeJS.ErrnoException) => {
    if (err.code === 'EADDRINUSE' && defaultPort !== 3000) {
      console.warn(`[CoinEdu Server] Port ${defaultPort} is in use, falling back to port 3000...`);
      app.listen(3000, '0.0.0.0', () => {
        console.log(`[CoinEdu Server] Running on fallback port 3000`);
      });
    } else {
      console.error('[CoinEdu Server] Server listen error:', err);
      process.exit(1);
    }
  });
}

if (process.env.COINEDU_SKIP_SERVER_START !== 'true') {
  startServer().catch((err) => {
    console.error('[CoinEdu Server] Fatal startup error:', err);
    process.exit(1);
  });
}
