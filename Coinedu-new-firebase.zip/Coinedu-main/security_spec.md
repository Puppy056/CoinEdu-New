# Security Specification for CoinEdu Firestore Database

## 1. Data Invariants
1. Default Deny: All access to unmapped collections or paths is strictly forbidden.
2. Educational Content (Courses, Lessons, Quizzes, Flashcards, LiveClasses, Glossary, Notifications):
   - Only verified administrators (`isAdmin()`) can create, update, or delete educational content.
   - Public and authenticated students can only read educational content if `published == true`.
   - Administrators can read both draft (`published == false`) and published records.
3. User Profiles (`users/{userId}`):
   - A user can read and write their own profile (`request.auth.uid == userId`).
   - A student cannot escalate their own role from `'student'` to `'admin'`.
   - Secondary administrators cannot delete, demote, or modify the Primary Owner's profile (`rakshiths056@gmail.com`) or grant `'admin'` role to other users.
4. User Quiz Attempts (`users/{userId}/quizAttempts/{attemptId}`):
   - A user can only view their own quiz attempts under their own `userId` path.
   - `attemptId` must match safe alphanumeric pattern.
5. Administrators (`admins/{adminId}`):
   - Primary Owner: `rakshiths056@gmail.com` (`isPrimaryOwner()`).
   - Persistent Additional Administrator: `jeffery158540@gmail.com` (Firebase UID: `liDG3eSTJuS8eTxin2JWt6SpqvD2`).
   - Only the Primary Owner (`isPrimaryOwner()`) can grant or revoke additional administrators in `/admins/{adminId}`.
   - Additional administrators (`isAdmin()`) have full Admin Console content permissions but cannot remove/demote the Primary Owner or grant admin access to other users.

## 2. The "Dirty Dozen" Payloads (Must Return PERMISSION_DENIED)
1. Unauthenticated client attempting to create a course in `/courses/{courseSlug}`.
2. Non-admin student attempting to delete a course in `/courses/{courseSlug}`.
3. Non-admin student attempting to write an unpublished course or set `published = true`.
4. Client attempting to read an unpublished course when not an administrator.
5. User A attempting to read User B's profile document at `/users/{userBId}`.
6. User A attempting to write or update User B's profile at `/users/{userBId}`.
7. Student attempting to change their own role to `"admin"` via profile update.
8. Secondary administrator (`liDG3eSTJuS8eTxin2JWt6SpqvD2`) attempting to grant admin access in `/admins/{newAdminId}` or demote `rakshiths056@gmail.com`.
9. Attacker creating a quiz attempt under another user's path `/users/{victimId}/quizAttempts/{attemptId}`.
10. Attacker modifying the immutable `attemptId` or `userId` in a quiz attempt.
11. Attacker injecting a 1.5MB junk string as a document ID to exhaust database memory.
12. Non-admin attempting blanket listing of all user profiles.
