import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  Presentation,
  AlertCircle,
  Loader2,
  FileText,
} from 'lucide-react';
import { PptxSlideData } from '../data/learningPlatform';

/**
 * Pure client-side ZIP + OpenXML (.pptx) slide parser.
 * Extracts slide titles, bullet text runs (<a:t>), and speaker notes from
 * ppt/slides/slide*.xml inside a .pptx archive directly in the browser.
 * No external third-party file viewers or cloud conversion services required.
 */
async function inflateRawBytes(compressed: Uint8Array): Promise<Uint8Array> {
  if (typeof DecompressionStream === 'undefined') {
    throw new Error('Browser does not support DecompressionStream for .pptx extraction.');
  }
  const ds = new DecompressionStream('deflate-raw');
  const writer = ds.writable.getWriter();
  writer.write(compressed as unknown as BufferSource);
  writer.close();

  const reader = ds.readable.getReader();
  const chunks: Uint8Array[] = [];
  let totalLength = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      totalLength += value.byteLength;
    }
  }
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return result;
}

interface ZipEntry {
  fileName: string;
  compressionMethod: number;
  compressedSize: number;
  uncompressedSize: number;
  localHeaderOffset: number;
}

function readZipCentralDirectory(buffer: ArrayBuffer): ZipEntry[] {
  const view = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  const len = buffer.byteLength;

  // Locate End of Central Directory (EOCD) signature 0x06054b50
  let eocdOffset = -1;
  const minOffset = Math.max(0, len - 65557);
  for (let i = len - 22; i >= minOffset; i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset < 0) {
    throw new Error('Invalid .pptx archive: ZIP central directory not found.');
  }

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const cdOffset = view.getUint32(eocdOffset + 16, true);
  const decoder = new TextDecoder('utf-8');
  const entries: ZipEntry[] = [];

  let ptr = cdOffset;
  for (let i = 0; i < totalEntries && ptr + 46 <= len; i++) {
    const sig = view.getUint32(ptr, true);
    if (sig !== 0x02014b50) break;

    const compressionMethod = view.getUint16(ptr + 10, true);
    const compressedSize = view.getUint32(ptr + 20, true);
    const uncompressedSize = view.getUint32(ptr + 24, true);
    const fileNameLen = view.getUint16(ptr + 28, true);
    const extraLen = view.getUint16(ptr + 30, true);
    const commentLen = view.getUint16(ptr + 32, true);
    const localHeaderOffset = view.getUint32(ptr + 42, true);

    const fileName = decoder.decode(bytes.subarray(ptr + 46, ptr + 46 + fileNameLen));
    entries.push({
      fileName,
      compressionMethod,
      compressedSize,
      uncompressedSize,
      localHeaderOffset,
    });

    ptr += 46 + fileNameLen + extraLen + commentLen;
  }

  return entries;
}

async function extractZipEntryText(buffer: ArrayBuffer, entry: ZipEntry): Promise<string> {
  const view = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  const offset = entry.localHeaderOffset;

  if (view.getUint32(offset, true) !== 0x04034b50) {
    throw new Error(`Corrupt local header for ${entry.fileName}`);
  }
  const fileNameLen = view.getUint16(offset + 26, true);
  const extraLen = view.getUint16(offset + 28, true);
  const dataStart = offset + 30 + fileNameLen + extraLen;
  const compressedSlice = bytes.subarray(dataStart, dataStart + entry.compressedSize);

  const decoder = new TextDecoder('utf-8');
  if (entry.compressionMethod === 0) {
    return decoder.decode(compressedSlice);
  }
  if (entry.compressionMethod === 8) {
    const inflated = await inflateRawBytes(compressedSlice);
    return decoder.decode(inflated);
  }
  throw new Error(`Unsupported ZIP compression method (${entry.compressionMethod}) in ${entry.fileName}`);
}

export function parseSlideXmlContent(
  xmlString: string,
  slideNumber: number,
  notesXmlString?: string
): PptxSlideData {
  const extractLines = (rawXml: string): string[] => {
    const lines: string[] = [];
    if (typeof DOMParser !== 'undefined') {
      const parser = new DOMParser();
      const doc = parser.parseFromString(rawXml, 'application/xml');
      const paragraphs = Array.from(doc.getElementsByTagNameNS('*', 'p'));
      for (const p of paragraphs) {
        const textNodes = Array.from(p.getElementsByTagNameNS('*', 't'));
        const line = textNodes
          .map((t) => t.textContent || '')
          .join('')
          .trim();
        if (line) {
          lines.push(line);
        }
      }
    } else {
      const pMatches = rawXml.match(/<a:p\b[\s\S]*?<\/a:p>/g) || [];
      for (const pBlock of pMatches) {
        const tMatches = Array.from(pBlock.matchAll(/<a:t[^>]*>([\s\S]*?)<\/a:t>/g));
        const line = tMatches
          .map((m) => m[1].replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'))
          .join('')
          .trim();
        if (line) {
          lines.push(line);
        }
      }
    }
    return lines;
  };

  const paragraphLines = extractLines(xmlString);
  const title = paragraphLines[0] || `Slide ${slideNumber}`;
  const bullets = paragraphLines.slice(1);

  let notes: string | undefined;
  if (notesXmlString) {
    const noteLines = extractLines(notesXmlString).filter(
      (line) => line && line !== String(slideNumber)
    );
    if (noteLines.length > 0) {
      notes = noteLines.join(' ');
    }
  }

  return {
    slideNumber,
    title,
    bullets: bullets.length > 0 ? bullets : ['No additional text on this slide.'],
    ...(notes ? { notes } : {}),
  };
}

export async function parsePptxArrayBuffer(buffer: ArrayBuffer): Promise<PptxSlideData[]> {
  const entries = readZipCentralDirectory(buffer);
  const slideEntries = entries
    .filter((e) => /^ppt\/slides\/slide(\d+)\.xml$/i.test(e.fileName))
    .sort((a, b) => {
      const numA = Number(a.fileName.match(/slide(\d+)\.xml/i)?.[1] || 0);
      const numB = Number(b.fileName.match(/slide(\d+)\.xml/i)?.[1] || 0);
      return numA - numB;
    });

  if (slideEntries.length === 0) {
    throw new Error('No slides found inside the .pptx file.');
  }

  const slides: PptxSlideData[] = [];
  for (let i = 0; i < slideEntries.length; i++) {
    const entry = slideEntries[i];
    const xmlText = await extractZipEntryText(buffer, entry);
    const parsedSlide = parseSlideXmlContent(xmlText, i + 1);

    // Check for matching speaker notes (ppt/notesSlides/notesSlideN.xml)
    const noteEntry = entries.find(
      (e) => e.fileName.toLowerCase() === `ppt/notesslides/notesslide${i + 1}.xml`
    );
    if (noteEntry) {
      try {
        const noteXml = await extractZipEntryText(buffer, noteEntry);
        const noteParsed = parseSlideXmlContent(noteXml, i + 1);
        const allNoteLines = [noteParsed.title, ...noteParsed.bullets].filter(
          (line) =>
            line &&
            line !== `Slide ${i + 1}` &&
            line !== 'No additional text on this slide.' &&
            line !== String(i + 1)
        );
        if (allNoteLines.length > 0) {
          parsedSlide.notes = allNoteLines.join(' ');
        }
      } catch {}
    }

    slides.push(parsedSlide);
  }

  return slides;
}

export async function parsePptxFile(file: File): Promise<PptxSlideData[]> {
  if (!file.name.toLowerCase().endsWith('.pptx')) {
    throw new Error('Unsupported file format. Please select a valid .pptx presentation file.');
  }
  const buffer = await file.arrayBuffer();
  return parsePptxArrayBuffer(buffer);
}

interface PptxViewerProps {
  title: string;
  slides?: PptxSlideData[];
  pptxUrl?: string;
  fileName?: string;
  pptxFileName?: string;
}

const ZOOM_LEVELS = [75, 100, 125, 150] as const;

export const PptxViewer: React.FC<PptxViewerProps> = ({
  title,
  slides: initialSlides,
  pptxUrl,
  fileName: propFileName,
  pptxFileName,
}) => {
  const fileName = propFileName || pptxFileName;
  const [slides, setSlides] = useState<PptxSlideData[]>(initialSlides || []);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [zoomPercent, setZoomPercent] = useState<number>(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialSlides && initialSlides.length > 0) {
      setSlides(initialSlides);
      setCurrentIndex(0);
      setError(null);
      return;
    }

    if (pptxUrl && pptxUrl.trim()) {
      let cancelled = false;
      setIsLoading(true);
      setError(null);
      fetch(pptxUrl)
        .then((res) => {
          if (!res.ok) throw new Error(`Could not load presentation (${res.status})`);
          return res.arrayBuffer();
        })
        .then((buf) => parsePptxArrayBuffer(buf))
        .then((extracted) => {
          if (!cancelled) {
            setSlides(extracted);
            setCurrentIndex(0);
            setIsLoading(false);
          }
        })
        .catch((err: any) => {
          if (!cancelled) {
            setError(err?.message || 'Unable to render this .pptx presentation in browser.');
            setIsLoading(false);
          }
        });

      return () => {
        cancelled = true;
      };
    }
  }, [initialSlides, pptxUrl]);

  const totalSlides = slides.length;
  const currentSlide = slides[currentIndex] || null;

  const goPrev = useCallback(() => {
    setCurrentIndex((prev) => Math.max(0, prev - 1));
  }, []);

  const goNext = useCallback(() => {
    setCurrentIndex((prev) => Math.min(Math.max(0, totalSlides - 1), prev + 1));
  }, [totalSlides]);

  const handleZoomIn = () => {
    const idx = ZOOM_LEVELS.indexOf(zoomPercent as any);
    if (idx < ZOOM_LEVELS.length - 1) {
      setZoomPercent(ZOOM_LEVELS[idx + 1]);
    }
  };

  const handleZoomOut = () => {
    const idx = ZOOM_LEVELS.indexOf(zoomPercent as any);
    if (idx > 0) {
      setZoomPercent(ZOOM_LEVELS[idx - 1]);
    }
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      setIsFullscreen((prev) => !prev);
    }
  };

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        goPrev();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        goNext();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goPrev, goNext]);

  if (isLoading) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-white my-6">
        <Loader2 className="w-8 h-8 text-blue-400 animate-spin mx-auto mb-3" />
        <p className="font-semibold text-base">Loading presentation slides...</p>
        <p className="text-xs text-slate-400 mt-1">Rendering {fileName || title} directly in browser</p>
      </div>
    );
  }

  if (error || totalSlides === 0) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-8 text-center my-6">
        <AlertCircle className="w-10 h-10 text-amber-600 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-900 mb-1">
          {error ? 'Presentation Viewer Error' : 'No Presentation Slides Available'}
        </h3>
        <p className="text-sm text-slate-600 max-w-md mx-auto">
          {error ||
            'This PPTX lesson does not have slides uploaded yet. Please check back once the instructor publishes the slide deck.'}
        </p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      data-testid="pptx-viewer"
      className={`bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'my-6'
      }`}
    >
      {/* Top Presentation Toolbar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-slate-200">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
            <Presentation className="w-4 h-4" />
          </div>
          <div className="truncate">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400 block">
              CoinEdu Slide Deck
            </span>
            <h4 className="text-sm font-bold text-white truncate">{fileName || title}</h4>
          </div>
        </div>

        {/* Zoom & Fullscreen Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-800 rounded-lg border border-slate-700 p-0.5">
            <button
              type="button"
              onClick={handleZoomOut}
              disabled={zoomPercent <= ZOOM_LEVELS[0]}
              aria-label="Zoom out"
              className="p-1.5 text-slate-300 hover:text-white disabled:opacity-40 transition-colors cursor-pointer"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="px-2 text-xs font-semibold text-slate-200 min-w-[3.2rem] text-center">
              {zoomPercent}%
            </span>
            <button
              type="button"
              onClick={handleZoomIn}
              disabled={zoomPercent >= ZOOM_LEVELS[ZOOM_LEVELS.length - 1]}
              aria-label="Zoom in"
              className="p-1.5 text-slate-300 hover:text-white disabled:opacity-40 transition-colors cursor-pointer"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? 'Exit full screen' : 'Enter full screen'}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-3.5 h-3.5" /> Exit Full Screen
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5" /> Full Screen
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Slide Stage */}
      <div className="flex-1 bg-slate-950 p-4 sm:p-8 flex items-center justify-center overflow-auto min-h-[360px] sm:min-h-[440px]">
        {currentSlide && (
          <div
            style={{
              transform: `scale(${zoomPercent / 100})`,
              transformOrigin: 'center center',
            }}
            className="w-full max-w-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950/60 border border-slate-700/80 rounded-2xl p-6 sm:p-12 shadow-2xl transition-transform duration-150 flex flex-col justify-between min-h-[300px] sm:min-h-[360px]"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-6 pb-4 border-b border-slate-800">
                <span className="text-xs font-bold uppercase tracking-widest text-blue-400">
                  {title}
                </span>
                <span className="text-xs font-mono text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">
                  Slide {currentIndex + 1} of {totalSlides}
                </span>
              </div>

              <h2 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight mb-6 leading-snug">
                {currentSlide.title}
              </h2>

              {currentSlide.imageUrl && (
                <div className="mb-6 rounded-xl overflow-hidden border border-slate-700 bg-slate-950 max-h-56 flex items-center justify-center">
                  <img
                    src={currentSlide.imageUrl}
                    alt={currentSlide.title}
                    className="max-h-56 object-contain"
                  />
                </div>
              )}

              <ul className="space-y-3.5">
                {currentSlide.bullets.map((bullet, bIdx) => (
                  <li
                    key={bIdx}
                    className="flex items-start gap-3 text-slate-200 text-sm sm:text-base leading-relaxed"
                  >
                    <span className="w-2 h-2 rounded-full bg-blue-500 mt-2 shrink-0" />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
              <span>CoinEdu Academy</span>
              <span>Use Left / Right arrow keys to navigate</span>
            </div>
          </div>
        )}
      </div>

      {/* Optional Speaker Notes Drawer */}
      {currentSlide?.notes && (
        <div className="bg-slate-900/90 border-t border-slate-800 px-6 py-3 text-xs text-slate-300 flex items-start gap-2">
          <FileText className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-white mr-1.5">Instructor Notes:</span>
            {currentSlide.notes}
          </div>
        </div>
      )}

      {/* Slide Thumbnail / Quick Jump Bar + Prev/Next Controls */}
      <div className="bg-slate-900 border-t border-slate-800 px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={goPrev}
            disabled={currentIndex === 0}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-bold text-white border border-slate-700 transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" /> Previous
          </button>

          <span
            data-testid="pptx-slide-indicator"
            className="px-3 py-1.5 text-xs font-bold text-slate-200 bg-slate-950 rounded-lg border border-slate-800"
          >
            Slide {currentIndex + 1} of {totalSlides}
          </span>

          <button
            type="button"
            onClick={goNext}
            disabled={currentIndex >= totalSlides - 1}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-xs font-bold text-white transition-colors cursor-pointer"
          >
            Next <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Slide Number Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full py-1">
          {slides.map((s, idx) => (
            <button
              key={s.slideNumber || idx}
              type="button"
              onClick={() => setCurrentIndex(idx)}
              title={s.title}
              className={`w-7 h-7 rounded-lg text-xs font-bold transition-colors shrink-0 cursor-pointer ${
                idx === currentIndex
                  ? 'bg-blue-600 text-white border border-blue-400'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white border border-slate-700'
              }`}
            >
              {idx + 1}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
