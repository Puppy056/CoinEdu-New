import React from 'react';
import { ArrowRight, BookOpen } from 'lucide-react';

interface HeroProps {
  onExploreTracks: () => void;
  onOpenCalculators?: () => void;
  onOpenSecurity?: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreTracks,
}) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-16 sm:pt-20 sm:pb-24">
      {/* Background radial ambient lights */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-cyan-500/10 via-blue-600/5 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute top-1/4 right-10 w-72 h-72 bg-amber-500/5 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Headline */}
        <div className="max-w-4xl">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15]">
            Learn Cryptocurrency, Blockchain &{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-amber-300">
              Money Safety
            </span>
          </h1>
          <p className="mt-5 text-base sm:text-xl text-slate-300 leading-relaxed font-normal">
            No false hype. No get-rich-quick schemes. Just simple, honest lessons to help you understand how blockchain works, how to invest carefully, and how to protect your hard-earned money from scams.
          </p>
        </div>

        {/* Action Button */}
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <button
            onClick={onExploreTracks}
            className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm sm:text-base text-slate-950 bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-cyan-200 transition-all shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/35 hover:-translate-y-0.5 cursor-pointer"
          >
            <BookOpen className="w-5 h-5" />
            <span>Start Learning</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
        </div>

      </div>
    </section>
  );
};
