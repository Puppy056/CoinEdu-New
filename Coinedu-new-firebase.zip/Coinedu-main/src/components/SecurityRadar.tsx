import React, { useState, useEffect, useMemo } from 'react';
import { assessScamRisk, ScamAuditFactors } from '../utils/finance';
import { ShieldAlert, ShieldCheck, CheckSquare, Square, AlertOctagon, HelpCircle, Key } from 'lucide-react';

export const SecurityRadar: React.FC = () => {
  // Scam Detector Factors
  const [factors, setFactors] = useState<ScamAuditFactors>({
    asksForSeedPhrase: false,
    guaranteedReturns: true,
    unsolicitedDmOrAirdrop: false,
    urgentTimePressure: true,
    unverifiedContract: false,
  });

  const scamResult = useMemo(() => {
    return assessScamRisk(factors);
  }, [factors]);

  // 8-Point Defense Checklist State with simple Indian English
  const defaultChecklist = [
    { id: 'c1', label: 'Secret recovery words (seed phrase) written safely on paper or metal — NEVER saved in phone photos, Google Drive, or email', checked: true },
    { id: 'c2', label: 'Hardware wallet (a safe physical USB device like Ledger or Trezor) used for long-term savings', checked: true },
    { id: 'c3', label: 'Two-Factor Authentication (2FA) enabled using an Authenticator app (NOT SMS text messages, to prevent phone number cloning)', checked: true },
    { id: 'c4', label: 'Official wallet and exchange websites saved in browser bookmarks so you never click fake search ads', checked: false },
    { id: 'c5', label: 'Old token spending permissions checked and cancelled regularly using safety tools like Revoke.cash', checked: false },
    { id: 'c6', label: 'Receiver wallet address checked carefully letter-by-letter before sending any crypto', checked: false },
    { id: 'c7', label: 'Sent a small test amount first before sending larger sums of money', checked: true },
    { id: 'c8', label: 'Never trust any strangers sending DMs or Telegram messages offering "customer support", "bonus rewards", or "wallet validation"', checked: true },
  ];

  const [checklist, setChecklist] = useState(() => {
    try {
      const saved = localStorage.getItem('coinedu_security_checklist');
      return saved ? JSON.parse(saved) : defaultChecklist;
    } catch {
      return defaultChecklist;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('coinedu_security_checklist', JSON.stringify(checklist));
    } catch (e) {
      console.warn('Could not save checklist to localStorage', e);
    }
  }, [checklist]);

  const toggleCheck = (id: string) => {
    setChecklist((prev: typeof defaultChecklist) =>
      prev.map(item => item.id === id ? { ...item, checked: !item.checked } : item)
    );
  };

  const completedCount = checklist.filter((item: typeof defaultChecklist[0]) => item.checked).length;
  const scorePercent = Math.round((completedCount / checklist.length) * 100);

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-rose-950/60 border border-rose-800/40 text-rose-300 text-xs font-semibold uppercase tracking-wider mb-2">
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Safety & Scam Checker</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Scam Checker & Wallet Safety Guide
        </h2>
        <p className="mt-2 text-slate-300 text-sm sm:text-base max-w-3xl leading-relaxed">
          In cryptocurrency, transactions cannot be reversed or cancelled. Once money is sent to a scammer, no bank or customer care can bring it back. Use this tool to check if an offer looks like a scam, and follow our 8 simple safety habits.
        </p>

        {/* Technical Term Explanation */}
        <div className="mt-4 p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-2 max-w-3xl">
          <div className="flex items-start gap-2">
            <HelpCircle className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-cyan-300">Self-custodial wallet: </strong>
              <span>A wallet where you control the private keys yourself. If you lose your recovery phrase, recovering your wallet may be impossible. No bank manager can reset your password.</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
        
        {/* Scam Detector (Left) */}
        <div className="lg:col-span-6 bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <AlertOctagon className="w-5 h-5 text-rose-400" />
                <span>Scam Warning Checker</span>
              </h3>
              <span className="text-[11px] font-mono text-slate-400">Risk Assessment</span>
            </div>
            <p className="text-xs text-slate-300 mb-6">
              Tick the warning signs you see in an investment offer, WhatsApp group, Telegram channel, or website message:
            </p>

            <div className="space-y-3 mb-6">
              <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={factors.asksForSeedPhrase}
                  onChange={(e) => setFactors({ ...factors, asksForSeedPhrase: e.target.checked })}
                  className="mt-0.5 accent-rose-500 rounded cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-semibold text-rose-300 block">Asks for your 12 or 24-word Secret Recovery Phrase</span>
                  <span className="text-slate-400 text-[11px]">Claims to "synchronize", "validate", or "fix" your wallet. (100% guarantee of a scam).</span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={factors.guaranteedReturns}
                  onChange={(e) => setFactors({ ...factors, guaranteedReturns: e.target.checked })}
                  className="mt-0.5 accent-rose-500 rounded cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-semibold text-amber-300 block">Promises Guaranteed Daily or Monthly High Profits</span>
                  <span className="text-slate-400 text-[11px]">Promises 2% to 10% daily risk-free income. In real investing, no one can guarantee high returns without risk.</span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={factors.urgentTimePressure}
                  onChange={(e) => setFactors({ ...factors, urgentTimePressure: e.target.checked })}
                  className="mt-0.5 accent-rose-500 rounded cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-semibold text-white block">Urgent Countdown Timer ("Hurry, only 15 minutes left!")</span>
                  <span className="text-slate-400 text-[11px]">Creates false panic so you make quick emotional mistakes without thinking.</span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={factors.unsolicitedDmOrAirdrop}
                  onChange={(e) => setFactors({ ...factors, unsolicitedDmOrAirdrop: e.target.checked })}
                  className="mt-0.5 accent-rose-500 rounded cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-semibold text-white block">Unexpected Direct Message or Free Token "Gift"</span>
                  <span className="text-slate-400 text-[11px]">Strangers messaging on Telegram, Instagram, or Discord pretending to give free money.</span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={factors.unverifiedContract}
                  onChange={(e) => setFactors({ ...factors, unverifiedContract: e.target.checked })}
                  className="mt-0.5 accent-rose-500 rounded cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-semibold text-white block">Secret or Unchecked Smart Contract Code</span>
                  <span className="text-slate-400 text-[11px]">The computer code controlling the token is hidden from public view and has no safety audit.</span>
                </div>
              </label>
            </div>
          </div>

          {/* Detector Score Output */}
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Threat Level</span>
              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                scamResult.verdict === 'CRITICAL_SCAM' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                scamResult.verdict === 'CAUTION' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                scamResult.verdict === 'LOW_RISK' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                'bg-emerald-950 text-emerald-300 border border-emerald-800'
              }`}>
                {scamResult.verdict === 'CRITICAL_SCAM' ? 'DANGER: LIKELY SCAM' :
                 scamResult.verdict === 'CAUTION' ? 'WARNING: HIGH RISK' :
                 scamResult.verdict === 'LOW_RISK' ? 'LOW RISK' : 'LOOKS SAFE'} ({scamResult.dangerScore}/100)
              </span>
            </div>

            <div className="h-2.5 w-full bg-slate-800 rounded-full overflow-hidden mb-3">
              <div
                style={{ width: `${scamResult.dangerScore}%` }}
                className={`h-full transition-all duration-300 ${
                  scamResult.dangerScore >= 80 ? 'bg-rose-500' :
                  scamResult.dangerScore >= 40 ? 'bg-amber-400' :
                  scamResult.dangerScore > 0 ? 'bg-blue-400' : 'bg-emerald-400'
                }`}
              />
            </div>

            <p className="text-xs text-slate-200 leading-relaxed font-medium">
              {scamResult.dangerScore >= 80 ? 'DO NOT INTERACT. This has major signs of a scam. Never send money or share your recovery words.' :
               scamResult.dangerScore >= 40 ? 'BE VERY CAREFUL. Serious warning signs detected. Do not invest any money you are not prepared to lose.' :
               scamResult.dangerScore > 0 ? 'Small warning signs present. Always double check official project websites and never rush.' :
               'No major warning signs selected. Always stay cautious and never share your private recovery phrase with anyone.'}
            </p>
          </div>
        </div>

        {/* 8-Point Defense Protocol (Right) */}
        <div className="lg:col-span-6 bg-[#0b1329] border border-cyan-500/30 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-cyan-400" />
                <span>8 Simple Safety Rules for Your Wallet</span>
              </h3>
              <span className="text-xs font-mono text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800">
                {completedCount} of {checklist.length} Completed
              </span>
            </div>

            <div className="mb-6">
              <div className="flex justify-between text-xs text-slate-400 mb-1.5 font-medium">
                <span>Your Safety Score</span>
                <span className="font-mono text-cyan-300">{scorePercent}%</span>
              </div>
              <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                <div
                  style={{ width: `${scorePercent}%` }}
                  className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-300"
                />
              </div>
            </div>

            <div className="space-y-2.5">
              {checklist.map((item: any) => (
                <button
                  key={item.id}
                  onClick={() => toggleCheck(item.id)}
                  className={`w-full text-left p-3 rounded-xl border text-xs leading-relaxed transition-all flex items-start gap-3 cursor-pointer ${
                    item.checked
                      ? 'bg-slate-900/90 border-cyan-500/30 text-slate-200'
                      : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="mt-0.5 flex-shrink-0">
                    {item.checked ? (
                      <CheckSquare className="w-4 h-4 text-cyan-400" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-600" />
                    )}
                  </div>
                  <span className={item.checked ? 'text-slate-200 font-medium' : 'text-slate-400'}>
                    {item.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span>Rule #1: If you do not control your secret keys, you do not own your coins.</span>
            </span>
            <button
              onClick={() => setChecklist(defaultChecklist)}
              className="text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
            >
              Reset Checklist
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
