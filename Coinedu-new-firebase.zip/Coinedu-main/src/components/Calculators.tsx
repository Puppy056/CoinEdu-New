import React, { useState, useMemo } from 'react';
import {
  calculateDCA,
  calculateImpermanentLoss,
  calculatePortfolioAllocation,
} from '../utils/finance';
import { Calculator, TrendingUp, PieChart, Percent, Info, HelpCircle } from 'lucide-react';

export const Calculators: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dca' | 'allocation' | 'il'>('dca');

  // --- DCA Calculator State ---
  const [monthlyDeposit, setMonthlyDeposit] = useState<number>(200);
  const [durationMonths, setDurationMonths] = useState<number>(36);
  const [annualRate, setAnnualRate] = useState<number>(18);

  const dcaResult = useMemo(() => {
    return calculateDCA(monthlyDeposit, durationMonths, annualRate);
  }, [monthlyDeposit, durationMonths, annualRate]);

  // --- Portfolio Risk Profile State ---
  const [riskScore, setRiskScore] = useState<number>(5);
  const portfolioResult = useMemo(() => {
    return calculatePortfolioAllocation(riskScore);
  }, [riskScore]);

  // --- Impermanent Loss Calculator State ---
  const [initialPrice, setInitialPrice] = useState<number>(100);
  const [newPrice, setNewPrice] = useState<number>(200);
  const [poolApy, setPoolApy] = useState<number>(12);

  const ilResult = useMemo(() => {
    return calculateImpermanentLoss(initialPrice, newPrice, poolApy);
  }, [initialPrice, newPrice, poolApy]);

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-blue-950/60 border border-blue-800/40 text-blue-300 text-xs font-semibold uppercase tracking-wider mb-2">
          <Calculator className="w-3.5 h-3.5" />
          <span>Interactive Practice Tools</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Practice Tools & Money Calculators
        </h2>
        <p className="mt-2 text-slate-300 text-sm sm:text-base max-w-3xl leading-relaxed">
          See how your investments can grow without guesswork or bias. Check how regular monthly investing works, find an investment mix based on how much loss you can handle, and see how pool trading works.
        </p>

        {/* Simple Word Box */}
        <div className="mt-4 p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-start gap-2">
            <HelpCircle className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-cyan-300">Bias: </strong>
              <span>An unfair preference or a way of thinking that favours one side. Calculators help you look at real numbers instead of emotional gut feelings.</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <HelpCircle className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-cyan-300">Volatility: </strong>
              <span>How much a price goes up and down over time. Crypto prices move up and down much faster than normal bank savings.</span>
            </div>
          </div>
        </div>
      </div>

      {/* Simulator Switcher Tabs */}
      <div className="flex flex-wrap gap-2 mb-8 p-1.5 rounded-xl bg-slate-900 border border-slate-800 max-w-xl">
        <button
          onClick={() => setActiveTab('dca')}
          className={`flex-1 min-w-[140px] py-2.5 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'dca'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Regular Monthly Investing (DCA)</span>
        </button>

        <button
          onClick={() => setActiveTab('allocation')}
          className={`flex-1 min-w-[140px] py-2.5 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'allocation'
              ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>How Much Loss You Can Handle</span>
        </button>

        <button
          onClick={() => setActiveTab('il')}
          className={`flex-1 min-w-[140px] py-2.5 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'il'
              ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <Percent className="w-4 h-4" />
          <span>Trading Pool Risk (Impermanent Loss)</span>
        </button>
      </div>

      {/* 1. DCA SIMULATOR */}
      {activeTab === 'dca' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Controls */}
          <div className="lg:col-span-5 bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-cyan-400" />
                <span>Monthly Investment Plan</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                <strong>DCA (Dollar Cost Averaging):</strong> Putting in a fixed amount of money every month (like an SIP) instead of investing all your savings at once.
              </p>
            </div>

            {/* Monthly Investment */}
            <div>
              <div className="flex justify-between text-xs sm:text-sm font-medium mb-2">
                <label htmlFor="dca-deposit" className="text-slate-300">Monthly Amount ($ USD)</label>
                <span className="text-cyan-400 font-mono font-bold">${monthlyDeposit}</span>
              </div>
              <input
                id="dca-deposit"
                type="range"
                min="25"
                max="2500"
                step="25"
                value={monthlyDeposit}
                onChange={(e) => setMonthlyDeposit(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-850 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
                <span>$25 / month</span>
                <span>$1,000 / month</span>
                <span>$2,500 / month</span>
              </div>
            </div>

            {/* Duration (Months) */}
            <div>
              <div className="flex justify-between text-xs sm:text-sm font-medium mb-2">
                <label htmlFor="dca-duration" className="text-slate-300">How Long You Will Invest</label>
                <span className="text-cyan-400 font-mono font-bold">
                  {durationMonths} Months ({(durationMonths / 12).toFixed(1)} Years)
                </span>
              </div>
              <input
                id="dca-duration"
                type="range"
                min="6"
                max="120"
                step="6"
                value={durationMonths}
                onChange={(e) => setDurationMonths(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-850 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
                <span>6 Months</span>
                <span>3 Years</span>
                <span>10 Years</span>
              </div>
            </div>

            {/* Expected Annual Growth Rate */}
            <div>
              <div className="flex justify-between text-xs sm:text-sm font-medium mb-2">
                <label htmlFor="dca-rate" className="text-slate-300">Estimated Yearly Growth Rate (%)</label>
                <span className="text-cyan-400 font-mono font-bold">{annualRate}%</span>
              </div>
              <input
                id="dca-rate"
                type="range"
                min="1"
                max="60"
                step="1"
                value={annualRate}
                onChange={(e) => setAnnualRate(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-850 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
                <span>Low (5%)</span>
                <span>Medium (18%)</span>
                <span>High (40%+)</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 leading-relaxed">
              <strong className="text-cyan-300 block mb-1">Why this strategy works:</strong>
              When crypto prices go down, your fixed monthly money buys more coins automatically. When prices go up, it buys fewer coins. You do not have to guess market timings or daily price tops and bottoms.
            </div>
          </div>

          {/* Results Output */}
          <div className="lg:col-span-7 bg-[#0b1329] border border-cyan-500/30 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">Estimated Growth Result</h3>
                <span className="text-xs font-mono px-2.5 py-1 rounded bg-cyan-950 border border-cyan-800 text-cyan-300">
                  Monthly SIP Model
                </span>
              </div>

              {/* Primary Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Total Money You Put In</span>
                  <span className="text-xl sm:text-2xl font-extrabold text-white font-mono">
                    ${dcaResult.totalInvested.toLocaleString()}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-cyan-900/60">
                  <span className="text-xs text-cyan-400 block mb-1">Estimated Final Value</span>
                  <span className="text-xl sm:text-2xl font-extrabold text-cyan-300 font-mono">
                    ${Math.round(dcaResult.finalValue).toLocaleString()}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-emerald-900/60 col-span-2 sm:col-span-1">
                  <span className="text-xs text-emerald-400 block mb-1">Estimated Total Profit</span>
                  <span className="text-xl sm:text-2xl font-extrabold text-emerald-300 font-mono">
                    +${Math.round(dcaResult.totalProfit).toLocaleString()}
                    <span className="text-xs ml-1 font-normal text-emerald-400">({dcaResult.roiPercentage}%)</span>
                  </span>
                </div>
              </div>

              {/* Progress Visual Bar */}
              <div className="mb-6">
                <div className="flex justify-between text-xs text-slate-400 mb-2">
                  <span>Breakdown of Your Money</span>
                  <span>Money Put In vs Profit Earned</span>
                </div>
                <div className="h-5 w-full bg-slate-800 rounded-full overflow-hidden flex">
                  <div
                    style={{ width: `${(dcaResult.totalInvested / Math.max(dcaResult.finalValue, 1)) * 100}%` }}
                    className="bg-slate-600 transition-all duration-300"
                    title={`Money Put In: $${dcaResult.totalInvested}`}
                  />
                  <div
                    style={{ width: `${(dcaResult.totalProfit / Math.max(dcaResult.finalValue, 1)) * 100}%` }}
                    className="bg-gradient-to-r from-cyan-400 to-emerald-400 transition-all duration-300"
                    title={`Profit: $${dcaResult.totalProfit}`}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 mt-2">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-600 inline-block" />
                    Money Put In (${dcaResult.totalInvested.toLocaleString()})
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block" />
                    Estimated Profit (+${Math.round(dcaResult.totalProfit).toLocaleString()})
                  </span>
                </div>
              </div>
            </div>

            {/* Simple note */}
            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 leading-normal">
              * Note: Past returns do not guarantee future returns. Crypto prices can drop suddenly. Regular monthly investing helps protect you from buying at peaks, but it does not eliminate risk.
            </div>
          </div>

        </div>
      )}

      {/* 2. PORTFOLIO ALLOCATION: HOW MUCH LOSS YOU CAN HANDLE */}
      {activeTab === 'allocation' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-5 bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <PieChart className="w-5 h-5 text-blue-400" />
                <span>How Much Loss You Can Handle</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Slide the bar according to how much price fluctuation you are comfortable with.
              </p>
            </div>

            <div>
              <div className="flex justify-between text-xs sm:text-sm font-medium mb-2">
                <label htmlFor="risk-score-slider" className="text-slate-300">Comfort Level (1 = Very Safe, 10 = High Risk)</label>
                <span className="text-blue-400 font-mono font-bold">{riskScore} / 10</span>
              </div>
              <input
                id="risk-score-slider"
                type="range"
                min="1"
                max="10"
                step="1"
                value={riskScore}
                onChange={(e) => setRiskScore(Number(e.target.value))}
                className="w-full accent-blue-500 bg-slate-850 h-2.5 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
                <span>1: Safety First</span>
                <span>5: Balanced</span>
                <span>10: Maximum Risk</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-xs uppercase tracking-wider font-bold text-slate-400 block mb-1">
                Selected Plan
              </span>
              <span className="text-lg font-extrabold text-blue-300 block mb-2">
                {portfolioResult.riskTier === 'Conservative' ? 'Safety-First Plan' :
                 portfolioResult.riskTier === 'Balanced' ? 'Balanced Plan' :
                 portfolioResult.riskTier === 'Growth' ? 'Growth Plan' : 'High Risk Plan'}
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">
                {portfolioResult.description}
              </p>
            </div>

            <div className="p-3.5 rounded-lg bg-blue-950/30 border border-blue-800/40 text-xs text-blue-200">
              <strong>How often to review: </strong>
              Check your portfolio {portfolioResult.rebalanceFrequency.toLowerCase()}. If one coin grew very fast, sell a small portion to bring your ratios back to balance.
            </div>
          </div>

          <div className="lg:col-span-7 bg-[#0b1329] border border-blue-500/30 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <h3 className="text-lg font-bold text-white mb-6">Suggested Portfolio Mix</h3>

              {/* Visual Bars Breakdown */}
              <div className="space-y-4 mb-8">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-amber-400">Bitcoin (BTC) — The largest and most established digital currency</span>
                    <span className="text-white font-mono">{portfolioResult.allocations.btc}%</span>
                  </div>
                  <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div style={{ width: `${portfolioResult.allocations.btc}%` }} className="h-full bg-amber-400 transition-all duration-300" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-blue-400">Ethereum (ETH) — The leading network for smart contracts and apps</span>
                    <span className="text-white font-mono">{portfolioResult.allocations.eth}%</span>
                  </div>
                  <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div style={{ width: `${portfolioResult.allocations.eth}%` }} className="h-full bg-blue-500 transition-all duration-300" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-cyan-400">Altcoins — Other cryptocurrencies (higher reward, higher risk)</span>
                    <span className="text-white font-mono">{portfolioResult.allocations.altcoins}%</span>
                  </div>
                  <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div style={{ width: `${portfolioResult.allocations.altcoins}%` }} className="h-full bg-cyan-400 transition-all duration-300" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-emerald-400">USD Stablecoins — Digital dollars designed to stay fixed at $1</span>
                    <span className="text-white font-mono">{portfolioResult.allocations.stablecoins}%</span>
                  </div>
                  <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div style={{ width: `${portfolioResult.allocations.stablecoins}%` }} className="h-full bg-emerald-400 transition-all duration-300" />
                  </div>
                </div>
              </div>

              {/* Simple Rule */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-2">
                <p>
                  <strong>Core and Safety Rule: </strong>
                  Bitcoin and Ethereum act as the stable foundation of your portfolio. Stablecoins give you an emergency cash cushion so you are never forced to sell your crypto when prices are temporarily low.
                </p>
                <p className="text-slate-400">
                  <strong>Decentralised: </strong> A system that is not controlled by one single authority or company. Both Bitcoin and Ethereum are decentralised networks run by thousands of independent computers around the world.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-500">
              * For educational understanding only. Not financial or investment advice.
            </div>
          </div>

        </div>
      )}

      {/* 3. IMPERMANENT LOSS CALCULATOR */}
      {activeTab === 'il' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-5 bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Percent className="w-5 h-5 text-amber-400" />
                <span>Trading Pool Simulator</span>
              </h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                <strong className="text-amber-300">Liquidity: </strong> How easily something can be bought or sold without greatly affecting its price. In a decentralised exchange, regular users provide liquidity (pairs of coins) so others can swap them.
              </p>
            </div>

            {/* Initial Token Price */}
            <div>
              <label htmlFor="il-initial-price" className="block text-xs sm:text-sm font-medium text-slate-300 mb-1">
                Starting Price of Token ($)
              </label>
              <input
                id="il-initial-price"
                type="number"
                min="1"
                value={initialPrice}
                onChange={(e) => setInitialPrice(Math.max(1, Number(e.target.value)))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Future Token Price */}
            <div>
              <label htmlFor="il-future-price" className="block text-xs sm:text-sm font-medium text-slate-300 mb-1">
                New Price of Token ($)
              </label>
              <input
                id="il-future-price"
                type="number"
                min="1"
                value={newPrice}
                onChange={(e) => setNewPrice(Math.max(1, Number(e.target.value)))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Price change: <strong className="text-amber-400 font-mono">{(newPrice / initialPrice).toFixed(2)}x</strong>
              </span>
            </div>

            {/* Fee APY Earned */}
            <div>
              <label htmlFor="il-apy" className="block text-xs sm:text-sm font-medium text-slate-300 mb-1">
                Trading Fees Earned by Pool (% per year)
              </label>
              <input
                id="il-apy"
                type="number"
                min="0"
                max="200"
                value={poolApy}
                onChange={(e) => setPoolApy(Math.max(0, Number(e.target.value)))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 leading-relaxed">
              <strong className="text-amber-300 block mb-1">What is Impermanent Loss?</strong>
              When one token's price goes up a lot compared to the other token in the pool, traders buy up the cheaper token. When you withdraw your money, you will have fewer of the coin that went up in price. If this difference is bigger than the trading fees you earned, you would have made more money by simply keeping both coins in your own wallet.
            </div>
          </div>

          <div className="lg:col-span-7 bg-[#0b1329] border border-amber-500/30 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <h3 className="text-lg font-bold text-white mb-6">Trading Pool Comparison</h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                <div className="p-4 rounded-xl bg-slate-900/80 border border-rose-900/50">
                  <span className="text-xs text-rose-300 block mb-1">Impermanent Loss (vs simply holding)</span>
                  <span className="text-2xl font-extrabold text-rose-400 font-mono">
                    {ilResult.impermanentLossPct}%
                  </span>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Value difference compared to simply keeping tokens in your wallet.
                  </p>
                </div>

                <div className={`p-4 rounded-xl bg-slate-900/80 border ${
                  ilResult.netReturnWithFeesPct >= 0 ? 'border-emerald-900/50' : 'border-rose-900/50'
                }`}>
                  <span className="text-xs text-slate-300 block mb-1">Final Return (After Adding Fees Earned)</span>
                  <span className={`text-2xl font-extrabold font-mono ${
                    ilResult.netReturnWithFeesPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {ilResult.netReturnWithFeesPct > 0 ? '+' : ''}{ilResult.netReturnWithFeesPct}%
                  </span>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {ilResult.netReturnWithFeesPct >= 0
                      ? 'Fees earned were higher than the loss.'
                      : 'The loss was higher than the fees earned.'}
                  </p>
                </div>
              </div>

              {/* Reference Curve Table */}
              <div className="bg-slate-900 rounded-xl p-4 border border-slate-800">
                <h4 className="text-xs uppercase font-bold text-slate-400 mb-3 tracking-wider">
                  Quick Guide: How Price Changes Affect Your Pool Value
                </h4>
                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="bg-slate-800/80 p-2 rounded">
                    <span className="text-slate-400 block text-[10px]">1.25x (25% up)</span>
                    <span className="font-mono text-amber-300 font-bold">-0.6%</span>
                  </div>
                  <div className="bg-slate-800/80 p-2 rounded">
                    <span className="text-slate-400 block text-[10px]">1.50x (50% up)</span>
                    <span className="font-mono text-amber-300 font-bold">-2.0%</span>
                  </div>
                  <div className="bg-slate-800/80 p-2 rounded">
                    <span className="text-slate-400 block text-[10px]">2.00x (Doubles)</span>
                    <span className="font-mono text-amber-300 font-bold">-5.7%</span>
                  </div>
                  <div className="bg-slate-800/80 p-2 rounded">
                    <span className="text-slate-400 block text-[10px]">5.00x (5x up)</span>
                    <span className="font-mono text-amber-300 font-bold">-25.5%</span>
                  </div>
                </div>
              </div>

            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-500">
              * Standard automated market maker formula. Providing liquidity carries market and smart contract risks.
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
