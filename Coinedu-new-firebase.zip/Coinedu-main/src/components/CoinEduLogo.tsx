import React from 'react';

interface CoinEduLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'mark' | 'wordmark';
  theme?: 'dark' | 'light' | 'monochrome';
  asBadge?: boolean;
}

/**
 * Official CoinEdu Logo Component
 * Exact typographic reproduction of the official CoinEdu branding:
 * - Font: Poppins (Font Weight: 800 / 900)
 * - Monogram Mark: "CE"
 * - Wordmark: "CoinEdu"
 */
export const CoinEduLogo: React.FC<CoinEduLogoProps> = ({
  className = '',
  size = 'md',
  variant = 'full',
  theme = 'dark',
  asBadge = true,
}) => {
  const iconSizes = {
    sm: 'w-8 h-8 text-sm',
    md: 'w-10 h-10 text-base',
    lg: 'w-14 h-14 text-2xl',
    xl: 'w-20 h-20 text-3xl',
  };

  const textSizes = {
    sm: 'text-xl tracking-[-0.03em]',
    md: 'text-2xl sm:text-[26px] tracking-[-0.035em]',
    lg: 'text-3xl sm:text-4xl tracking-[-0.035em]',
    xl: 'text-4xl sm:text-5xl tracking-[-0.04em]',
  };

  const markFont = {
    fontFamily: "'Poppins', sans-serif",
    fontWeight: 900,
    letterSpacing: '-0.05em',
  };

  const wordmarkFont = {
    fontFamily: "'Poppins', sans-serif",
    fontWeight: 800,
    letterSpacing: '-0.035em',
  };

  // Monogram Mark ("CE")
  const renderMark = () => {
    if (!asBadge) {
      return (
        <span
          className={`font-black select-none ${
            theme === 'light' ? 'text-black' : 'text-white'
          }`}
          style={markFont}
        >
          CE
        </span>
      );
    }

    return (
      <div
        className={`relative flex items-center justify-center rounded-xl select-none transition-transform group-hover:scale-105 ${iconSizes[size]} ${
          theme === 'light'
            ? 'bg-black text-white'
            : 'bg-[#0f172a] text-white border border-slate-700/80 shadow-md shadow-cyan-950/20'
        }`}
        aria-hidden="true"
      >
        <span style={markFont} className="translate-x-[-1px]">
          CE
        </span>
      </div>
    );
  };

  // Wordmark ("CoinEdu")
  const renderWordmark = () => (
    <span
      className={`font-extrabold leading-none select-none transition-colors ${textSizes[size]} ${
        theme === 'light' ? 'text-black' : 'text-white group-hover:text-cyan-300'
      }`}
      style={wordmarkFont}
    >
      CoinEdu
    </span>
  );

  if (variant === 'mark') {
    return <div className={`inline-flex items-center ${className}`}>{renderMark()}</div>;
  }

  if (variant === 'wordmark') {
    return <div className={`inline-flex items-center ${className}`}>{renderWordmark()}</div>;
  }

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {renderMark()}
      {renderWordmark()}
    </div>
  );
};
