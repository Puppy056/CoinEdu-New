import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useContentStore, searchPlatformContent } from '../data/learningPlatform';
import { CoinEduLogo } from './CoinEduLogo';
import {
  Menu,
  X,
  LogIn,
  UserPlus,
  LogOut,
  Search,
  BookOpen,
  FileText,
  History,
  HelpCircle,
  ChevronRight,
  Bell,
  CheckCheck,
  Award,
  Layers,
  Video,
  User as UserIcon,
  Settings,
  LayoutDashboard,
  Shield,
} from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  navigate: (to: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, navigate }) => {
  const {
    user,
    logout,
    readNotificationIds,
    markNotificationRead,
    markAllNotificationsRead,
  } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, glossaryTerms, notifications } = useContentStore(isAdmin);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const notifRef = useRef<HTMLDivElement>(null);

  // Active published notifications for students
  const activeNotifications = notifications.filter((n) => n.published && !n.archived);
  const unreadNotifications = activeNotifications.filter(
    (n) => !readNotificationIds.includes(n.id)
  );

  // Close notification dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    };
    if (notifOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [notifOpen]);

  // Keyboard shortcut Ctrl+K / Cmd+K or Escape for search modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        if (searchOpen) setSearchOpen(false);
        if (notifOpen) setNotifOpen(false);
        if (mobileMenuOpen) setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [searchOpen, notifOpen, mobileMenuOpen]);

  const handleLogoClick = () => {
    if (user) {
      navigate('/dashboard');
    } else {
      navigate('/');
    }
  };

  const handleNavClick = (to: string) => {
    navigate(to);
    setMobileMenuOpen(false);
    setSearchOpen(false);
    setNotifOpen(false);
  };

  const handleSignOut = () => {
    logout();
    setMobileMenuOpen(false);
    setNotifOpen(false);
    navigate('/');
  };

  // Public Navigation (No Interactive Learning or public Glossary)
  const publicNavLinks = [
    { label: 'Home', path: '/' },
    { label: 'Courses', path: '/courses' },
    { label: 'Live Classes', path: '/live-classes' },
  ];

  // Primary Desktop Student Navigation
  const desktopStudentLinks = [
    { label: 'Dashboard', path: '/dashboard' },
    { label: 'My Courses', path: '/my-courses' },
    { label: 'My Quizzes', path: '/my-quizzes' },
    { label: 'My Flashcards', path: '/flashcards' },
    { label: 'My Live Classes', path: '/my-live-classes' },
    { label: 'Dictionary', path: '/dictionary' },
  ];

  // Full Student Hamburger Navigation Menu (Section 11)
  const studentHamburgerLinks = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'My Courses', path: '/my-courses', icon: BookOpen },
    { label: 'My Quizzes', path: '/my-quizzes', icon: Award },
    { label: 'My Flashcards', path: '/flashcards', icon: Layers },
    { label: 'My Live Classes', path: '/my-live-classes', icon: Video },
    { label: 'Learning History', path: '/history', icon: History },
    { label: 'Dictionary', path: '/dictionary', icon: FileText },
    { label: 'My Profile', path: '/profile', icon: UserIcon },
    { label: 'Settings', path: '/settings', icon: Settings },
  ];

  const activeDesktopLinks = user ? desktopStudentLinks : publicNavLinks;
  const searchResults = searchPlatformContent(
    searchQuery,
    courses,
    user ? glossaryTerms : []
  );
  const totalMatches =
    searchResults.courses.length + searchResults.lessons.length + searchResults.glossary.length;

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#080d1a]/95 backdrop-blur-md border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 gap-3">
            {/* Logo & Motto */}
            <div
              onClick={handleLogoClick}
              className="flex items-center gap-3 cursor-pointer group shrink-0"
              role="button"
              tabIndex={0}
              aria-label="CoinEdu Logo Navigation"
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleLogoClick();
                }
              }}
            >
              <CoinEduLogo size="md" variant="mark" />

              <div>
                <div className="flex items-center gap-2">
                  <CoinEduLogo size="md" variant="wordmark" />
                </div>
                <p className="text-[11px] text-slate-400 font-medium tracking-wide hidden sm:block">
                  Learn Smart. Invest Wise. Grow Together.
                </p>
              </div>
            </div>

            {/* Desktop Nav Items */}
            <nav className="hidden lg:flex items-center gap-1 shrink-0" aria-label="Main Navigation">
              {activeDesktopLinks.map((item) => {
                const isActive = currentPath === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => handleNavClick(item.path)}
                    className={`btn-interactive px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <span>{item.label}</span>
                  </button>
                );
              })}

              {/* If Admin, show Admin Console Link */}
              {user?.role === 'admin' && (
                <button
                  onClick={() => handleNavClick('/admin')}
                  className={`btn-interactive px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                    currentPath.startsWith('/admin')
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-amber-950/60 text-amber-300 border border-amber-800/60 hover:bg-amber-900/60'
                  }`}
                >
                  Admin
                </button>
              )}
            </nav>

            {/* Prominent Expanded Search Bar */}
            <div className="flex-1 max-w-sm sm:max-w-md md:max-w-xl mx-2">
              <button
                type="button"
                onClick={() => setSearchOpen(true)}
                aria-label="Search courses and lessons"
                className="btn-interactive w-full flex items-center justify-between gap-3 px-3.5 py-2 sm:py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900/90 hover:bg-slate-900 border border-slate-700/80 hover:border-cyan-500/50 transition-all shadow-inner cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Search className="w-4 h-4 text-cyan-400 shrink-0 group-hover:scale-110 transition-transform" />
                  <span className="truncate hidden sm:inline text-slate-400 group-hover:text-slate-300">
                    {user
                      ? 'Search courses, lessons, and dictionary...'
                      : 'Search recommended courses and lessons...'}
                  </span>
                  <span className="sm:hidden text-slate-400">Search courses...</span>
                </div>
                <kbd className="hidden sm:inline-flex items-center gap-1 text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800 group-hover:border-slate-700 shrink-0">
                  <span>Ctrl</span>
                  <span>+</span>
                  <span>K</span>
                </kbd>
              </button>
            </div>

            {/* Right Actions: Notifications, Auth & Hamburger Menu */}
            <div className="flex items-center gap-2 shrink-0">
              {/* Student Notification Bell */}
              {user && (
                <div className="relative" ref={notifRef}>
                  <button
                    type="button"
                    onClick={() => setNotifOpen((prev) => !prev)}
                    aria-label="Notifications"
                    data-testid="notification-bell"
                    className="btn-interactive relative p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 cursor-pointer"
                  >
                    <Bell className="w-4 h-4" />
                    {unreadNotifications.length > 0 && (
                      <span
                        data-testid="notification-unread-badge"
                        className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shadow"
                      >
                        {unreadNotifications.length}
                      </span>
                    )}
                  </button>

                  {notifOpen && (
                    <div
                      data-testid="notification-panel"
                      className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#0b1329] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden z-50 animate-fade-in"
                    >
                      <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                        <div>
                          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                            Notifications
                          </h3>
                          <p className="text-[11px] text-slate-400">
                            {unreadNotifications.length > 0
                              ? `${unreadNotifications.length} unread update${unreadNotifications.length === 1 ? '' : 's'}`
                              : 'All caught up'}
                          </p>
                        </div>
                        {unreadNotifications.length > 0 && (
                          <button
                            type="button"
                            onClick={() =>
                              markAllNotificationsRead(activeNotifications.map((n) => n.id))
                            }
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 cursor-pointer"
                          >
                            <CheckCheck className="w-3.5 h-3.5" />
                            Mark all read
                          </button>
                        )}
                      </div>

                      <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/80">
                        {activeNotifications.length === 0 ? (
                          <div className="py-10 px-4 text-center">
                            <Bell className="w-7 h-7 text-slate-600 mx-auto mb-2" />
                            <p className="text-xs font-semibold text-slate-300">
                              No notifications yet.
                            </p>
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              Course updates and live class announcements will appear here.
                            </p>
                          </div>
                        ) : (
                          activeNotifications.map((notif) => {
                            const isRead = readNotificationIds.includes(notif.id);
                            return (
                              <div
                                key={notif.id}
                                className={`p-3.5 transition-colors ${
                                  isRead ? 'bg-transparent' : 'bg-blue-950/30'
                                }`}
                              >
                                <div className="flex items-start justify-between gap-2">
                                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                                    {!isRead && (
                                      <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" />
                                    )}
                                    <span>{notif.title}</span>
                                  </h4>
                                  <span className="text-[10px] font-mono text-slate-500 shrink-0">
                                    {new Date(notif.createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                                  {notif.message}
                                </p>
                                <div className="mt-2.5 flex items-center justify-between gap-2">
                                  {notif.linkPath ? (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        markNotificationRead(notif.id);
                                        handleNavClick(notif.linkPath!);
                                      }}
                                      className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1 cursor-pointer"
                                    >
                                      <span>Open Link</span>
                                      <ChevronRight className="w-3 h-3" />
                                    </button>
                                  ) : (
                                    <span />
                                  )}
                                  {!isRead && (
                                    <button
                                      type="button"
                                      onClick={() => markNotificationRead(notif.id)}
                                      className="text-[11px] font-medium text-slate-400 hover:text-white cursor-pointer"
                                    >
                                      Mark read
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="hidden sm:flex items-center gap-2">
                {!user ? (
                  <>
                    <button
                      onClick={() => handleNavClick('/login')}
                      className="btn-interactive flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/80 cursor-pointer"
                    >
                      <LogIn className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Sign In</span>
                    </button>
                    <button
                      onClick={() => handleNavClick('/signup')}
                      className="btn-interactive flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 cursor-pointer shadow-sm shadow-cyan-500/20"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Sign Up</span>
                    </button>
                  </>
                ) : (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleNavClick('/profile')}
                      className="btn-interactive flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 border border-slate-700 hover:border-slate-600 cursor-pointer"
                    >
                      <div className="w-5 h-5 rounded-md bg-cyan-950 text-cyan-400 flex items-center justify-center font-mono font-bold text-[10px]">
                        {user.name.charAt(0)}
                      </div>
                      <span className="truncate max-w-[100px]">{user.name}</span>
                    </button>

                    <button
                      onClick={handleSignOut}
                      title="Sign Out"
                      aria-label="Sign Out"
                      className="btn-interactive p-2 rounded-xl bg-slate-900 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 border border-slate-700 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              {/* Hamburger Menu Button (Visible on all viewports for signed-in students so all 9 student routes are accessible, and on mobile/tablet for public visitors) */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className={`btn-interactive p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700 cursor-pointer ${
                  user ? '' : 'lg:hidden'
                }`}
                aria-label="Toggle navigation menu"
                aria-expanded={mobileMenuOpen}
                data-testid="hamburger-menu-button"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Drawer / Hamburger Menu */}
        {mobileMenuOpen && (
          <div
            data-testid="hamburger-menu-drawer"
            className="border-b border-slate-800 bg-[#0b1329]/98 px-4 pt-3 pb-6 space-y-1.5 animate-fade-in max-w-7xl mx-auto"
          >
            {user ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5">
                {studentHamburgerLinks.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentPath === item.path;
                  return (
                    <button
                      key={item.path}
                      onClick={() => handleNavClick(item.path)}
                      className={`btn-interactive w-full text-left px-3.5 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-3 cursor-pointer ${
                        isActive
                          ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30'
                          : 'text-slate-300 hover:bg-slate-800/50'
                      }`}
                    >
                      <Icon className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}

                {user.role === 'admin' && (
                  <button
                    onClick={() => handleNavClick('/admin')}
                    className="btn-interactive w-full text-left px-3.5 py-2.5 rounded-xl text-sm font-bold bg-amber-950/80 text-amber-300 border border-amber-800 flex items-center gap-3 cursor-pointer"
                  >
                    <Shield className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Admin Console</span>
                  </button>
                )}
              </div>
            ) : (
              publicNavLinks.map((item) => {
                const isActive = currentPath === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => handleNavClick(item.path)}
                    className={`btn-interactive w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-semibold flex items-center justify-between cursor-pointer ${
                      isActive
                        ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    <span>{item.label}</span>
                  </button>
                );
              })
            )}

            <div className="pt-3 border-t border-slate-800 space-y-2">
              {!user ? (
                <div className="flex gap-2">
                  <button
                    onClick={() => handleNavClick('/login')}
                    className="btn-interactive flex-1 py-2.5 text-center rounded-xl bg-slate-800 text-slate-200 text-xs font-bold cursor-pointer"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => handleNavClick('/signup')}
                    className="btn-interactive flex-1 py-2.5 text-center rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold cursor-pointer"
                  >
                    Sign Up
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => handleNavClick('/profile')}
                    className="text-xs font-semibold text-cyan-300 cursor-pointer"
                  >
                    Signed in as: <strong>{user.name}</strong>
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="text-xs font-bold text-rose-400 hover:underline cursor-pointer"
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Global Search Modal */}
      {searchOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-start justify-center pt-16 sm:pt-24 p-4"
          onClick={() => setSearchOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Search CoinEdu"
        >
          <div
            className="bg-[#0b1329] border border-slate-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-modal-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-800">
              <Search className="w-5 h-5 text-cyan-400 shrink-0" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  user
                    ? 'Search courses, lessons, or dictionary words...'
                    : 'Search recommended courses or lessons...'
                }
                aria-label="Search CoinEdu"
                className="w-full bg-transparent text-sm text-white placeholder-slate-400 focus:outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded cursor-pointer"
                >
                  Clear
                </button>
              )}
              <button
                onClick={() => setSearchOpen(false)}
                aria-label="Close search dialog"
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-[65vh] overflow-y-auto p-4 space-y-5">
              {!searchQuery.trim() ? (
                <div className="space-y-4">
                  <p className="text-xs text-slate-400">
                    Type any keyword above to search across available courses and lessons.
                  </p>
                  <div>
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 block mb-2">
                      Quick Destinations
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        onClick={() => handleNavClick('/courses')}
                        className="btn-interactive flex items-center justify-between p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 cursor-pointer"
                      >
                        <span className="flex items-center gap-2 font-semibold">
                          <BookOpen className="w-4 h-4 text-cyan-400" />
                          Recommended Courses
                        </span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                      </button>
                      <button
                        onClick={() => handleNavClick('/live-classes')}
                        className="btn-interactive flex items-center justify-between p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 cursor-pointer"
                      >
                        <span className="flex items-center gap-2 font-semibold">
                          <Video className="w-4 h-4 text-emerald-400" />
                          Live Classes
                        </span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                      </button>
                      {user && (
                        <button
                          onClick={() => handleNavClick('/dictionary')}
                          className="btn-interactive flex items-center justify-between p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 cursor-pointer"
                        >
                          <span className="flex items-center gap-2 font-semibold">
                            <FileText className="w-4 h-4 text-amber-400" />
                            Dictionary
                          </span>
                          <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                        </button>
                      )}
                      <button
                        onClick={() => handleNavClick('/faq')}
                        className="btn-interactive flex items-center justify-between p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 cursor-pointer"
                      >
                        <span className="flex items-center gap-2 font-semibold">
                          <HelpCircle className="w-4 h-4 text-cyan-400" />
                          FAQ & Beginner Help
                        </span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                      </button>
                    </div>
                  </div>
                </div>
              ) : totalMatches === 0 ? (
                <div className="py-10 text-center">
                  <p className="text-sm font-bold text-white mb-1">
                    No matching items found for "{searchQuery}"
                  </p>
                  <p className="text-xs text-slate-400">
                    Courses, lessons, and dictionary definitions added by the administrator will appear in search results once published.
                  </p>
                </div>
              ) : (
                <div className="space-y-5">
                  {searchResults.courses.length > 0 && (
                    <div>
                      <h4 className="text-xs font-mono uppercase tracking-wider text-cyan-400 mb-2">
                        Courses ({searchResults.courses.length})
                      </h4>
                      <div className="space-y-2">
                        {searchResults.courses.map((c) => (
                          <button
                            key={c.slug}
                            onClick={() => handleNavClick(`/courses/${c.slug}`)}
                            className="w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-between gap-3 cursor-pointer"
                          >
                            <div>
                              <p className="text-xs font-bold text-white">{c.title}</p>
                              <p className="text-[11px] text-slate-400 line-clamp-1">
                                {c.description}
                              </p>
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono shrink-0">
                              {c.level} · {c.durationWeeks}w
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {searchResults.lessons.length > 0 && (
                    <div>
                      <h4 className="text-xs font-mono uppercase tracking-wider text-amber-400 mb-2">
                        Lessons ({searchResults.lessons.length})
                      </h4>
                      <div className="space-y-2">
                        {searchResults.lessons.map(({ lesson, courseTitle }) => (
                          <button
                            key={lesson.lessonId}
                            onClick={() => handleNavClick(`/learn/${lesson.lessonId}`)}
                            className="w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-between gap-3 cursor-pointer"
                          >
                            <div>
                              <p className="text-xs font-bold text-white">{lesson.title}</p>
                              <p className="text-[11px] text-slate-400">In course: {courseTitle}</p>
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono shrink-0">
                              {lesson.durationMinutes}m
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {user && searchResults.glossary.length > 0 && (
                    <div>
                      <h4 className="text-xs font-mono uppercase tracking-wider text-emerald-400 mb-2">
                        Dictionary ({searchResults.glossary.length})
                      </h4>
                      <div className="space-y-2">
                        {searchResults.glossary.map((g) => (
                          <button
                            key={g.term}
                            onClick={() => handleNavClick('/dictionary')}
                            className="w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 cursor-pointer"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-white">{g.term}</span>
                              <span className="text-[10px] font-mono text-slate-400">
                                {g.category}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 line-clamp-2">{g.shortDef}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
