import React, { useState, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { useContentStore, GlossaryItem } from '../data/learningPlatform';
import { Search, HelpCircle, AlertTriangle, Lightbulb, Plus, BookOpen } from 'lucide-react';

interface GlossarySectionProps {
  navigate?: (to: string) => void;
}

export const GlossarySection: React.FC<GlossarySectionProps> = ({ navigate }) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { glossaryTerms } = useContentStore(isAdmin);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Blockchain', 'DeFi', 'Security', 'Trading', 'Macroeconomics'];

  const filteredTerms = useMemo(() => {
    return glossaryTerms.filter((item) => {
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const matchesSearch =
        item.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.shortDef.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.fullDef.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [glossaryTerms, searchQuery, selectedCategory]);

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-amber-950/60 border border-amber-800/40 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Student Crypto Reference</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Dictionary
          </h1>
          <p className="mt-2 text-slate-300 text-sm sm:text-base max-w-3xl leading-relaxed">
            Cryptocurrency, blockchain, and security terms explained in clear, everyday English. Each definition includes a practical real-world example and a common mistake to avoid.
          </p>
        </div>

        {isAdmin && navigate && (
          <button
            onClick={() => navigate('/admin/glossary')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md shadow-amber-400/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Dictionary Term</span>
          </button>
        )}
      </div>

      {glossaryTerms.length === 0 ? (
        // Exact empty state
        <div className="text-center py-20 bg-[#0b1329] rounded-2xl border border-slate-800 p-8 max-w-2xl mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-amber-950/50 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto mb-4">
            <BookOpen className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">No dictionary terms available yet.</h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-6">
            Dictionary definitions will appear here once added and published by an administrator.
          </p>
          {isAdmin && navigate && (
            <button
              onClick={() => navigate('/admin/glossary')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Dictionary Term</span>
            </button>
          )}
        </div>
      ) : (
        <>
          {/* Filter and Search Bar */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            {/* Search Input */}
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Search words (e.g. Seed phrase, Volatility, Consensus, Liquidity)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700/80 rounded-xl text-white text-sm placeholder-slate-400 focus:outline-none focus:border-cyan-400 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs text-slate-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1.5 items-center">
              {categories.map((cat) => {
                const isActive = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                        : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Results Count */}
          <div className="text-xs text-slate-400 mb-6 font-mono">
            Showing {filteredTerms.length} of {glossaryTerms.length} words
          </div>

          {/* Glossary Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredTerms.map((item) => (
              <div
                key={item.term}
                className="bg-[#0b1329] border border-slate-800 hover:border-slate-700 rounded-2xl p-6 transition-all shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                      {item.term}
                    </h3>
                    <div className="flex items-center gap-2">
                      {isAdmin && (
                        <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded ${
                          item.published
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {item.published ? 'Published' : 'Draft'}
                        </span>
                      )}
                      <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                        {item.category}
                      </span>
                    </div>
                  </div>

                  <p className="text-sm text-slate-300 font-medium leading-relaxed mb-3">
                    {item.shortDef}
                  </p>

                  <p className="text-xs text-slate-400 leading-relaxed mb-4">
                    {item.fullDef}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-800/80">
                  {/* Real World Analogy */}
                  {item.realWorldAnalogy && (
                    <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300">
                      <Lightbulb className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-cyan-300">Everyday Example: </strong>
                        <span>{item.realWorldAnalogy}</span>
                      </div>
                    </div>
                  )}

                  {/* Beginner Pitfall */}
                  {item.beginnerPitfall && (
                    <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-950/20 border border-amber-900/40 text-xs text-amber-200">
                      <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-amber-300">Common Mistake to Avoid: </strong>
                        <span>{item.beginnerPitfall}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filteredTerms.length === 0 && (
            <div className="text-center py-16 bg-slate-900/40 rounded-2xl border border-slate-800">
              <HelpCircle className="w-10 h-10 text-slate-500 mx-auto mb-3" />
              <p className="text-base font-semibold text-white">No matching words found</p>
              <p className="text-xs text-slate-400 mt-1">Try clearing your search words or selecting "All" categories.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
};
