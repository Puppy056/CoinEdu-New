import React from 'react';
import { CoinEduLogo } from './CoinEduLogo';

interface FooterProps {
  navigate: (to: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigate }) => {
  return (
    <footer className="bg-[#050811] border-t border-slate-800/80 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-slate-800/70">
          {/* Brand & Motto */}
          <div className="md:col-span-5 space-y-3">
            <CoinEduLogo size="md" variant="full" />

            <p className="text-xs font-semibold text-amber-300">
              “Learn Smart. Invest Wise. Grow Together.”
            </p>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Helping everyday learners in India understand cryptocurrency, how blockchain works, and how to protect their money safely from scams.
            </p>
          </div>

          {/* Platform Navigation: Simple everyday words */}
          <div className="md:col-span-4 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">
              Learning Sections
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => navigate('/courses')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Recommended Courses
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/live-classes')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Live Classes (How sessions work)
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/login')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Student Sign In
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/signup')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Create Student Account
                </button>
              </li>
            </ul>
          </div>

          {/* Institutional & Legal */}
          <div className="md:col-span-3 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">
              Support & Legal
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => navigate('/faq')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  FAQ & Beginner Help
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/about')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  About CoinEdu
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/contact')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Contact & Feedback
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/privacy')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Privacy & Data Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/terms')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Terms of Service
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/disclaimer')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Educational Disclaimer
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <div className="pt-6 space-y-3">
          <p className="text-[11px] text-slate-400 leading-relaxed">
            <strong>Educational Disclaimer: </strong>
            CoinEdu is strictly an educational platform. Nothing on this website is financial, investment, legal, or tax advice. We never promise investment returns or suggest that any cryptocurrency is guaranteed to be profitable. Cryptocurrency prices go up and down quickly, and there is a real risk of losing money. Never invest money that you cannot afford to lose.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 pt-2">
            <p>© {new Date().getFullYear()} CoinEdu. All rights reserved.</p>
            <p className="text-slate-500">Motto: Learn Smart. Invest Wise. Grow Together.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};
