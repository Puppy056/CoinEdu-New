import React, { useState, useEffect } from 'react';
import { COURSE_TRACKS, CourseTrack, Module } from '../data/courses';
import { CheckCircle2, ChevronRight, Clock, HelpCircle, ArrowLeft, Award, BookOpen } from 'lucide-react';

export const CourseViewer: React.FC = () => {
  const [selectedTrackId, setSelectedTrackId] = useState<string>(COURSE_TRACKS[0]?.id || '');
  const [activeModuleId, setActiveModuleId] = useState<string | null>(null);
  
  // Interactive quiz state
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [completedModules, setCompletedModules] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('coinedu_completed_modules');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const activeTrack = COURSE_TRACKS.find(t => t.id === selectedTrackId) || COURSE_TRACKS[0];
  const activeModule = activeTrack?.modules?.find(m => m.id === activeModuleId);

  useEffect(() => {
    try {
      localStorage.setItem('coinedu_completed_modules', JSON.stringify(completedModules));
    } catch (e) {
      console.warn('Could not save progress to localStorage', e);
    }
  }, [completedModules]);

  if (!COURSE_TRACKS || COURSE_TRACKS.length === 0) {
    return (
      <div className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="w-16 h-16 rounded-2xl bg-cyan-950/50 border border-cyan-800/40 flex items-center justify-center text-cyan-400 mx-auto mb-4">
          <BookOpen className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">No courses available yet.</h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
          Courses created by administrators will appear here once published.
        </p>
      </div>
    );
  }

  const handleOpenModule = (mod: Module) => {
    setActiveModuleId(mod.id);
    setSelectedQuizOption(null);
    setQuizSubmitted(false);
    window.scrollTo({ top: 120, behavior: 'smooth' });
  };

  const handleQuizSubmit = () => {
    if (selectedQuizOption === null || !activeModule) return;
    setQuizSubmitted(true);
    if (selectedQuizOption === activeModule.quiz.correctIndex) {
      if (!completedModules.includes(activeModule.id)) {
        setCompletedModules(prev => [...prev, activeModule.id]);
      }
    }
  };

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-cyan-950/60 border border-cyan-800/40 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Structured Learning</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Courses for Beginners & Beyond
        </h2>
        <p className="mt-2 text-slate-300 text-sm sm:text-base max-w-3xl leading-relaxed">
          Step-by-step courses designed to help you understand cryptocurrency and blockchain with clear examples and everyday language. Test your knowledge as you complete each section.
        </p>
      </div>

      {/* Track Selector Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        {COURSE_TRACKS.map((track) => {
          const isSelected = track.id === selectedTrackId;
          const completedCount = track.modules.filter(m => completedModules.includes(m.id)).length;
          const isFinished = completedCount === track.modules.length;

          return (
            <button
              key={track.id}
              onClick={() => {
                setSelectedTrackId(track.id);
                setActiveModuleId(null);
              }}
              className={`text-left p-4 rounded-xl border transition-all cursor-pointer relative overflow-hidden ${
                isSelected
                  ? 'bg-gradient-to-b from-slate-800 to-slate-900 border-cyan-500/50 shadow-md shadow-cyan-500/10'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                  track.level === 'Beginner' ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' :
                  track.level === 'Intermediate' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                  'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  {track.level}
                </span>
                {isFinished && (
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Completed
                  </span>
                )}
              </div>
              <h3 className={`font-bold text-sm sm:text-base leading-snug ${isSelected ? 'text-cyan-300' : 'text-white'}`}>
                {track.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                {track.description}
              </p>
              <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/80">
                <span>{track.modules.length} Sections</span>
                <span>{completedCount}/{track.modules.length} Completed</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Section Reader or Sections List */}
      {activeModule ? (
        /* Detailed Section Reader */
        <div className="bg-[#0b1329] border border-cyan-500/30 rounded-2xl p-6 sm:p-10 shadow-xl relative animate-fade-in">
          
          <button
            onClick={() => setActiveModuleId(null)}
            className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 mb-6 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Course Sections</span>
          </button>

          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mb-2">
            <span className="font-mono text-cyan-400 uppercase">{activeTrack.title}</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              {activeModule.estimatedMinutes} min read
            </span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-4">
            {activeModule.title}
          </h3>

          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-cyan-200 text-sm mb-8 leading-relaxed">
            <strong className="text-cyan-300 block mb-1">What you will learn:</strong>
            {activeModule.summary}
          </div>

          {/* Sections */}
          <div className="space-y-8">
            {activeModule.sections.map((sec, idx) => (
              <div key={idx} className="space-y-3">
                <h4 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-slate-800 text-cyan-400 text-xs flex items-center justify-center font-mono">
                    {idx + 1}
                  </span>
                  {sec.heading}
                </h4>
                <div className="space-y-2 text-slate-300 leading-relaxed text-sm sm:text-base">
                  {sec.content.map((p, pIdx) => (
                    <p key={pIdx}>{p}</p>
                  ))}
                </div>
                {sec.keyTakeaway && (
                  <div className="mt-4 p-3.5 rounded-lg bg-amber-950/20 border-l-4 border-amber-400 text-amber-200 text-xs sm:text-sm">
                    <strong className="text-amber-300">Important Takeaway: </strong>
                    {sec.keyTakeaway}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Test Your Knowledge */}
          <div className="mt-12 pt-8 border-t border-slate-800">
            <div className="flex items-center gap-2 mb-3">
              <Award className="w-5 h-5 text-amber-400" />
              <h4 className="text-base sm:text-lg font-bold text-white">
                Test Your Knowledge
              </h4>
            </div>
            <p className="text-sm text-slate-300 font-medium mb-4">
              {activeModule.quiz.question}
            </p>

            <div className="space-y-2.5 max-w-2xl mb-4">
              {activeModule.quiz.options.map((option, optIdx) => {
                const isSelected = selectedQuizOption === optIdx;
                let optionStyle = 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-200';
                
                if (quizSubmitted) {
                  if (optIdx === activeModule.quiz.correctIndex) {
                    optionStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200';
                  } else if (isSelected) {
                    optionStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                  }
                } else if (isSelected) {
                  optionStyle = 'bg-cyan-950/70 border-cyan-500 text-cyan-200';
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => {
                      if (!quizSubmitted) setSelectedQuizOption(optIdx);
                    }}
                    disabled={quizSubmitted}
                    className={`w-full text-left p-3.5 rounded-xl border text-sm font-medium transition-all flex items-center justify-between cursor-pointer ${optionStyle}`}
                  >
                    <span>{option}</span>
                    {quizSubmitted && optIdx === activeModule.quiz.correctIndex && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {!quizSubmitted ? (
              <button
                onClick={handleQuizSubmit}
                disabled={selectedQuizOption === null}
                className="px-5 py-2.5 rounded-xl text-sm font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-md shadow-cyan-500/20"
              >
                Submit Answer
              </button>
            ) : (
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 max-w-2xl mt-4">
                <p className={`text-sm font-bold mb-1 ${
                  selectedQuizOption === activeModule.quiz.correctIndex ? 'text-emerald-400' : 'text-amber-400'
                }`}>
                  {selectedQuizOption === activeModule.quiz.correctIndex ? 'Correct! Good job.' : 'Not quite right.'}
                </p>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {activeModule.quiz.explanation}
                </p>
                {selectedQuizOption !== activeModule.quiz.correctIndex && (
                  <button
                    onClick={() => {
                      setQuizSubmitted(false);
                      setSelectedQuizOption(null);
                    }}
                    className="mt-3 text-xs font-semibold text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                  >
                    Try again
                  </button>
                )}
              </div>
            )}

          </div>

        </div>
      ) : (
        /* Sections Grid for selected track */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeTrack.modules.map((mod, index) => {
            const isDone = completedModules.includes(mod.id);
            return (
              <div
                key={mod.id}
                className="bg-slate-900/70 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-6 transition-all group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-900/60">
                      Section {index + 1}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-slate-400">
                      <Clock className="w-3.5 h-3.5" />
                      {mod.estimatedMinutes} min
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors mb-2">
                    {mod.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-4">
                    {mod.summary}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {isDone ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-md border border-emerald-800/50">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed
                      </span>
                    ) : (
                      <span className="text-xs text-slate-500">Not completed</span>
                    )}
                  </div>

                  <button
                    onClick={() => handleOpenModule(mod)}
                    className="flex items-center gap-1 text-xs font-semibold text-cyan-400 group-hover:text-cyan-300 cursor-pointer bg-slate-800 hover:bg-slate-750 px-3 py-1.5 rounded-lg border border-slate-700"
                  >
                    <span>{isDone ? 'Review' : 'Start Reading'}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
