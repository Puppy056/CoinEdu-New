import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  AlertCircle,
  Loader2,
  RotateCcw,
  Captions,
} from 'lucide-react';

interface VideoLessonPlayerProps {
  lessonId: string;
  title: string;
  videoUrl?: string;
  subtitleUrl?: string;
  initialTimeSeconds?: number;
  onSaveProgressSeconds?: (seconds: number) => void;
  onVideoEnded?: () => void;
}

const PLAYBACK_RATES = [0.75, 1, 1.25, 1.5, 2] as const;

function formatSeconds(secs: number): string {
  if (!Number.isFinite(secs) || secs < 0) return '0:00';
  const total = Math.floor(secs);
  const mins = Math.floor(total / 60);
  const rem = total % 60;
  return `${mins}:${rem < 10 ? '0' : ''}${rem}`;
}

export const VideoLessonPlayer: React.FC<VideoLessonPlayerProps> = ({
  lessonId,
  title,
  videoUrl,
  subtitleUrl,
  initialTimeSeconds = 0,
  onSaveProgressSeconds,
  onVideoEnded,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [resumedBanner, setResumedBanner] = useState<number | null>(null);
  const [captionsEnabled, setCaptionsEnabled] = useState(true);

  const isEmbedUrl =
    Boolean(videoUrl) &&
    (videoUrl!.includes('youtube.com/embed') ||
      videoUrl!.includes('player.vimeo.com') ||
      videoUrl!.includes('youtu.be'));

  useEffect(() => {
    setIsPlaying(false);
    setCurrentTime(0);
    setDuration(0);
    setHasError(false);
    setIsLoading(Boolean(videoUrl) && !isEmbedUrl);
    setResumedBanner(null);
  }, [lessonId, videoUrl, isEmbedUrl]);

  const handleLoadedMetadata = () => {
    const v = videoRef.current;
    if (!v) return;
    setDuration(v.duration || 0);
    setIsLoading(false);
    if (initialTimeSeconds > 5 && initialTimeSeconds < (v.duration || Infinity) - 5) {
      try {
        v.currentTime = initialTimeSeconds;
        setCurrentTime(initialTimeSeconds);
        setResumedBanner(initialTimeSeconds);
      } catch {}
    }
  };

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play()
        .then(() => setIsPlaying(true))
        .catch(() => setHasError(true));
    } else {
      v.pause();
      setIsPlaying(false);
    }
  };

  const handleTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    setCurrentTime(v.currentTime);
    if (onSaveProgressSeconds && Math.floor(v.currentTime) % 3 === 0) {
      onSaveProgressSeconds(v.currentTime);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = videoRef.current;
    const nextTime = Number(e.target.value);
    setCurrentTime(nextTime);
    if (v) {
      v.currentTime = nextTime;
    }
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    const nextMuted = !isMuted;
    v.muted = nextMuted;
    setIsMuted(nextMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = videoRef.current;
    const nextVol = Number(e.target.value);
    setVolume(nextVol);
    if (v) {
      v.volume = nextVol;
      v.muted = nextVol === 0;
      setIsMuted(nextVol === 0);
    }
  };

  const cyclePlaybackRate = () => {
    const v = videoRef.current;
    const idx = PLAYBACK_RATES.indexOf(playbackRate as any);
    const nextRate = PLAYBACK_RATES[(idx + 1) % PLAYBACK_RATES.length];
    setPlaybackRate(nextRate);
    if (v) {
      v.playbackRate = nextRate;
    }
  };

  const toggleFullscreen = async () => {
    if (!wrapperRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await wrapperRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      setIsFullscreen((prev) => !prev);
    }
  };

  const restartFromBeginning = () => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = 0;
    setCurrentTime(0);
    setResumedBanner(null);
  };

  if (!videoUrl || !videoUrl.trim()) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-8 text-center my-6">
        <AlertCircle className="w-10 h-10 text-amber-600 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-900 mb-1">Video Stream Not Configured</h3>
        <p className="text-sm text-slate-600 max-w-md mx-auto">
          The video source for this lesson has not been uploaded yet. Please review the lesson summary below.
        </p>
      </div>
    );
  }

  if (isEmbedUrl) {
    return (
      <div
        data-testid="video-lesson-player"
        className="my-6 rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 shadow-xl"
      >
        <div className="aspect-video w-full">
          <iframe
            src={videoUrl}
            title={title}
            className="w-full h-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div>
    );
  }

  return (
    <div
      ref={wrapperRef}
      data-testid="video-lesson-player"
      className={`bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'my-6'
      }`}
    >
      {/* Resume Notification Bar */}
      {resumedBanner !== null && (
        <div className="bg-blue-950/90 border-b border-blue-800/60 px-4 py-2 flex items-center justify-between text-xs text-blue-200">
          <span>Resumed from your last watched position ({formatSeconds(resumedBanner)})</span>
          <button
            type="button"
            onClick={restartFromBeginning}
            className="inline-flex items-center gap-1 font-bold text-white hover:text-blue-300 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Start Over
          </button>
        </div>
      )}

      {/* Video Surface */}
      <div className="relative aspect-video w-full bg-black flex items-center justify-center">
        {isLoading && !hasError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/80 z-10 text-white">
            <Loader2 className="w-8 h-8 text-blue-400 animate-spin mb-2" />
            <span className="text-xs text-slate-300 font-medium">Loading lesson video...</span>
          </div>
        )}

        {hasError ? (
          <div className="p-8 text-center text-white max-w-md">
            <AlertCircle className="w-10 h-10 text-rose-400 mx-auto mb-3" />
            <h4 className="font-bold text-base mb-1">Unable to Play Video</h4>
            <p className="text-xs text-slate-400">
              The video stream could not be loaded. Please check your connection or try refreshing the page.
            </p>
          </div>
        ) : (
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-full object-contain cursor-pointer"
            playsInline
            onClick={togglePlay}
            onLoadedMetadata={handleLoadedMetadata}
            onTimeUpdate={handleTimeUpdate}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => {
              setIsPlaying(false);
              if (onVideoEnded) onVideoEnded();
            }}
            onError={() => {
              setIsLoading(false);
              setHasError(true);
            }}
          >
            {subtitleUrl && captionsEnabled && (
              <track kind="subtitles" src={subtitleUrl} srcLang="en" label="English" default />
            )}
          </video>
        )}
      </div>

      {/* Custom Accessible Player Controls */}
      <div className="bg-slate-900 border-t border-slate-800 px-4 py-3 space-y-2.5 text-slate-200">
        {/* Seek Timeline */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-400 min-w-[2.5rem]">
            {formatSeconds(currentTime)}
          </span>
          <input
            type="range"
            min={0}
            max={duration > 0 ? duration : 100}
            step={0.5}
            value={currentTime}
            onChange={handleSeek}
            aria-label="Seek timeline"
            className="flex-1 h-1.5 bg-slate-700 rounded-lg accent-blue-500 cursor-pointer"
          />
          <span className="text-xs font-mono text-slate-400 min-w-[2.5rem] text-right">
            {formatSeconds(duration)}
          </span>
        </div>

        {/* Bottom Control Row */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={togglePlay}
              disabled={hasError}
              aria-label={isPlaying ? 'Pause' : 'Play'}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-xs font-bold text-white transition-colors cursor-pointer"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3.5 h-3.5" /> Pause
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" /> Play
                </>
              )}
            </button>

            {/* Volume Control */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleMute}
                aria-label={isMuted ? 'Unmute' : 'Mute'}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                aria-label="Volume"
                className="w-20 h-1.5 bg-slate-700 rounded-lg accent-blue-500 cursor-pointer hidden sm:block"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Playback Speed */}
            <button
              type="button"
              onClick={cyclePlaybackRate}
              aria-label="Playback speed"
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-200 transition-colors cursor-pointer"
            >
              Speed: {playbackRate}x
            </button>

            {/* Subtitles toggle if subtitleUrl exists */}
            {subtitleUrl && (
              <button
                type="button"
                onClick={() => setCaptionsEnabled((prev) => !prev)}
                aria-label="Toggle captions"
                className={`p-1.5 rounded-lg border text-xs font-bold transition-colors cursor-pointer ${
                  captionsEnabled
                    ? 'bg-blue-600/20 border-blue-500/40 text-blue-300'
                    : 'bg-slate-800 border-slate-700 text-slate-400'
                }`}
              >
                <Captions className="w-4 h-4" />
              </button>
            )}

            {/* Full Screen */}
            <button
              type="button"
              onClick={toggleFullscreen}
              aria-label={isFullscreen ? 'Exit full screen' : 'Full screen'}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
            >
              {isFullscreen ? (
                <Minimize2 className="w-3.5 h-3.5" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
              <span className="hidden sm:inline">{isFullscreen ? 'Exit' : 'Full Screen'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
