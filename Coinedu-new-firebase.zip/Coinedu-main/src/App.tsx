/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { useRouter } from './router/useRouter';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Public Pages
import {
  HomePage,
  CoursesCataloguePage,
  CourseDetailPage,
  LiveClassesPage,
  GlossaryPage,
  FaqHelpPage,
  AboutPage,
  ContactPage,
  PrivacyPage,
  TermsPage,
  DisclaimerPage,
} from './pages/public/PublicPages';

// Auth Pages
import {
  LoginPage,
  SignupPage,
  ForgotPasswordPage,
  ResetPasswordCompletePage,
} from './pages/public/AuthPages';

// Student Pages
import {
  StudentDashboardPage,
  MyCoursesPage,
  MyQuizzesPage,
  MyLiveClassesPage,
  LessonViewPage,
  QuizTakePage,
  QuizResultsPage,
  FlashcardsPage,
  FlashcardStudyPage,
  LearningHistoryPage,
  ProfilePage,
  SettingsPage,
} from './pages/student/StudentPages';

// Admin Pages
import { AdminPage } from './pages/admin/AdminPages';

// 404 Page
import { NotFoundPage } from './pages/NotFoundPage';

function AppContent() {
  const { user, isLoading } = useAuth();
  const { currentPath, currentRoute, navigate } = useRouter();

  // Check if URL has Firebase password reset action query (?mode=resetPassword&oobCode=...)
  const searchParams =
    typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
  const isPasswordResetActionUrl =
    searchParams?.get('mode') === 'resetPassword' && Boolean(searchParams?.get('oobCode'));

  // Navigation Rules & Legacy Route Redirects
  useEffect(() => {
    if (isPasswordResetActionUrl) return;

    if (currentRoute.name === 'legacy-glossary') {
      navigate('/dictionary');
      return;
    }
    if (currentRoute.name === 'legacy-interactive-learning') {
      navigate('/courses');
      return;
    }
    if (currentRoute.name === 'legacy-bookmarks') {
      navigate(user ? '/dashboard' : '/');
      return;
    }

    if (
      !isLoading &&
      user &&
      (currentPath === '/' || currentPath === '/login' || currentPath === '/signup')
    ) {
      navigate('/dashboard');
    }
  }, [user, currentPath, currentRoute.name, isLoading, navigate, isPasswordResetActionUrl]);

  // Protected Route Guard for Student Pages
  const renderProtectedRoute = (element: React.ReactNode) => {
    if (isLoading) {
      return (
        <div className="py-24 text-center">
          <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-mono text-slate-400">Loading CoinEdu portal...</p>
        </div>
      );
    }
    if (!user) {
      return (
        <div className="py-24 text-center max-w-md mx-auto px-4">
          <h2 className="text-2xl font-bold text-white mb-2">Student Authentication Required</h2>
          <p className="text-xs sm:text-sm text-slate-400 mb-6">
            Please sign in to access your course materials, quizzes, dictionary, and learning dashboard.
          </p>
          <button
            onClick={() => navigate('/login')}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs btn-interactive cursor-pointer"
          >
            Sign In to Continue
          </button>
        </div>
      );
    }
    return element;
  };

  const renderCurrentRoute = () => {
    if (isPasswordResetActionUrl) {
      return <ResetPasswordCompletePage navigate={navigate} />;
    }

    switch (currentRoute.name) {
      // 1. Public Pages
      case 'home':
        if (user) return renderProtectedRoute(<StudentDashboardPage navigate={navigate} />);
        return <HomePage navigate={navigate} />;
      case 'courses':
        return <CoursesCataloguePage navigate={navigate} />;
      case 'course-detail':
        return <CourseDetailPage slug={currentRoute.slug} navigate={navigate} />;
      case 'live-classes':
        return <LiveClassesPage navigate={navigate} />;
      case 'faq':
        return <FaqHelpPage navigate={navigate} />;
      case 'about':
        return <AboutPage navigate={navigate} />;
      case 'contact':
        return <ContactPage navigate={navigate} />;
      case 'login':
        if (user) return renderProtectedRoute(<StudentDashboardPage navigate={navigate} />);
        return <LoginPage navigate={navigate} />;
      case 'signup':
        if (user) return renderProtectedRoute(<StudentDashboardPage navigate={navigate} />);
        return <SignupPage navigate={navigate} />;
      case 'forgot-password':
        return <ForgotPasswordPage navigate={navigate} />;
      case 'reset-password':
        return <ResetPasswordCompletePage navigate={navigate} />;
      case 'privacy':
        return <PrivacyPage />;
      case 'terms':
        return <TermsPage />;
      case 'disclaimer':
        return <DisclaimerPage />;

      // 2. Student Pages (Protected)
      case 'dashboard':
        return renderProtectedRoute(<StudentDashboardPage navigate={navigate} />);
      case 'my-courses':
        return renderProtectedRoute(<MyCoursesPage navigate={navigate} />);
      case 'my-quizzes':
        return renderProtectedRoute(<MyQuizzesPage navigate={navigate} />);
      case 'my-live-classes':
        return renderProtectedRoute(<MyLiveClassesPage navigate={navigate} />);
      case 'dictionary':
      case 'legacy-glossary':
        return renderProtectedRoute(<GlossaryPage navigate={navigate} />);
      case 'learn':
        return renderProtectedRoute(
          <LessonViewPage lessonId={currentRoute.lessonId} navigate={navigate} />
        );
      case 'quiz':
        return renderProtectedRoute(
          <QuizTakePage quizId={currentRoute.quizId} navigate={navigate} />
        );
      case 'quiz-results':
        return renderProtectedRoute(
          <QuizResultsPage
            quizId={currentRoute.quizId}
            attemptId={currentRoute.attemptId}
            navigate={navigate}
          />
        );
      case 'flashcards':
        return renderProtectedRoute(<FlashcardsPage navigate={navigate} />);
      case 'flashcards-study':
        return renderProtectedRoute(
          <FlashcardStudyPage setId={currentRoute.setId} navigate={navigate} />
        );
      case 'history':
        return renderProtectedRoute(<LearningHistoryPage navigate={navigate} />);
      case 'profile':
        return renderProtectedRoute(<ProfilePage navigate={navigate} />);
      case 'settings':
        return renderProtectedRoute(<SettingsPage navigate={navigate} />);

      // Legacy Redirect Fallbacks
      case 'legacy-interactive-learning':
        return <CoursesCataloguePage navigate={navigate} />;
      case 'legacy-bookmarks':
        return user ? (
          renderProtectedRoute(<StudentDashboardPage navigate={navigate} />)
        ) : (
          <HomePage navigate={navigate} />
        );

      // 3. Admin Pages (Enforces server-verified admin role)
      case 'admin':
        return <AdminPage navigate={navigate} subroute="overview" />;
      case 'admin-courses':
        return <AdminPage navigate={navigate} subroute="courses" />;
      case 'admin-lessons':
        return <AdminPage navigate={navigate} subroute="lessons" />;
      case 'admin-quizzes':
        return <AdminPage navigate={navigate} subroute="quizzes" />;
      case 'admin-flashcards':
        return <AdminPage navigate={navigate} subroute="flashcards" />;
      case 'admin-live-classes':
        return <AdminPage navigate={navigate} subroute="live-classes" />;
      case 'admin-glossary':
        return <AdminPage navigate={navigate} subroute="glossary" />;
      case 'admin-notifications':
        return <AdminPage navigate={navigate} subroute="notifications" />;
      case 'admin-students':
        return <AdminPage navigate={navigate} subroute="students" />;

      // 4. 404 Fallback
      case 'not-found':
      default:
        return <NotFoundPage path={currentRoute.path} navigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#080d1a] text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      <Navbar currentPath={currentPath} navigate={navigate} />

      <main className="flex-1">{renderCurrentRoute()}</main>

      <Footer navigate={navigate} />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
