export interface GlossaryItem {
  term: string;
  category: 'Blockchain' | 'DeFi' | 'Security' | 'Trading' | 'Macroeconomics';
  shortDef: string;
  fullDef: string;
  realWorldAnalogy: string;
  beginnerPitfall: string;
  published?: boolean;
}

// Clean unseeded glossary terms: all educational content added manually by admin
export const GLOSSARY_TERMS: GlossaryItem[] = [];
