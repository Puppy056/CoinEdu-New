/**
 * CoinEdu Learning Platform Core Data Models & Persistent Store
 * Completely unseeded: All educational content (courses, lessons, quizzes,
 * flashcards, live classes, glossary) is added manually by admin.
 * Backed by Firebase Firestore with real-time updates and local fallback.
 */

import { useState, useEffect } from 'react';
import { GlossaryItem } from './glossary';
import {
  saveCourseFirestore,
  deleteCourseFirestore,
  saveQuizFirestore,
  deleteQuizFirestore,
  saveFlashcardSetFirestore,
  deleteFlashcardSetFirestore,
  saveLiveClassFirestore,
  deleteLiveClassFirestore,
  saveGlossaryItemFirestore,
  deleteGlossaryItemFirestore,
  saveNotificationFirestore,
  deleteNotificationFirestore,
  subscribeToCourses,
  subscribeToQuizzes,
  subscribeToFlashcards,
  subscribeToLiveClasses,
  subscribeToGlossary,
  subscribeToNotifications,
} from '../firebase/firestoreService';

export type { GlossaryItem };

export const COURSE_CATEGORIES = [
  'Blockchain Basics',
  'Wallets & Safety',
  'DeFi & Smart Contracts',
  'Trading & Risk',
  'Security & Scam Prevention',
] as const;

export interface LessonContentSection {
  heading: string;
  paragraphs: string[];
  callout?: string;
}

export interface PptxSlideData {
  slideNumber: number;
  title: string;
  bullets: string[];
  notes?: string;
  imageUrl?: string;
}

export interface LessonItem {
  lessonId: string;
  courseSlug: string;
  title: string;
  type: 'written' | 'video' | 'pptx';
  durationMinutes: number;
  summary: string;
  videoUrl?: string;
  subtitleUrl?: string;
  pptxUrl?: string;
  pptxFileName?: string;
  pptxSlides?: PptxSlideData[];
  content: LessonContentSection[];
  quizId?: string;
  flashcardSetId?: string;
  published?: boolean;
  updatedAt?: string;
}

export interface CourseDetail {
  slug: string;
  title: string;
  category?: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  durationWeeks: number;
  instructor: string;
  instructorTitle: string;
  description: string;
  prerequisites?: string[];
  curriculumSummary: string[];
  lessons: LessonItem[];
  published?: boolean;
  recommended?: boolean;
  updatedAt?: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizData {
  quizId: string;
  title: string;
  courseSlug: string;
  lessonId: string;
  passingScore: number;
  timeLimitMinutes?: number;
  instructions?: string;
  questions: QuizQuestion[];
  published?: boolean;
  updatedAt?: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  category: string;
}

export interface FlashcardSet {
  setId: string;
  title: string;
  lessonId: string;
  courseSlug: string;
  cards: Flashcard[];
  published?: boolean;
  updatedAt?: string;
}

export interface LiveClassItem {
  id: string;
  title: string;
  courseSlug?: string;
  instructor: string;
  instructorRole: string;
  date: string;
  time: string;
  durationMinutes: number;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  agenda: string[];
  meetingUrl: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  published?: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  linkPath?: string;
  courseSlug?: string;
  published: boolean;
  archived?: boolean;
  createdAt: string;
  expiresAt?: string;
  updatedAt?: string;
}

export interface AdminActivityLogEntry {
  id: string;
  action: string;
  details: string;
  status: 'success' | 'error';
  timestamp: string;
}

// Storage keys for local caching
const STORAGE_KEYS = {
  COURSES: 'coinedu_content_courses_v1',
  QUIZZES: 'coinedu_content_quizzes_v1',
  FLASHCARDS: 'coinedu_content_flashcards_v1',
  LIVE_CLASSES: 'coinedu_content_live_classes_v1',
  GLOSSARY: 'coinedu_content_glossary_v1',
  NOTIFICATIONS: 'coinedu_content_notifications_v1',
  ADMIN_LOGS: 'coinedu_admin_activity_logs_v1',
};

// Dispatch change event to all reactive listeners across components
function notifyContentChanged() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('coinedu_content_updated'));
  }
}

// --- Pure Domain Helpers (Testable) ---
export function filterRecommendedCourses(courses: CourseDetail[]): CourseDetail[] {
  return (courses || []).filter((c) => c.published === true && c.recommended === true);
}

export interface CourseProgressSummary {
  totalPublishedLessons: number;
  completedLessonsCount: number;
  percentage: number;
  isCompleted: boolean;
  statusLabel: string;
}

export function calculateCourseProgress(
  course: CourseDetail,
  userCompletedLessonIds: string[]
): CourseProgressSummary {
  const publishedLessons = (course.lessons || []).filter((l) => l.published !== false);
  const totalPublishedLessons = publishedLessons.length;
  if (totalPublishedLessons === 0) {
    return {
      totalPublishedLessons: 0,
      completedLessonsCount: 0,
      percentage: 0,
      isCompleted: false,
      statusLabel: 'No lessons published yet',
    };
  }

  const completedSet = new Set(userCompletedLessonIds || []);
  const completedLessonsCount = publishedLessons.filter((l) => completedSet.has(l.lessonId)).length;
  const clampedCompleted = Math.min(completedLessonsCount, totalPublishedLessons);
  const percentage = Math.round((clampedCompleted / totalPublishedLessons) * 100);
  const isCompleted = clampedCompleted === totalPublishedLessons && totalPublishedLessons > 0;

  return {
    totalPublishedLessons,
    completedLessonsCount: clampedCompleted,
    percentage,
    isCompleted,
    statusLabel: `${clampedCompleted} / ${totalPublishedLessons} Lessons`,
  };
}

export function isNotificationActive(notification: NotificationItem, nowIso = new Date().toISOString()): boolean {
  if (!notification.published || notification.archived) return false;
  if (notification.expiresAt && notification.expiresAt.trim() !== '') {
    const expTime = Date.parse(notification.expiresAt);
    const nowTime = Date.parse(nowIso);
    if (!Number.isNaN(expTime) && !Number.isNaN(nowTime) && nowTime > expTime) {
      return false;
    }
  }
  return true;
}

// --- Admin Activity & Error Reporting ---
export function getAdminActivityLogs(): AdminActivityLogEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_LOGS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function logAdminActivity(
  action: string,
  details: string,
  status: 'success' | 'error' = 'success'
): void {
  if (typeof window === 'undefined') return;
  try {
    const existing = getAdminActivityLogs();
    const entry: AdminActivityLogEntry = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      action,
      details,
      status,
      timestamp: new Date().toISOString(),
    };
    const updated = [entry, ...existing].slice(0, 50);
    localStorage.setItem(STORAGE_KEYS.ADMIN_LOGS, JSON.stringify(updated));
    notifyContentChanged();
  } catch {
    // ignore storage quota errors
  }
}

export function clearAdminActivityLogs(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(STORAGE_KEYS.ADMIN_LOGS);
    notifyContentChanged();
  } catch {}
}

// --- Courses Store ---
export function getStoredCourses(includeUnpublished = false): CourseDetail[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.COURSES);
    const parsed: CourseDetail[] = raw ? JSON.parse(raw) : [];
    if (includeUnpublished) return parsed;
    return parsed.filter((c) => c.published === true);
  } catch {
    return [];
  }
}

export function saveCourse(course: CourseDetail): void {
  const existing = getStoredCourses(true);
  const index = existing.findIndex((c) => c.slug === course.slug);
  const now = new Date().toISOString();
  const toSave: CourseDetail = {
    ...course,
    category: course.category || 'Blockchain Basics',
    published: course.published ?? false,
    recommended: course.recommended ?? false,
    lessons: course.lessons || [],
    prerequisites: course.prerequisites || [],
    curriculumSummary: course.curriculumSummary || [],
    updatedAt: now,
  };

  if (index >= 0) {
    existing[index] = toSave;
  } else {
    existing.push(toSave);
  }

  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(existing));
  logAdminActivity(
    index >= 0 ? 'Updated Course' : 'Created Course',
    `"${toSave.title}" (${toSave.published ? 'Published' : 'Draft'}${toSave.recommended ? ', Recommended' : ''})`
  );
  notifyContentChanged();

  saveCourseFirestore(toSave).catch((err) => {
    console.warn('Could not sync course to Firestore:', err);
    logAdminActivity('Cloud Sync Warning', `Course "${toSave.title}" saved locally; cloud sync pending.`, 'error');
  });
}

export function deleteCourse(slug: string): void {
  const existing = getStoredCourses(true);
  const target = existing.find((c) => c.slug === slug);
  const filtered = existing.filter((c) => c.slug !== slug);
  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(filtered));
  logAdminActivity('Deleted Course', `Removed course "${target?.title || slug}"`);
  notifyContentChanged();

  deleteCourseFirestore(slug).catch((err) => {
    console.warn('Could not delete course from Firestore:', err);
  });
}

export function toggleCoursePublish(slug: string): boolean {
  const existing = getStoredCourses(true);
  const course = existing.find((c) => c.slug === slug);
  if (!course) return false;
  course.published = !course.published;
  course.updatedAt = new Date().toISOString();
  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(existing));
  logAdminActivity(
    course.published ? 'Published Course' : 'Unpublished Course',
    `"${course.title}" is now ${course.published ? 'live for students' : 'in draft mode'}`
  );
  notifyContentChanged();

  saveCourseFirestore(course).catch(() => null);
  return course.published;
}

export function toggleCourseRecommended(slug: string): boolean {
  const existing = getStoredCourses(true);
  const course = existing.find((c) => c.slug === slug);
  if (!course) return false;
  course.recommended = !course.recommended;
  course.updatedAt = new Date().toISOString();
  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(existing));
  logAdminActivity(
    course.recommended ? 'Marked Course Recommended' : 'Unmarked Course Recommended',
    `"${course.title}" is ${course.recommended ? 'now featured on /courses' : 'removed from /courses recommendations'}`
  );
  notifyContentChanged();

  saveCourseFirestore(course).catch(() => null);
  return Boolean(course.recommended);
}

// --- Lessons Store ---
export function saveLesson(courseSlug: string, lesson: LessonItem): void {
  const existing = getStoredCourses(true);
  const course = existing.find((c) => c.slug === courseSlug);
  if (!course) return;

  const now = new Date().toISOString();
  const toSave: LessonItem = {
    ...lesson,
    courseSlug,
    published: lesson.published ?? false,
    content: lesson.content || [],
    updatedAt: now,
  };

  const lIdx = course.lessons.findIndex((l) => l.lessonId === lesson.lessonId);
  if (lIdx >= 0) {
    course.lessons[lIdx] = toSave;
  } else {
    course.lessons.push(toSave);
  }
  course.updatedAt = now;

  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(existing));
  logAdminActivity(
    lIdx >= 0 ? 'Updated Lesson' : 'Added Lesson',
    `"${toSave.title}" (${toSave.type.toUpperCase()}) in course "${course.title}"`
  );
  notifyContentChanged();

  saveCourseFirestore(course).catch(() => null);
}

export function reorderLesson(courseSlug: string, lessonId: string, direction: 'up' | 'down'): void {
  const existing = getStoredCourses(true);
  const course = existing.find((c) => c.slug === courseSlug);
  if (!course) return;

  const idx = course.lessons.findIndex((l) => l.lessonId === lessonId);
  if (idx < 0) return;

  const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
  if (targetIdx < 0 || targetIdx >= course.lessons.length) return;

  const temp = course.lessons[idx];
  course.lessons[idx] = course.lessons[targetIdx];
  course.lessons[targetIdx] = temp;
  course.updatedAt = new Date().toISOString();

  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(existing));
  logAdminActivity('Reordered Lesson', `Moved "${temp.title}" ${direction} in "${course.title}"`);
  notifyContentChanged();

  saveCourseFirestore(course).catch(() => null);
}

export function deleteLesson(lessonId: string): void {
  const existing = getStoredCourses(true);
  let updatedCourse: CourseDetail | null = null;
  let removedTitle = lessonId;
  for (const course of existing) {
    const lIdx = course.lessons.findIndex((l) => l.lessonId === lessonId);
    if (lIdx >= 0) {
      removedTitle = course.lessons[lIdx].title;
      course.lessons.splice(lIdx, 1);
      course.updatedAt = new Date().toISOString();
      updatedCourse = course;
      break;
    }
  }
  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(existing));
  logAdminActivity('Deleted Lesson', `Removed lesson "${removedTitle}"`);
  notifyContentChanged();

  if (updatedCourse) {
    saveCourseFirestore(updatedCourse).catch(() => null);
  }
}

export function toggleLessonPublish(lessonId: string): boolean {
  const existing = getStoredCourses(true);
  let newStatus = false;
  let updatedCourse: CourseDetail | null = null;
  let lessonTitle = lessonId;
  for (const course of existing) {
    const lesson = course.lessons.find((l) => l.lessonId === lessonId);
    if (lesson) {
      lesson.published = !lesson.published;
      lesson.updatedAt = new Date().toISOString();
      newStatus = lesson.published;
      lessonTitle = lesson.title;
      updatedCourse = course;
      break;
    }
  }
  localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(existing));
  logAdminActivity(
    newStatus ? 'Published Lesson' : 'Unpublished Lesson',
    `"${lessonTitle}" status set to ${newStatus ? 'Published' : 'Draft'}`
  );
  notifyContentChanged();

  if (updatedCourse) {
    saveCourseFirestore(updatedCourse).catch(() => null);
  }
  return newStatus;
}

// --- Quizzes Store ---
export function getStoredQuizzes(includeUnpublished = false): Record<string, QuizData> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.QUIZZES);
    const parsed: Record<string, QuizData> = raw ? JSON.parse(raw) : {};
    if (includeUnpublished) return parsed;
    const filtered: Record<string, QuizData> = {};
    for (const [id, q] of Object.entries(parsed)) {
      if (q.published === true) filtered[id] = q;
    }
    return filtered;
  } catch {
    return {};
  }
}

export function saveQuiz(quiz: QuizData): void {
  const existing = getStoredQuizzes(true);
  const toSave: QuizData = {
    ...quiz,
    published: quiz.published ?? false,
    questions: quiz.questions || [],
    updatedAt: new Date().toISOString(),
  };
  existing[quiz.quizId] = toSave;
  localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(existing));
  logAdminActivity('Saved Quiz', `"${toSave.title}" (${toSave.questions.length} questions)`);
  notifyContentChanged();

  saveQuizFirestore(toSave).catch(() => null);
}

export function deleteQuiz(quizId: string): void {
  const existing = getStoredQuizzes(true);
  const title = existing[quizId]?.title || quizId;
  delete existing[quizId];
  localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(existing));
  logAdminActivity('Deleted Quiz', `Removed quiz "${title}"`);
  notifyContentChanged();

  deleteQuizFirestore(quizId).catch(() => null);
}

export function toggleQuizPublish(quizId: string): boolean {
  const existing = getStoredQuizzes(true);
  if (!existing[quizId]) return false;
  existing[quizId].published = !existing[quizId].published;
  existing[quizId].updatedAt = new Date().toISOString();
  localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(existing));
  logAdminActivity(
    existing[quizId].published ? 'Published Quiz' : 'Unpublished Quiz',
    `"${existing[quizId].title}"`
  );
  notifyContentChanged();

  saveQuizFirestore(existing[quizId]).catch(() => null);
  return existing[quizId].published;
}

// --- Flashcards Store ---
export function getStoredFlashcards(includeUnpublished = false): Record<string, FlashcardSet> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FLASHCARDS);
    const parsed: Record<string, FlashcardSet> = raw ? JSON.parse(raw) : {};
    if (includeUnpublished) return parsed;
    const filtered: Record<string, FlashcardSet> = {};
    for (const [id, s] of Object.entries(parsed)) {
      if (s.published === true) filtered[id] = s;
    }
    return filtered;
  } catch {
    return {};
  }
}

export function saveFlashcardSet(set: FlashcardSet): void {
  const existing = getStoredFlashcards(true);
  const toSave: FlashcardSet = {
    ...set,
    published: set.published ?? false,
    cards: set.cards || [],
    updatedAt: new Date().toISOString(),
  };
  existing[set.setId] = toSave;
  localStorage.setItem(STORAGE_KEYS.FLASHCARDS, JSON.stringify(existing));
  logAdminActivity('Saved Flashcards', `"${toSave.title}" (${toSave.cards.length} cards)`);
  notifyContentChanged();

  saveFlashcardSetFirestore(toSave).catch(() => null);
}

export function deleteFlashcardSet(setId: string): void {
  const existing = getStoredFlashcards(true);
  const title = existing[setId]?.title || setId;
  delete existing[setId];
  localStorage.setItem(STORAGE_KEYS.FLASHCARDS, JSON.stringify(existing));
  logAdminActivity('Deleted Flashcards', `Removed deck "${title}"`);
  notifyContentChanged();

  deleteFlashcardSetFirestore(setId).catch(() => null);
}

export function toggleFlashcardPublish(setId: string): boolean {
  const existing = getStoredFlashcards(true);
  if (!existing[setId]) return false;
  existing[setId].published = !existing[setId].published;
  existing[setId].updatedAt = new Date().toISOString();
  localStorage.setItem(STORAGE_KEYS.FLASHCARDS, JSON.stringify(existing));
  logAdminActivity(
    existing[setId].published ? 'Published Flashcards' : 'Unpublished Flashcards',
    `"${existing[setId].title}"`
  );
  notifyContentChanged();

  saveFlashcardSetFirestore(existing[setId]).catch(() => null);
  return existing[setId].published;
}

// --- Live Classes Store ---
export function getStoredLiveClasses(includeUnpublished = false): LiveClassItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LIVE_CLASSES);
    const parsed: LiveClassItem[] = raw ? JSON.parse(raw) : [];
    if (includeUnpublished) return parsed;
    return parsed.filter((l) => l.published === true);
  } catch {
    return [];
  }
}

export function saveLiveClass(item: LiveClassItem): void {
  const existing = getStoredLiveClasses(true);
  const index = existing.findIndex((l) => l.id === item.id);
  const toSave: LiveClassItem = {
    ...item,
    published: item.published ?? false,
    agenda: item.agenda || [],
  };

  if (index >= 0) {
    existing[index] = toSave;
  } else {
    existing.push(toSave);
  }

  localStorage.setItem(STORAGE_KEYS.LIVE_CLASSES, JSON.stringify(existing));
  logAdminActivity('Scheduled Live Class', `"${toSave.title}" on ${toSave.date}`);
  notifyContentChanged();

  saveLiveClassFirestore(toSave).catch(() => null);
}

export function deleteLiveClass(id: string): void {
  const existing = getStoredLiveClasses(true).filter((l) => l.id !== id);
  localStorage.setItem(STORAGE_KEYS.LIVE_CLASSES, JSON.stringify(existing));
  logAdminActivity('Deleted Live Class', `Removed live class ID "${id}"`);
  notifyContentChanged();

  deleteLiveClassFirestore(id).catch(() => null);
}

export function toggleLiveClassPublish(id: string): boolean {
  const existing = getStoredLiveClasses(true);
  const item = existing.find((l) => l.id === id);
  if (!item) return false;
  item.published = !item.published;
  localStorage.setItem(STORAGE_KEYS.LIVE_CLASSES, JSON.stringify(existing));
  logAdminActivity(
    item.published ? 'Published Live Class' : 'Unpublished Live Class',
    `"${item.title}"`
  );
  notifyContentChanged();

  saveLiveClassFirestore(item).catch(() => null);
  return item.published;
}

// --- Dictionary (Glossary) Store ---
export function getStoredGlossary(includeUnpublished = false): GlossaryItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GLOSSARY);
    const parsed: GlossaryItem[] = raw ? JSON.parse(raw) : [];
    if (includeUnpublished) return parsed;
    return parsed.filter((g) => g.published === true);
  } catch {
    return [];
  }
}

export function saveGlossaryItem(item: GlossaryItem): void {
  const existing = getStoredGlossary(true);
  const index = existing.findIndex((g) => g.term.toLowerCase() === item.term.toLowerCase());
  const toSave: GlossaryItem = {
    ...item,
    published: item.published ?? false,
  };

  if (index >= 0) {
    existing[index] = toSave;
  } else {
    existing.push(toSave);
  }

  localStorage.setItem(STORAGE_KEYS.GLOSSARY, JSON.stringify(existing));
  logAdminActivity('Saved Dictionary Term', `"${toSave.term}" (${toSave.category})`);
  notifyContentChanged();

  saveGlossaryItemFirestore(toSave).catch(() => null);
}

export function deleteGlossaryItem(term: string): void {
  const existing = getStoredGlossary(true).filter((g) => g.term.toLowerCase() !== term.toLowerCase());
  localStorage.setItem(STORAGE_KEYS.GLOSSARY, JSON.stringify(existing));
  logAdminActivity('Deleted Dictionary Term', `Removed term "${term}"`);
  notifyContentChanged();

  deleteGlossaryItemFirestore(term).catch(() => null);
}

export function toggleGlossaryPublish(term: string): boolean {
  const existing = getStoredGlossary(true);
  const item = existing.find((g) => g.term.toLowerCase() === term.toLowerCase());
  if (!item) return false;
  item.published = !item.published;
  localStorage.setItem(STORAGE_KEYS.GLOSSARY, JSON.stringify(existing));
  logAdminActivity(
    item.published ? 'Published Dictionary Term' : 'Unpublished Dictionary Term',
    `"${item.term}"`
  );
  notifyContentChanged();

  saveGlossaryItemFirestore(item).catch(() => null);
  return item.published;
}

// --- Notifications Store ---
export function getStoredNotifications(includeUnpublished = false): NotificationItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    const parsed: NotificationItem[] = raw ? JSON.parse(raw) : [];
    if (includeUnpublished) return parsed;
    return parsed.filter((n) => isNotificationActive(n));
  } catch {
    return [];
  }
}

export function saveNotification(notification: NotificationItem): void {
  const existing = getStoredNotifications(true);
  const index = existing.findIndex((n) => n.id === notification.id);
  const now = new Date().toISOString();
  const toSave: NotificationItem = {
    ...notification,
    published: notification.published ?? false,
    archived: notification.archived ?? false,
    createdAt: notification.createdAt || now,
    updatedAt: now,
  };

  if (index >= 0) {
    existing[index] = toSave;
  } else {
    existing.unshift(toSave);
  }

  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(existing));
  logAdminActivity(
    index >= 0 ? 'Updated Notification' : 'Created Notification',
    `"${toSave.title}" (${toSave.published ? 'Published' : 'Draft'})`
  );
  notifyContentChanged();

  saveNotificationFirestore(toSave).catch(() => null);
}

export function deleteNotification(id: string): void {
  const existing = getStoredNotifications(true);
  const target = existing.find((n) => n.id === id);
  const filtered = existing.filter((n) => n.id !== id);
  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(filtered));
  logAdminActivity('Deleted Notification', `Removed notification "${target?.title || id}"`);
  notifyContentChanged();

  deleteNotificationFirestore(id).catch(() => null);
}

export function toggleNotificationPublish(id: string): boolean {
  const existing = getStoredNotifications(true);
  const item = existing.find((n) => n.id === id);
  if (!item) return false;
  item.published = !item.published;
  item.updatedAt = new Date().toISOString();
  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(existing));
  logAdminActivity(
    item.published ? 'Published Notification' : 'Unpublished Notification',
    `"${item.title}"`
  );
  notifyContentChanged();

  saveNotificationFirestore(item).catch(() => null);
  return item.published;
}

export function toggleNotificationArchive(id: string): boolean {
  const existing = getStoredNotifications(true);
  const item = existing.find((n) => n.id === id);
  if (!item) return false;
  item.archived = !item.archived;
  item.updatedAt = new Date().toISOString();
  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(existing));
  logAdminActivity(
    item.archived ? 'Archived Notification' : 'Unarchived Notification',
    `"${item.title}"`
  );
  notifyContentChanged();

  saveNotificationFirestore(item).catch(() => null);
  return Boolean(item.archived);
}

// --- Pure Search & Filter Helper (Testable) ---
export interface SearchResults {
  courses: CourseDetail[];
  lessons: Array<{ lesson: LessonItem; courseTitle: string; courseSlug: string }>;
  glossary: GlossaryItem[];
}

export function searchPlatformContent(
  query: string,
  courses: CourseDetail[],
  glossaryTerms: GlossaryItem[]
): SearchResults {
  const q = query.trim().toLowerCase();
  if (!q) {
    return { courses: [], lessons: [], glossary: [] };
  }

  const matchedCourses = courses.filter(
    (c) =>
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      (c.category && c.category.toLowerCase().includes(q)) ||
      (c.curriculumSummary && c.curriculumSummary.some((item) => item.toLowerCase().includes(q)))
  );

  const matchedLessons: Array<{ lesson: LessonItem; courseTitle: string; courseSlug: string }> = [];
  for (const course of courses) {
    for (const lesson of course.lessons || []) {
      if (!lesson.published && !course.published) continue;
      const inTitle = lesson.title.toLowerCase().includes(q);
      const inSummary = lesson.summary.toLowerCase().includes(q);
      const inContent =
        lesson.content &&
        lesson.content.some(
          (sec) =>
            sec.heading.toLowerCase().includes(q) ||
            sec.paragraphs.some((p) => p.toLowerCase().includes(q))
        );
      if (inTitle || inSummary || inContent) {
        matchedLessons.push({
          lesson,
          courseTitle: course.title,
          courseSlug: course.slug,
        });
      }
    }
  }

  const matchedGlossary = glossaryTerms.filter(
    (g) =>
      g.term.toLowerCase().includes(q) ||
      g.shortDef.toLowerCase().includes(q) ||
      g.fullDef.toLowerCase().includes(q) ||
      g.category.toLowerCase().includes(q)
  );

  return {
    courses: matchedCourses,
    lessons: matchedLessons,
    glossary: matchedGlossary,
  };
}

// Reactive Hook for any React Component
export function useContentStore(isAdmin = false) {
  const [, setVersion] = useState(0);
  const [firestoreCourses, setFirestoreCourses] = useState<CourseDetail[] | null>(null);
  const [firestoreQuizzes, setFirestoreQuizzes] = useState<Record<string, QuizData> | null>(null);
  const [firestoreFlashcards, setFirestoreFlashcards] = useState<Record<string, FlashcardSet> | null>(null);
  const [firestoreLiveClasses, setFirestoreLiveClasses] = useState<LiveClassItem[] | null>(null);
  const [firestoreGlossary, setFirestoreGlossary] = useState<GlossaryItem[] | null>(null);
  const [firestoreNotifications, setFirestoreNotifications] = useState<NotificationItem[] | null>(null);

  useEffect(() => {
    const handleUpdate = () => setVersion((v) => v + 1);
    window.addEventListener('coinedu_content_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);

    // Subscribe to Firestore updates across all collections
    let unsubscribeCourses: (() => void) | undefined;
    let unsubscribeQuizzes: (() => void) | undefined;
    let unsubscribeFlashcards: (() => void) | undefined;
    let unsubscribeLiveClasses: (() => void) | undefined;
    let unsubscribeGlossary: (() => void) | undefined;
    let unsubscribeNotifications: (() => void) | undefined;

    try {
      unsubscribeCourses = subscribeToCourses((courses) => {
        setFirestoreCourses(courses);
        try {
          localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
        } catch {}
      }, isAdmin);
    } catch {}

    try {
      unsubscribeQuizzes = subscribeToQuizzes((quizzes) => {
        setFirestoreQuizzes(quizzes);
        try {
          localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(quizzes));
        } catch {}
      }, isAdmin);
    } catch {}

    try {
      unsubscribeFlashcards = subscribeToFlashcards((flashcards) => {
        setFirestoreFlashcards(flashcards);
        try {
          localStorage.setItem(STORAGE_KEYS.FLASHCARDS, JSON.stringify(flashcards));
        } catch {}
      }, isAdmin);
    } catch {}

    try {
      unsubscribeLiveClasses = subscribeToLiveClasses((classes) => {
        setFirestoreLiveClasses(classes);
        try {
          localStorage.setItem(STORAGE_KEYS.LIVE_CLASSES, JSON.stringify(classes));
        } catch {}
      }, isAdmin);
    } catch {}

    try {
      unsubscribeGlossary = subscribeToGlossary((terms) => {
        setFirestoreGlossary(terms);
        try {
          localStorage.setItem(STORAGE_KEYS.GLOSSARY, JSON.stringify(terms));
        } catch {}
      }, isAdmin);
    } catch {}

    try {
      unsubscribeNotifications = subscribeToNotifications((items) => {
        setFirestoreNotifications(items);
        try {
          localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(items));
        } catch {}
      }, isAdmin);
    } catch {}

    return () => {
      window.removeEventListener('coinedu_content_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
      if (unsubscribeCourses) unsubscribeCourses();
      if (unsubscribeQuizzes) unsubscribeQuizzes();
      if (unsubscribeFlashcards) unsubscribeFlashcards();
      if (unsubscribeLiveClasses) unsubscribeLiveClasses();
      if (unsubscribeGlossary) unsubscribeGlossary();
      if (unsubscribeNotifications) unsubscribeNotifications();
    };
  }, [isAdmin]);

  const courses = firestoreCourses !== null ? firestoreCourses : getStoredCourses(isAdmin);
  const quizzes = firestoreQuizzes !== null ? firestoreQuizzes : getStoredQuizzes(isAdmin);
  const flashcards = firestoreFlashcards !== null ? firestoreFlashcards : getStoredFlashcards(isAdmin);
  const liveClasses = firestoreLiveClasses !== null ? firestoreLiveClasses : getStoredLiveClasses(isAdmin);
  const glossaryTerms = firestoreGlossary !== null ? firestoreGlossary : getStoredGlossary(isAdmin);
  const rawNotifications =
    firestoreNotifications !== null ? firestoreNotifications : getStoredNotifications(true);
  const notifications = isAdmin
    ? rawNotifications
    : rawNotifications.filter((n) => isNotificationActive(n));
  const activityLogs = isAdmin ? getAdminActivityLogs() : [];

  return {
    courses,
    quizzes,
    flashcards,
    liveClasses,
    glossaryTerms,
    notifications,
    activityLogs,
  };
}

// Initial empty exports to satisfy clean initial imports
export const COURSES_DATA: CourseDetail[] = [];
export const QUIZZES_DATA: Record<string, QuizData> = {};
export const FLASHCARD_SETS: Record<string, FlashcardSet> = {};
export const LIVE_CLASSES_DATA: LiveClassItem[] = [];
