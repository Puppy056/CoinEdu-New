export interface Module {
  id: string;
  title: string;
  estimatedMinutes: number;
  summary: string;
  sections: {
    heading: string;
    content: string[];
    keyTakeaway?: string;
  }[];
  quiz: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
}

export interface CourseTrack {
  id: string;
  title: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  color: string;
  iconName: string;
  description: string;
  modules: Module[];
}

// Clean unseeded tracks: all educational content added manually by admin
export const COURSE_TRACKS: CourseTrack[] = [];
