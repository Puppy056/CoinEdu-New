import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import {
  getStoredCourses,
  getStoredQuizzes,
  getStoredFlashcards,
  getStoredLiveClasses,
  getStoredGlossary,
  getStoredNotifications,
  COURSE_CATEGORIES,
  searchPlatformContent,
  filterRecommendedCourses,
  calculateCourseProgress,
  isNotificationActive,
  CourseDetail,
  NotificationItem,
} from '../data/learningPlatform';
import { GLOSSARY_TERMS, GlossaryItem } from '../data/glossary';
import { parseSlideXmlContent } from '../components/PptxViewer';
import { parsePath } from '../router/useRouter';

after(() => {
  setTimeout(() => process.exit(0), 50);
});

test('Educational Content Empty State Invariant: No courses, lessons, quizzes, flashcards, glossary items, or notifications are pre-seeded', () => {
  assert.equal(getStoredCourses(true).length, 0);
  assert.equal(Object.keys(getStoredQuizzes(true)).length, 0);
  assert.equal(Object.keys(getStoredFlashcards(true)).length, 0);
  assert.equal(getStoredLiveClasses(true).length, 0);
  assert.equal(getStoredGlossary(true).length, 0);
  assert.equal(getStoredNotifications(true).length, 0);
  assert.equal(GLOSSARY_TERMS.length, 0);
});

test('Course Categories are defined for filtering and admin classification', () => {
  assert.ok(COURSE_CATEGORIES.includes('Blockchain Basics'));
  assert.ok(COURSE_CATEGORIES.includes('Wallets & Safety'));
  assert.ok(COURSE_CATEGORIES.includes('Security & Scam Prevention'));
});

test('Recommended Courses Filter (filterRecommendedCourses) returns only published & recommended courses', () => {
  const courses: CourseDetail[] = [
    {
      slug: 'rec-pub',
      title: 'Recommended Published',
      level: 'Beginner',
      durationWeeks: 2,
      instructor: '',
      instructorTitle: '',
      description: '',
      curriculumSummary: [],
      lessons: [],
      published: true,
      recommended: true,
    },
    {
      slug: 'rec-draft',
      title: 'Recommended Draft',
      level: 'Beginner',
      durationWeeks: 2,
      instructor: '',
      instructorTitle: '',
      description: '',
      curriculumSummary: [],
      lessons: [],
      published: false,
      recommended: true,
    },
    {
      slug: 'non-rec-pub',
      title: 'Standard Published',
      level: 'Intermediate',
      durationWeeks: 3,
      instructor: '',
      instructorTitle: '',
      description: '',
      curriculumSummary: [],
      lessons: [],
      published: true,
      recommended: false,
    },
  ];

  const rec = filterRecommendedCourses(courses);
  assert.equal(rec.length, 1);
  assert.equal(rec[0].slug, 'rec-pub');
});

test('Course Progress Calculator (calculateCourseProgress) prevents 1/0 lessons bug and handles 0-lesson courses cleanly', () => {
  const emptyCourse: CourseDetail = {
    slug: 'empty-c',
    title: 'Empty Course',
    level: 'Beginner',
    durationWeeks: 1,
    instructor: '',
    instructorTitle: '',
    description: '',
    curriculumSummary: [],
    published: true,
    lessons: [],
  };

  // 0 lessons in course, even if completedLessons has stale IDs from another course
  const zeroLessonProg = calculateCourseProgress(emptyCourse, ['stale_lesson_1']);
  assert.equal(zeroLessonProg.completedLessonsCount, 0);
  assert.equal(zeroLessonProg.totalPublishedLessons, 0);
  assert.equal(zeroLessonProg.percentage, 0);
  assert.equal(zeroLessonProg.isCompleted, false);

  // 2 lessons in course, 1 completed
  const twoLessonCourse: CourseDetail = {
    ...emptyCourse,
    slug: 'c1',
    lessons: [
      {
        lessonId: 'l1',
        courseSlug: 'c1',
        title: 'L1',
        type: 'written' as const,
        durationMinutes: 5,
        summary: '',
        content: [],
        published: true,
      },
      {
        lessonId: 'l2',
        courseSlug: 'c1',
        title: 'L2',
        type: 'pptx' as const,
        durationMinutes: 10,
        summary: '',
        content: [],
        published: true,
      },
    ],
  };

  const halfProg = calculateCourseProgress(twoLessonCourse, ['l1', 'other_course_lesson']);
  assert.equal(halfProg.completedLessonsCount, 1);
  assert.equal(halfProg.totalPublishedLessons, 2);
  assert.equal(halfProg.percentage, 50);
  assert.equal(halfProg.isCompleted, false);

  const fullProg = calculateCourseProgress(twoLessonCourse, ['l1', 'l2']);
  assert.equal(fullProg.completedLessonsCount, 2);
  assert.equal(fullProg.totalPublishedLessons, 2);
  assert.equal(fullProg.percentage, 100);
  assert.equal(fullProg.isCompleted, true);
});

test('Notification Active Filter (isNotificationActive) checks published, archived, and expiration dates', () => {
  const nowIso = '2026-10-26T12:00:00Z';
  const activeNotif: NotificationItem = {
    id: 'n1',
    title: 'New Course',
    message: 'Check out Blockchain 101',
    createdAt: '2026-10-25T12:00:00Z',
    expiresAt: '2026-11-01T12:00:00Z',
    published: true,
    archived: false,
  };
  const expiredNotif: NotificationItem = {
    ...activeNotif,
    id: 'n2',
    expiresAt: '2026-10-20T12:00:00Z',
  };
  const draftNotif: NotificationItem = {
    ...activeNotif,
    id: 'n3',
    published: false,
  };

  assert.equal(isNotificationActive(activeNotif, nowIso), true);
  assert.equal(isNotificationActive(expiredNotif, nowIso), false);
  assert.equal(isNotificationActive(draftNotif, nowIso), false);
});

test('PPTX Slide XML Parser (parseSlideXmlContent) extracts slide title, bullets, and speaker notes', () => {
  const sampleSlideXml = `
    <p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
      <p:cSld>
        <p:spTree>
          <p:sp>
            <p:txBody>
              <a:p><a:r><a:t>What is a Blockchain?</a:t></a:r></a:p>
            </p:txBody>
          </p:sp>
          <p:sp>
            <p:txBody>
              <a:p><a:r><a:t>Distributed append-only ledger</a:t></a:r></a:p>
              <a:p><a:r><a:t>Secured by cryptographic hashes</a:t></a:r></a:p>
            </p:txBody>
          </p:sp>
        </p:spTree>
      </p:cSld>
    </p:sld>
  `;
  const sampleNotesXml = `
    <p:notes xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
      <a:p><a:r><a:t>Emphasize immutability and consensus.</a:t></a:r></a:p>
    </p:notes>
  `;

  const parsed = parseSlideXmlContent(sampleSlideXml, 1, sampleNotesXml);
  assert.equal(parsed.slideNumber, 1);
  assert.equal(parsed.title, 'What is a Blockchain?');
  assert.deepEqual(parsed.bullets, [
    'Distributed append-only ledger',
    'Secured by cryptographic hashes',
  ]);
  assert.equal(parsed.notes, 'Emphasize immutability and consensus.');
});

test('Router Path Parser (parsePath) maps new student/admin routes and legacy redirects accurately', () => {
  assert.equal(parsePath('/reset-password').name, 'reset-password');
  assert.equal(parsePath('/dictionary').name, 'dictionary');
  assert.equal(parsePath('/my-quizzes').name, 'my-quizzes');
  assert.equal(parsePath('/my-live-classes').name, 'my-live-classes');
  assert.equal(parsePath('/admin/notifications').name, 'admin-notifications');
  assert.equal(parsePath('/glossary').name, 'legacy-glossary');
  assert.equal(parsePath('/bookmarks').name, 'legacy-bookmarks');
  assert.equal(parsePath('/interactive-learning').name, 'legacy-interactive-learning');
});

test('Global Search Helper (searchPlatformContent) searches courses, lessons, and dictionary terms accurately', () => {
  const sampleCourses: CourseDetail[] = [
    {
      slug: 'wallet-safety-101',
      title: 'Wallet Safety for Beginners',
      category: 'Wallets & Safety',
      level: 'Beginner',
      durationWeeks: 2,
      instructor: '',
      instructorTitle: '',
      description: 'Learn how seed phrases and hardware wallets protect keys.',
      prerequisites: ['Basic internet usage'],
      curriculumSummary: ['Understand seed phrases'],
      published: true,
      lessons: [
        {
          lessonId: 'les_seed_1',
          courseSlug: 'wallet-safety-101',
          title: 'How Recovery Seed Phrases Work',
          type: 'written',
          durationMinutes: 12,
          summary: 'Never share your 12-word recovery phrase online.',
          content: [],
          published: true,
        },
      ],
    },
  ];

  const sampleGlossary: GlossaryItem[] = [
    {
      term: 'Seed Phrase',
      category: 'Security',
      shortDef: 'A list of 12 or 24 simple words that backs up a crypto wallet.',
      fullDef: 'Human-readable representation of your master private key.',
      realWorldAnalogy: 'Like a master spare key to your locker.',
      beginnerPitfall: 'Storing a screenshot of your seed phrase in cloud photos.',
      published: true,
    },
  ];

  const emptyRes = searchPlatformContent('   ', sampleCourses, sampleGlossary);
  assert.equal(emptyRes.courses.length, 0);
  assert.equal(emptyRes.lessons.length, 0);
  assert.equal(emptyRes.glossary.length, 0);

  const hitRes = searchPlatformContent('seed', sampleCourses, sampleGlossary);
  assert.equal(hitRes.courses.length, 1);
  assert.equal(hitRes.courses[0].slug, 'wallet-safety-101');
  assert.equal(hitRes.lessons.length, 1);
  assert.equal(hitRes.lessons[0].lesson.lessonId, 'les_seed_1');
  assert.equal(hitRes.glossary.length, 1);
  assert.equal(hitRes.glossary[0].term, 'Seed Phrase');
});

test('Firestore Payload Sanitizer (sanitizeFirestorePayload) removes undefined fields recursively so setDoc never fails', async () => {
  const { sanitizeFirestorePayload } = await import('../firebase/firestoreService');

  const rawUserProfile = {
    id: 'bjOZLNNQwHZfnwK5u0Yudeb1lRT2',
    email: 'rakshiths018@gmail.com',
    name: 'Rakshith',
    role: 'student' as const,
    enrolledCourses: ['wallet-safety-101'],
    completedLessons: [],
    bookmarks: [],
    lastVisitedLessonId: undefined,
  };

  const sanitizedProfile = sanitizeFirestorePayload(rawUserProfile);
  assert.equal('lastVisitedLessonId' in sanitizedProfile, false);
  assert.equal(sanitizedProfile.id, 'bjOZLNNQwHZfnwK5u0Yudeb1lRT2');
  assert.deepEqual(sanitizedProfile.enrolledCourses, ['wallet-safety-101']);
});

test('Dual Administrator Authorization: Primary Owner (rakshiths056@gmail.com) and Additional Administrator (jeffery158540@gmail.com / liDG3eSTJuS8eTxin2JWt6SpqvD2) are both authorized with distinct ownership tiers', async () => {
  process.env.COINEDU_SKIP_SERVER_START = 'true';
  const { checkAdminAuthorization, PRIMARY_ADMIN_EMAIL, BUILTIN_ADDITIONAL_ADMINS } = await import('../../server');

  assert.equal(PRIMARY_ADMIN_EMAIL, 'rakshiths056@gmail.com');
  assert.equal(
    BUILTIN_ADDITIONAL_ADMINS.some(
      (a) => a.uid === 'liDG3eSTJuS8eTxin2JWt6SpqvD2' && a.email === 'jeffery158540@gmail.com'
    ),
    true
  );

  // 1. Primary owner retains full ownership
  const primaryResult = checkAdminAuthorization({
    localId: 'primary_owner_uid',
    email: 'rakshiths056@gmail.com',
    emailVerified: true,
  });
  assert.equal(primaryResult.authorized, true);
  assert.equal(primaryResult.isPrimaryOwner, true);
  assert.equal(primaryResult.adminTier, 'primary_owner');

  // 2. Additional administrator (jeffery158540@gmail.com / liDG3eSTJuS8eTxin2JWt6SpqvD2) is authorized without primary ownership
  const secondAdminByUid = checkAdminAuthorization({
    localId: 'liDG3eSTJuS8eTxin2JWt6SpqvD2',
    email: 'jeffery158540@gmail.com',
    emailVerified: true,
  });
  assert.equal(secondAdminByUid.authorized, true);
  assert.equal(secondAdminByUid.isPrimaryOwner, false);
  assert.equal(secondAdminByUid.adminTier, 'additional_admin');

  // 3. Regular student is not authorized
  const studentResult = checkAdminAuthorization({
    localId: 'student_uid_123',
    email: 'student@example.com',
    emailVerified: true,
  });
  assert.equal(studentResult.authorized, false);
  assert.equal(studentResult.isPrimaryOwner, false);
  assert.equal(studentResult.adminTier, 'none');
});

