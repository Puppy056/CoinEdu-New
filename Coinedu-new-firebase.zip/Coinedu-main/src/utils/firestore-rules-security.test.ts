import test from 'node:test';
import assert from 'node:assert/strict';

/**
 * Pure Rule Evaluation Engine mirroring `firestore.rules` logic
 * Verifies all security invariants required by CoinEdu
 */

interface RequestAuth {
  uid: string;
  token: {
    email?: string;
    email_verified?: boolean;
  };
}

interface FirestoreContext {
  auth: RequestAuth | null;
  database: string;
  adminsDocExists?: (uid: string) => boolean;
}

const PRIMARY_ADMIN_EMAIL = 'rakshiths056@gmail.com';

function isSignedIn(ctx: FirestoreContext): boolean {
  return ctx.auth !== null;
}

function isAdmin(ctx: FirestoreContext): boolean {
  if (!isSignedIn(ctx) || !ctx.auth) return false;
  if (ctx.auth.token.email_verified !== true) return false;

  const email = (ctx.auth.token.email || '').toLowerCase().trim();
  if (email === PRIMARY_ADMIN_EMAIL) return true;

  if (ctx.adminsDocExists && ctx.adminsDocExists(ctx.auth.uid)) {
    return true;
  }
  return false;
}

function isOwner(ctx: FirestoreContext, userId: string): boolean {
  return isSignedIn(ctx) && ctx.auth?.uid === userId;
}

function isValidId(id: string): boolean {
  return typeof id === 'string' && id.length > 0 && id.length <= 128 && /^[a-zA-Z0-9_\-]+$/.test(id);
}

// Rules for: match /admins/{adminId}
function canReadAdminDoc(ctx: FirestoreContext): boolean {
  return isAdmin(ctx);
}

function canWriteAdminDoc(): boolean {
  return false; // Direct client writes are strictly disabled
}

// Rules for: match /users/{userId}
function canGetStudentProfile(ctx: FirestoreContext, targetUserId: string): boolean {
  return isOwner(ctx, targetUserId) || isAdmin(ctx);
}

function canListStudentProfiles(ctx: FirestoreContext): boolean {
  return isAdmin(ctx);
}

function canCreateStudentProfile(ctx: FirestoreContext, targetUserId: string, incomingData: any): boolean {
  if (!isOwner(ctx, targetUserId)) return false;
  if (!isValidId(incomingData.id) || incomingData.id !== targetUserId) return false;
  if (typeof incomingData.email !== 'string' || typeof incomingData.name !== 'string') return false;
  // Students can ONLY create accounts with role === 'student'
  return incomingData.role === 'student';
}

function canUpdateStudentProfile(
  ctx: FirestoreContext,
  targetUserId: string,
  existingData: any,
  incomingData: any
): boolean {
  if (isAdmin(ctx)) return true;
  if (isOwner(ctx, targetUserId)) {
    // Student cannot elevate role
    return incomingData.role === existingData.role && incomingData.role === 'student';
  }
  return false;
}

function canDeleteStudentProfile(ctx: FirestoreContext): boolean {
  return isAdmin(ctx);
}

// Rules for: match /users/{userId}/quizAttempts/{attemptId}
function canReadQuizAttempt(ctx: FirestoreContext, targetUserId: string): boolean {
  return isOwner(ctx, targetUserId) || isAdmin(ctx);
}

function canCreateQuizAttempt(ctx: FirestoreContext, targetUserId: string, attemptId: string, incomingData: any): boolean {
  // Official certified quiz attempts are safely disabled until trusted server-side grading is implemented
  return false;
}

function canUpdateOrDeleteQuizAttempt(): boolean {
  return false; // Immutable and disabled
}

// Rules for Educational Content (Courses, Lessons, Quizzes, Flashcards, LiveClasses, Glossary)
function canReadEducationalContent(ctx: FirestoreContext, isPublished: boolean): boolean {
  return isPublished === true || isAdmin(ctx);
}

function canWriteEducationalContent(ctx: FirestoreContext): boolean {
  return isAdmin(ctx);
}

// ==========================================
// TEST SUITE
// ==========================================

test('Security Invariant 1: Unauthenticated users cannot access private student data', () => {
  const unauthCtx: FirestoreContext = { auth: null, database: 'default' };

  // Profile read/write
  assert.equal(canGetStudentProfile(unauthCtx, 'student_123'), false);
  assert.equal(canListStudentProfiles(unauthCtx), false);
  assert.equal(canCreateStudentProfile(unauthCtx, 'student_123', { id: 'student_123', role: 'student' }), false);
  assert.equal(canUpdateStudentProfile(unauthCtx, 'student_123', { role: 'student' }, { role: 'student' }), false);
  assert.equal(canDeleteStudentProfile(unauthCtx), false);

  // Quiz attempt read/write
  assert.equal(canReadQuizAttempt(unauthCtx, 'student_123'), false);
  assert.equal(canCreateQuizAttempt(unauthCtx, 'student_123', 'att_01', { userId: 'student_123', score: 90, passed: true }), false);

  // Admin collection
  assert.equal(canReadAdminDoc(unauthCtx), false);
  assert.equal(canWriteAdminDoc(), false);
});

test('Security Invariant 2: Students cannot read or modify another student private data', () => {
  const student1Ctx: FirestoreContext = {
    auth: {
      uid: 'student_alice',
      token: { email: 'alice@student.com', email_verified: true },
    },
    database: 'default',
  };

  // Alice cannot read or list Bob's profile
  assert.equal(canGetStudentProfile(student1Ctx, 'student_bob'), false);
  assert.equal(canListStudentProfiles(student1Ctx), false);

  // Alice cannot update or delete Bob's profile
  assert.equal(
    canUpdateStudentProfile(student1Ctx, 'student_bob', { role: 'student' }, { role: 'student', name: 'Hacked' }),
    false
  );
  assert.equal(canDeleteStudentProfile(student1Ctx), false);

  // Alice cannot read or submit quiz attempts for Bob
  assert.equal(canReadQuizAttempt(student1Ctx, 'student_bob'), false);
  assert.equal(
    canCreateQuizAttempt(student1Ctx, 'student_bob', 'att_fake', { userId: 'student_bob', score: 100, passed: true }),
    false
  );
});

test('Security Invariant 3: Students cannot give themselves admin access', () => {
  const attackerCtx: FirestoreContext = {
    auth: {
      uid: 'attacker_uid',
      token: { email: 'attacker@evil.com', email_verified: true },
    },
    database: 'default',
  };

  // 1. Direct client write to /admins collection is strictly forbidden
  assert.equal(canWriteAdminDoc(), false);

  // 2. Creating a profile with role: 'admin' is rejected
  assert.equal(
    canCreateStudentProfile(attackerCtx, 'attacker_uid', {
      id: 'attacker_uid',
      email: 'attacker@evil.com',
      name: 'Attacker',
      role: 'admin',
    }),
    false
  );

  // 3. Updating profile to role: 'admin' is rejected
  assert.equal(
    canUpdateStudentProfile(
      attackerCtx,
      'attacker_uid',
      { role: 'student' },
      { role: 'admin' }
    ),
    false
  );

  // 4. isAdmin evaluates to false for attacker
  assert.equal(isAdmin(attackerCtx), false);
});

test('Security Invariant 4: Only authorised admins can create, edit, publish, or delete educational content', () => {
  const studentCtx: FirestoreContext = {
    auth: { uid: 'student_1', token: { email: 'student@coinedu.in', email_verified: true } },
    database: 'default',
  };

  const unverifiedAdminCtx: FirestoreContext = {
    auth: { uid: 'spoof_uid', token: { email: 'rakshiths056@gmail.com', email_verified: false } },
    database: 'default',
  };

  const verifiedOwnerCtx: FirestoreContext = {
    auth: { uid: 'owner_uid', token: { email: 'rakshiths056@gmail.com', email_verified: true } },
    database: 'default',
  };

  // Student cannot write content
  assert.equal(canWriteEducationalContent(studentCtx), false);

  // Unverified owner email cannot write content (email_verified must be true)
  assert.equal(canWriteEducationalContent(unverifiedAdminCtx), false);

  // Verified owner can write content
  assert.equal(canWriteEducationalContent(verifiedOwnerCtx), true);
});

test('Security Invariant 5: Unpublished content and private admin data are protected, attempts are tamper-proof', () => {
  const studentCtx: FirestoreContext = {
    auth: { uid: 'student_1', token: { email: 'student@coinedu.in', email_verified: true } },
    database: 'default',
  };
  const verifiedOwnerCtx: FirestoreContext = {
    auth: { uid: 'owner_uid', token: { email: 'rakshiths056@gmail.com', email_verified: true } },
    database: 'default',
  };

  // Unpublished content cannot be read by student
  assert.equal(canReadEducationalContent(studentCtx, false), false);

  // Unpublished content can be read by admin for editing
  assert.equal(canReadEducationalContent(verifiedOwnerCtx, false), true);

  // Admin collection cannot be read by student
  assert.equal(canReadAdminDoc(studentCtx), false);

  // Admin collection can be read by admin
  assert.equal(canReadAdminDoc(verifiedOwnerCtx), true);

  // Quiz attempts are tamper-proof and immutable
  assert.equal(canUpdateOrDeleteQuizAttempt(), false);
});

test('Security Invariant 6: Legitimate student actions work without failure', () => {
  const legitimateStudentCtx: FirestoreContext = {
    auth: { uid: 'student_real_123', token: { email: 'student@domain.in', email_verified: true } },
    database: 'default',
  };

  // Can read published educational content
  assert.equal(canReadEducationalContent(legitimateStudentCtx, true), true);

  // Can create their own student profile with role: 'student'
  assert.equal(
    canCreateStudentProfile(legitimateStudentCtx, 'student_real_123', {
      id: 'student_real_123',
      email: 'student@domain.in',
      name: 'Rohan Sharma',
      role: 'student',
    }),
    true
  );

  // Can read own profile
  assert.equal(canGetStudentProfile(legitimateStudentCtx, 'student_real_123'), true);

  // Can update own profile preserving role: 'student'
  assert.equal(
    canUpdateStudentProfile(
      legitimateStudentCtx,
      'student_real_123',
      { role: 'student', name: 'Rohan Sharma' },
      { role: 'student', name: 'Rohan S.', enrolledCourses: ['crypto-basics'] }
    ),
    true
  );

  // Official certified quiz attempts are safely disabled until trusted server-side grading is deployed
  assert.equal(
    canCreateQuizAttempt(legitimateStudentCtx, 'student_real_123', 'att_1729334400', {
      attemptId: 'att_1729334400',
      userId: 'student_real_123',
      quizId: 'quiz-blockchain-101',
      score: 85,
      passed: true,
    }),
    false
  );

  // Can read own quiz attempt
  assert.equal(canReadQuizAttempt(legitimateStudentCtx, 'student_real_123'), true);
});
