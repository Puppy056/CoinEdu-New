import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDCA,
  calculateImpermanentLoss,
  calculatePortfolioAllocation,
  assessScamRisk,
} from './finance.ts';

test('DCA calculation returns correct investment and positive profit with positive return rate', () => {
  const result = calculateDCA(100, 12, 12); // $100/mo, 12 months, 12% annual rate (1% monthly)
  assert.equal(result.totalInvested, 1200);
  assert.ok(result.finalValue > 1200, 'Final value should exceed total invested');
  assert.ok(result.totalProfit > 0, 'Profit should be positive');
  assert.ok(result.roiPercentage > 0, 'ROI % should be positive');
  assert.equal(result.monthlyBreakdown.length, 12);
  assert.equal(result.monthlyBreakdown[11].invested, 1200);
});

test('DCA calculation handles zero inputs safely', () => {
  const result = calculateDCA(0, 12, 10);
  assert.equal(result.totalInvested, 0);
  assert.equal(result.finalValue, 0);
  assert.equal(result.totalProfit, 0);
});

test('Impermanent loss calculates correctly for 2x price increase (standard Uniswap v2 curve)', () => {
  // If price doubles (from 100 to 200), IL is approx -5.72%
  const result = calculateImpermanentLoss(100, 200, 10);
  assert.equal(result.priceRatio, 2);
  // IL should be approximately -5.72%
  assert.ok(result.impermanentLossPct < -5.6 && result.impermanentLossPct > -5.8, `Expected ~ -5.72, got ${result.impermanentLossPct}`);
  // Net return with 10% fee APY should be positive around 4.28%
  assert.ok(result.netReturnWithFeesPct > 4.2 && result.netReturnWithFeesPct < 4.4);
});

test('Impermanent loss is zero when price ratio does not change', () => {
  const result = calculateImpermanentLoss(100, 100, 5);
  assert.equal(result.priceRatio, 1);
  assert.equal(result.impermanentLossPct, 0);
  assert.equal(result.netReturnWithFeesPct, 5);
});

test('Portfolio allocation clamps and segments according to risk score', () => {
  const conservative = calculatePortfolioAllocation(2);
  assert.equal(conservative.riskTier, 'Conservative');
  assert.equal(conservative.allocations.btc, 45);
  assert.equal(conservative.allocations.stablecoins, 30);

  const balanced = calculatePortfolioAllocation(5);
  assert.equal(balanced.riskTier, 'Balanced');
  assert.equal(balanced.allocations.btc, 50);

  const growth = calculatePortfolioAllocation(7);
  assert.equal(growth.riskTier, 'Growth');
  assert.equal(growth.allocations.altcoins, 18);

  const highRisk = calculatePortfolioAllocation(10);
  assert.equal(highRisk.riskTier, 'High Risk');
  assert.equal(highRisk.allocations.stablecoins, 0);
});

test('Scam risk assessment flags seed phrase requests as critical scam', () => {
  const result = assessScamRisk({
    asksForSeedPhrase: true,
    guaranteedReturns: false,
    unverifiedContract: false,
    urgentTimePressure: false,
    unsolicitedDmOrAirdrop: false,
  });

  assert.equal(result.verdict, 'CRITICAL_SCAM');
  assert.equal(result.dangerScore, 100);
  assert.ok(result.flags.some(f => f.includes('seed phrase')));
});

test('Scam risk assessment evaluates clean projects as safe', () => {
  const result = assessScamRisk({
    asksForSeedPhrase: false,
    guaranteedReturns: false,
    unverifiedContract: false,
    urgentTimePressure: false,
    unsolicitedDmOrAirdrop: false,
  });

  assert.equal(result.verdict, 'SAFE');
  assert.equal(result.dangerScore, 0);
  assert.equal(result.flags.length, 0);
});
