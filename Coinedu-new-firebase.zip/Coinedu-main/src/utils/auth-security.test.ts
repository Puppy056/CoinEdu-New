import test from 'node:test';
import assert from 'node:assert/strict';

test('Security Invariant: New account creation strictly forces student role', () => {
  function sanitizeNewUserRole(requestedRole: unknown): 'student' {
    // Under no circumstances can a user self-assign or specify admin role
    return 'student';
  }

  assert.equal(sanitizeNewUserRole('admin'), 'student');
  assert.equal(sanitizeNewUserRole('superuser'), 'student');
  assert.equal(sanitizeNewUserRole(undefined), 'student');
  assert.equal(sanitizeNewUserRole('student'), 'student');
});

test('Security Invariant: Admin role verification requires exact verified email or staff list', () => {
  const PRIMARY_ADMIN_EMAIL = 'rakshiths056@gmail.com';
  const authorizedUids = new Set(['staff_valid_123']);

  function isAuthorizedAdmin(email: string, emailVerified: boolean, uid: string): boolean {
    if (!emailVerified) return false;
    if (email.toLowerCase().trim() === PRIMARY_ADMIN_EMAIL) return true;
    if (authorizedUids.has(uid)) return true;
    return false;
  }

  // Primary owner with verified email
  assert.equal(isAuthorizedAdmin('rakshiths056@gmail.com', true, 'uid_owner'), true);

  // Primary owner email with unverified token MUST be rejected
  assert.equal(isAuthorizedAdmin('rakshiths056@gmail.com', false, 'uid_owner'), false);

  // Attack: Spoofed email with similar spelling or domain
  assert.equal(isAuthorizedAdmin('rakshiths056@gmail.com.co', true, 'uid_spoof'), false);
  assert.equal(isAuthorizedAdmin('admin@coinedu.in', true, 'uid_demo'), false);

  // Authorized staff member with verified email
  assert.equal(isAuthorizedAdmin('staff@domain.com', true, 'staff_valid_123'), true);

  // Unlisted user
  assert.equal(isAuthorizedAdmin('hacker@domain.com', true, 'random_uid'), false);
});

test('Security Invariant: Multi-provider collision error returns clean actionable guidance', () => {
  function formatAuthError(errCode: string): string {
    if (errCode === 'auth/account-exists-with-different-credential') {
      return 'An account already exists with this email using password login. Please sign in with your email and password.';
    }
    if (errCode === 'auth/popup-closed-by-user') {
      return 'Sign in was cancelled.';
    }
    return 'Authentication failed.';
  }

  const collisionMsg = formatAuthError('auth/account-exists-with-different-credential');
  assert.ok(collisionMsg.includes('already exists'));
  assert.ok(collisionMsg.includes('sign in with your email and password'));

  const cancelMsg = formatAuthError('auth/popup-closed-by-user');
  assert.equal(cancelMsg, 'Sign in was cancelled.');
});
