/**
 * CoinEdu Financial & Cryptographic Logic Engine
 * Pure math and modeling functions for financial literacy, risk assessment, and crypto economics.
 */

export interface DCAResult {
  totalInvested: number;
  finalValue: number;
  totalProfit: number;
  roiPercentage: number;
  monthlyBreakdown: { month: number; invested: number; portfolioValue: number }[];
  lumpSumComparisonValue: number;
}

/**
 * Calculates Dollar Cost Averaging (DCA) performance over time
 * @param monthlyAmount Amount invested every month in USD
 * @param months Number of months invested
 * @param annualRatePercentage Expected annual return rate percentage (e.g. 15 for 15%)
 */
export function calculateDCA(
  monthlyAmount: number,
  months: number,
  annualRatePercentage: number
): DCAResult {
  if (monthlyAmount <= 0 || months <= 0) {
    return {
      totalInvested: 0,
      finalValue: 0,
      totalProfit: 0,
      roiPercentage: 0,
      monthlyBreakdown: [],
      lumpSumComparisonValue: 0,
    };
  }

  const monthlyRate = annualRatePercentage / 100 / 12;
  let runningValue = 0;
  const breakdown: { month: number; invested: number; portfolioValue: number }[] = [];

  for (let m = 1; m <= months; m++) {
    // Investment added at the beginning of the month and earns monthly return
    runningValue = (runningValue + monthlyAmount) * (1 + monthlyRate);
    breakdown.push({
      month: m,
      invested: monthlyAmount * m,
      portfolioValue: Math.round(runningValue * 100) / 100,
    });
  }

  const totalInvested = monthlyAmount * months;
  const finalValue = Math.round(runningValue * 100) / 100;
  const totalProfit = Math.round((finalValue - totalInvested) * 100) / 100;
  const roiPercentage = totalInvested > 0 ? Math.round(((finalValue - totalInvested) / totalInvested) * 10000) / 100 : 0;

  // Lump sum comparison: all money invested on Day 1
  const lumpSumComparisonValue = Math.round(totalInvested * Math.pow(1 + monthlyRate, months) * 100) / 100;

  return {
    totalInvested,
    finalValue,
    totalProfit,
    roiPercentage,
    monthlyBreakdown: breakdown,
    lumpSumComparisonValue,
  };
}

export interface ImpermanentLossResult {
  priceRatio: number;
  impermanentLossPct: number;
  poolValueVsHoldPct: number;
  netReturnWithFeesPct: number;
}

/**
 * Calculates Impermanent Loss for standard 50/50 AMM pools (Uniswap v2 formula)
 * IL = (2 * sqrt(k) / (1 + k)) - 1
 * @param initialPrice Initial token price
 * @param newPrice Future token price
 * @param feeApyEarnedPct Fee or Staking APY earned over the period (e.g. 12 for 12%)
 */
export function calculateImpermanentLoss(
  initialPrice: number,
  newPrice: number,
  feeApyEarnedPct: number = 0
): ImpermanentLossResult {
  if (initialPrice <= 0 || newPrice <= 0) {
    return {
      priceRatio: 1,
      impermanentLossPct: 0,
      poolValueVsHoldPct: 0,
      netReturnWithFeesPct: 0,
    };
  }

  const k = newPrice / initialPrice;
  const rawIL = (2 * Math.sqrt(k)) / (1 + k) - 1;
  const impermanentLossPct = Math.round(rawIL * 10000) / 100; // e.g. -5.72%
  const netReturnWithFeesPct = Math.round((impermanentLossPct + feeApyEarnedPct) * 100) / 100;

  return {
    priceRatio: Math.round(k * 100) / 100,
    impermanentLossPct,
    poolValueVsHoldPct: Math.round((1 + rawIL) * 10000) / 100,
    netReturnWithFeesPct,
  };
}

export interface PortfolioAllocation {
  riskScore: number;
  riskTier: 'Conservative' | 'Balanced' | 'Growth' | 'High Risk';
  description: string;
  allocations: {
    btc: number;
    eth: number;
    altcoins: number;
    stablecoins: number;
  };
  rebalanceFrequency: string;
}

/**
 * Generates educational crypto portfolio allocation based on risk score (1 - 10)
 */
export function calculatePortfolioAllocation(riskScore: number): PortfolioAllocation {
  const clampedScore = Math.max(1, Math.min(10, Math.round(riskScore)));

  if (clampedScore <= 3) {
    return {
      riskScore: clampedScore,
      riskTier: 'Conservative',
      description: 'Capital preservation focus: Heavily weighted in USD stablecoins and Bitcoin to minimize extreme market drawdowns.',
      allocations: {
        btc: 45,
        eth: 20,
        altcoins: 5,
        stablecoins: 30,
      },
      rebalanceFrequency: 'Quarterly',
    };
  }

  if (clampedScore <= 6) {
    return {
      riskScore: clampedScore,
      riskTier: 'Balanced',
      description: 'Core-and-satellite portfolio: High Bitcoin and Ethereum foundational exposure with tactical cash buffer.',
      allocations: {
        btc: 50,
        eth: 30,
        altcoins: 10,
        stablecoins: 10,
      },
      rebalanceFrequency: 'Semi-Annually',
    };
  }

  if (clampedScore <= 8) {
    return {
      riskScore: clampedScore,
      riskTier: 'Growth',
      description: 'Aggressive growth focus: Concentrated exposure in top crypto assets and Layer-1 protocols.',
      allocations: {
        btc: 45,
        eth: 35,
        altcoins: 18,
        stablecoins: 2,
      },
      rebalanceFrequency: 'Monthly to Quarterly',
    };
  }

  return {
    riskScore: clampedScore,
    riskTier: 'High Risk',
    description: 'High volatility frontier: Maximum upside exposure with substantial downside drawdown risk.',
    allocations: {
      btc: 30,
      eth: 35,
      altcoins: 35,
      stablecoins: 0,
    },
    rebalanceFrequency: 'Active / Monthly',
  };
}

export interface ScamAuditFactors {
  asksForSeedPhrase: boolean;
  guaranteedReturns: boolean;
  unverifiedContract: boolean;
  urgentTimePressure: boolean;
  unsolicitedDmOrAirdrop: boolean;
}

export interface ScamAuditResult {
  dangerScore: number; // 0 - 100
  verdict: 'SAFE' | 'LOW_RISK' | 'CAUTION' | 'CRITICAL_SCAM';
  flags: string[];
  recommendation: string;
}

/**
 * Evaluates Web3 transaction or project scam indicators
 */
export function assessScamRisk(factors: ScamAuditFactors): ScamAuditResult {
  const flags: string[] = [];
  let score = 0;

  if (factors.asksForSeedPhrase) {
    score += 100;
    flags.push('CRITICAL: Requesting secret recovery seed phrase or private key. 100% scam guarantee.');
  }

  if (factors.guaranteedReturns) {
    score += 40;
    flags.push('HIGH RISK: Promising "guaranteed" daily or monthly returns (Ponzi scheme hallmark).');
  }

  if (factors.unsolicitedDmOrAirdrop) {
    score += 30;
    flags.push('WARNING: Unsolicited direct message or unexpected token airdrop phishing attack.');
  }

  if (factors.urgentTimePressure) {
    score += 25;
    flags.push('WARNING: Artificial urgency ("claim within 10 minutes or forfeit tokens").');
  }

  if (factors.unverifiedContract) {
    score += 20;
    flags.push('CAUTION: Unverified smart contract source code on block explorer.');
  }

  const dangerScore = Math.min(100, score);

  let verdict: ScamAuditResult['verdict'] = 'SAFE';
  let recommendation = 'Project displays standard operational indicators. Always exercise prudence.';

  if (dangerScore >= 80) {
    verdict = 'CRITICAL_SCAM';
    recommendation = 'DO NOT INTERACT. Immediately disconnect your wallet and never sign this transaction.';
  } else if (dangerScore >= 40) {
    verdict = 'CAUTION';
    recommendation = 'Significant red flags identified. Do not commit funds or approve unlimited token spend allowances.';
  } else if (dangerScore > 0) {
    verdict = 'LOW_RISK';
    recommendation = 'Minor warning signs present. Verify contract address on official documentation.';
  }

  return {
    dangerScore,
    verdict,
    flags,
    recommendation,
  };
}
