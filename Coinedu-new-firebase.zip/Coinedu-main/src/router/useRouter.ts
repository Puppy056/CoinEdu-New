import { useState, useEffect } from 'react';

export type RouteType =
  // Public
  | { name: 'home' }
  | { name: 'courses' }
  | { name: 'course-detail'; slug: string }
  | { name: 'live-classes' }
  | { name: 'faq' }
  | { name: 'about' }
  | { name: 'contact' }
  | { name: 'login' }
  | { name: 'signup' }
  | { name: 'forgot-password' }
  | { name: 'reset-password' }
  | { name: 'privacy' }
  | { name: 'terms' }
  | { name: 'disclaimer' }
  // Legacy redirects
  | { name: 'legacy-glossary' }
  | { name: 'legacy-interactive-learning' }
  | { name: 'legacy-bookmarks' }
  // Student
  | { name: 'dashboard' }
  | { name: 'my-courses' }
  | { name: 'my-quizzes' }
  | { name: 'my-live-classes' }
  | { name: 'dictionary' }
  | { name: 'history' }
  | { name: 'learn'; lessonId: string }
  | { name: 'quiz'; quizId: string }
  | { name: 'quiz-results'; quizId: string; attemptId: string }
  | { name: 'flashcards' }
  | { name: 'flashcards-study'; setId: string }
  | { name: 'profile' }
  | { name: 'settings' }
  // Admin
  | { name: 'admin' }
  | { name: 'admin-courses' }
  | { name: 'admin-lessons' }
  | { name: 'admin-quizzes' }
  | { name: 'admin-flashcards' }
  | { name: 'admin-live-classes' }
  | { name: 'admin-glossary' }
  | { name: 'admin-notifications' }
  | { name: 'admin-students' }
  // 404
  | { name: 'not-found'; path: string };

export function parsePath(pathname: string): RouteType {
  // Strip query string if passed accidentally, then normalize trailing slashes
  const cleanPathname = pathname.split('?')[0];
  const path = cleanPathname.replace(/\/+$/, '') || '/';

  // 1. Exact static public & auth routes
  if (path === '/') return { name: 'home' };
  if (path === '/courses') return { name: 'courses' };
  if (path === '/live-classes') return { name: 'live-classes' };
  if (path === '/faq') return { name: 'faq' };
  if (path === '/about') return { name: 'about' };
  if (path === '/contact') return { name: 'contact' };
  if (path === '/login') return { name: 'login' };
  if (path === '/signup') return { name: 'signup' };
  if (path === '/forgot-password') return { name: 'forgot-password' };
  if (path === '/reset-password') return { name: 'reset-password' };
  if (path === '/privacy') return { name: 'privacy' };
  if (path === '/terms') return { name: 'terms' };
  if (path === '/disclaimer') return { name: 'disclaimer' };

  // Legacy redirects
  if (path === '/glossary') return { name: 'legacy-glossary' };
  if (path === '/interactive-learning') return { name: 'legacy-interactive-learning' };
  if (path === '/bookmarks') return { name: 'legacy-bookmarks' };

  // 2. Student exact static routes
  if (path === '/dashboard') return { name: 'dashboard' };
  if (path === '/my-courses') return { name: 'my-courses' };
  if (path === '/my-quizzes') return { name: 'my-quizzes' };
  if (path === '/my-live-classes') return { name: 'my-live-classes' };
  if (path === '/dictionary') return { name: 'dictionary' };
  if (path === '/history') return { name: 'history' };
  if (path === '/flashcards') return { name: 'flashcards' };
  if (path === '/profile') return { name: 'profile' };
  if (path === '/settings') return { name: 'settings' };

  // 3. Admin exact static routes
  if (path === '/admin') return { name: 'admin' };
  if (path === '/admin/courses') return { name: 'admin-courses' };
  if (path === '/admin/lessons') return { name: 'admin-lessons' };
  if (path === '/admin/quizzes') return { name: 'admin-quizzes' };
  if (path === '/admin/flashcards') return { name: 'admin-flashcards' };
  if (path === '/admin/live-classes') return { name: 'admin-live-classes' };
  if (path === '/admin/glossary' || path === '/admin/dictionary') return { name: 'admin-glossary' };
  if (path === '/admin/notifications') return { name: 'admin-notifications' };
  if (path === '/admin/students') return { name: 'admin-students' };

  // 4. Dynamic parameterized routes
  // /quiz/:quizId/results/:attemptId
  const quizResultsMatch = path.match(/^\/quiz\/([^/]+)\/results\/([^/]+)$/);
  if (quizResultsMatch) {
    return {
      name: 'quiz-results',
      quizId: quizResultsMatch[1],
      attemptId: quizResultsMatch[2],
    };
  }

  // /quiz/:quizId
  const quizMatch = path.match(/^\/quiz\/([^/]+)$/);
  if (quizMatch) {
    return { name: 'quiz', quizId: quizMatch[1] };
  }

  // /courses/:slug
  const courseMatch = path.match(/^\/courses\/([^/]+)$/);
  if (courseMatch) {
    return { name: 'course-detail', slug: courseMatch[1] };
  }

  // /learn/:lessonId
  const lessonMatch = path.match(/^\/learn\/([^/]+)$/);
  if (lessonMatch) {
    return { name: 'learn', lessonId: lessonMatch[1] };
  }

  // /flashcards/:setId
  const flashcardMatch = path.match(/^\/flashcards\/([^/]+)$/);
  if (flashcardMatch) {
    return { name: 'flashcards-study', setId: flashcardMatch[1] };
  }

  // Fallback: 404 Not Found
  return { name: 'not-found', path };
}

export function useRouter() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname;
    }
    return '/';
  });

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (to: string) => {
    const [targetPathname] = to.split('?');
    if (to !== window.location.pathname + window.location.search) {
      window.history.pushState(null, '', to);
      setCurrentPath(targetPathname || '/');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const currentRoute = parsePath(currentPath);

  return {
    currentPath,
    currentRoute,
    navigate,
  };
}
