import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  deleteUser,
  verifyPasswordResetCode,
  confirmPasswordReset,
} from 'firebase/auth';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  firebaseSignOut,
  onAuthStateChanged,
  FirebaseUser,
} from '../firebase/config';
import {
  syncUserProfile,
  fetchUserProfile,
  deleteUserProfileFirestore,
} from '../firebase/firestoreService';

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'admin';
  enrolledCourses: string[];
  isPrimaryOwner?: boolean;
}

export interface QuizAttemptRecord {
  attemptId: string;
  quizId: string;
  score: number;
  total: number;
  passed: boolean;
  userAnswers: Record<string, number>;
  timestamp: string;
}

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  sendPasswordReset: (email: string) => Promise<{ success: boolean; error?: string }>;
  verifyPasswordResetActionCode: (oobCode: string) => Promise<{ valid: boolean; email?: string; error?: string }>;
  completePasswordResetWithCode: (oobCode: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  updateDisplayName: (newName: string) => Promise<{ success: boolean; error?: string }>;
  deleteAccount: () => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  verifyAdmin: () => Promise<boolean>;
  enrollInCourse: (courseSlug: string) => void;
  unenrollFromCourse: (courseSlug: string) => void;
  completedLessons: string[];
  startedLessons: string[];
  markLessonComplete: (lessonId: string) => void;
  bookmarks: string[];
  toggleBookmark: (itemId: string) => void;
  lastVisitedLessonId: string | null;
  recordLessonVisit: (lessonId: string) => void;
  flashcardAssessments: Record<string, 'know' | 'review'>;
  recordFlashcardAssessment: (cardId: string, status: 'know' | 'review') => void;
  recordQuizAttempt: (attempt: QuizAttemptRecord) => void;
  quizAttempts: Record<string, QuizAttemptRecord>;
  readNotificationIds: string[];
  markNotificationRead: (notificationId: string) => void;
  markAllNotificationsRead: (notificationIds: string[]) => void;
  getVideoPlaybackTime: (lessonId: string) => number;
  saveVideoPlaybackTime: (lessonId: string, seconds: number) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function readScopedJson<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeScopedJson<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Per-student progress state (strictly isolated by authenticated user ID)
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [startedLessons, setStartedLessons] = useState<string[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [readNotificationIds, setReadNotificationIds] = useState<string[]>([]);
  const [lastVisitedLessonId, setLastVisitedLessonId] = useState<string | null>(null);
  const [flashcardAssessments, setFlashcardAssessments] = useState<Record<string, 'know' | 'review'>>({});
  const [quizAttempts, setQuizAttempts] = useState<Record<string, QuizAttemptRecord>>({});
  const [videoPositions, setVideoPositions] = useState<Record<string, number>>({});

  // Server-side strict verification of Admin Role using the real Firebase ID token
  const verifyAdminServer = async (idToken: string): Promise<{ authorized: boolean; isOwner?: boolean }> => {
    const checkLocalAdminFallback = (): { authorized: boolean; isOwner?: boolean } => {
      const fb = auth.currentUser;
      if (!fb) return { authorized: false };
      const normalizedEmail = (fb.email || '').toLowerCase().trim();
      if (normalizedEmail === 'rakshiths056@gmail.com' && fb.emailVerified) {
        return { authorized: true, isOwner: true };
      }
      if (
        fb.uid === 'liDG3eSTJuS8eTxin2JWt6SpqvD2' ||
        (normalizedEmail === 'jeffery158540@gmail.com' && fb.emailVerified)
      ) {
        return { authorized: true, isOwner: false };
      }
      return { authorized: false };
    };

    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${idToken}`,
          'Content-Type': 'application/json',
        },
      });
      if (res.ok) {
        const data = await res.json();
        return {
          authorized: Boolean(data.authorized),
          isOwner: Boolean(data.user?.isPrimaryOwner),
        };
      }
      if (res.status >= 500) {
        return checkLocalAdminFallback();
      }
      return { authorized: false };
    } catch {
      return checkLocalAdminFallback();
    }
  };

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentFbUser) => {
      setFirebaseUser(currentFbUser);

      if (currentFbUser) {
        try {
          const uid = currentFbUser.uid;
          const idToken = await currentFbUser.getIdToken();
          setToken(idToken);
          try {
            localStorage.setItem('coinedu_auth_token', idToken);
          } catch {}

          // Verify role strictly with server API
          const adminCheck = await verifyAdminServer(idToken);
          const role: 'student' | 'admin' = adminCheck.authorized ? 'admin' : 'student';

          // Retrieve user profile from Firestore if exists
          const existingProfile = await fetchUserProfile(uid).catch(() => null);

          // Load per-user local cache & merge with Firestore profile for this user only
          const cachedCompleted = readScopedJson<string[]>(`coinedu_completed_${uid}`, []);
          const mergedCompleted = Array.from(
            new Set([...(existingProfile?.completedLessons || []), ...cachedCompleted])
          );
          setCompletedLessons(mergedCompleted);
          writeScopedJson(`coinedu_completed_${uid}`, mergedCompleted);

          const cachedStarted = readScopedJson<string[]>(`coinedu_started_${uid}`, []);
          const mergedStarted = Array.from(
            new Set([
              ...(existingProfile?.startedLessons || []),
              ...cachedStarted,
              ...mergedCompleted,
              ...(existingProfile?.lastVisitedLessonId ? [existingProfile.lastVisitedLessonId] : []),
            ])
          );
          setStartedLessons(mergedStarted);
          writeScopedJson(`coinedu_started_${uid}`, mergedStarted);

          const cachedBookmarks = readScopedJson<string[]>(`coinedu_bookmarks_${uid}`, []);
          const mergedBookmarks = Array.from(
            new Set([...(existingProfile?.bookmarks || []), ...cachedBookmarks])
          );
          setBookmarks(mergedBookmarks);
          writeScopedJson(`coinedu_bookmarks_${uid}`, mergedBookmarks);

          const cachedReadNotifs = readScopedJson<string[]>(`coinedu_read_notifs_${uid}`, []);
          const mergedReadNotifs = Array.from(
            new Set([...(existingProfile?.readNotificationIds || []), ...cachedReadNotifs])
          );
          setReadNotificationIds(mergedReadNotifs);
          writeScopedJson(`coinedu_read_notifs_${uid}`, mergedReadNotifs);

          const cachedLastVisited = localStorage.getItem(`coinedu_last_visited_${uid}`) || null;
          const resolvedLastVisited = existingProfile?.lastVisitedLessonId || cachedLastVisited || null;
          setLastVisitedLessonId(resolvedLastVisited);
          if (resolvedLastVisited) {
            try {
              localStorage.setItem(`coinedu_last_visited_${uid}`, resolvedLastVisited);
            } catch {}
          }

          const cachedEnrolled = readScopedJson<string[]>(`coinedu_enrolled_${uid}`, []);
          const mergedEnrolled = Array.from(
            new Set([...(existingProfile?.enrolledCourses || []), ...cachedEnrolled])
          );
          writeScopedJson(`coinedu_enrolled_${uid}`, mergedEnrolled);

          const cachedFlashcards = readScopedJson<Record<string, 'know' | 'review'>>(
            `coinedu_flashcards_${uid}`,
            {}
          );
          setFlashcardAssessments(cachedFlashcards);

          const cachedAttempts = readScopedJson<Record<string, QuizAttemptRecord>>(
            `coinedu_quiz_attempts_${uid}`,
            {}
          );
          setQuizAttempts(cachedAttempts);

          const cachedVideoPos = readScopedJson<Record<string, number>>(
            `coinedu_video_pos_${uid}`,
            {}
          );
          setVideoPositions(cachedVideoPos);

          const appUser: User = {
            id: uid,
            email: (currentFbUser.email || '').toLowerCase().trim(),
            name:
              existingProfile?.name ||
              currentFbUser.displayName ||
              currentFbUser.email?.split('@')[0] ||
              'Learner',
            role,
            enrolledCourses: mergedEnrolled,
            isPrimaryOwner: adminCheck.isOwner,
          };

          setUser(appUser);

          // Sync student profile in Firestore
          await syncUserProfile({
            id: appUser.id,
            email: appUser.email,
            name: appUser.name,
            role: appUser.role,
            enrolledCourses: appUser.enrolledCourses,
            completedLessons: mergedCompleted,
            startedLessons: mergedStarted,
            bookmarks: mergedBookmarks,
            readNotificationIds: mergedReadNotifs,
            ...(resolvedLastVisited ? { lastVisitedLessonId: resolvedLastVisited } : {}),
          }).catch((err) => {
            console.warn('Could not sync user profile to Firestore:', err);
          });
        } catch (err) {
          console.error('Error hydrating authenticated user session:', err);
          setUser(null);
          setToken(null);
        } finally {
          setIsLoading(false);
        }
      } else {
        setUser(null);
        setToken(null);
        setCompletedLessons([]);
        setStartedLessons([]);
        setBookmarks([]);
        setReadNotificationIds([]);
        setLastVisitedLessonId(null);
        setFlashcardAssessments({});
        setQuizAttempts({});
        setVideoPositions({});
        setIsLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Google Sign-In with explicit multi-provider conflict handling
  const loginWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const idToken = await fbUser.getIdToken();
      try {
        localStorage.setItem('coinedu_auth_token', idToken);
      } catch {}

      const adminCheck = await verifyAdminServer(idToken);
      const role: 'student' | 'admin' = adminCheck.authorized ? 'admin' : 'student';

      const existingProfile = await fetchUserProfile(fbUser.uid).catch(() => null);
      const cachedEnrolled = readScopedJson<string[]>(`coinedu_enrolled_${fbUser.uid}`, []);
      const mergedEnrolled = Array.from(
        new Set([...(existingProfile?.enrolledCourses || []), ...cachedEnrolled])
      );
      const resolvedLastVisited = existingProfile?.lastVisitedLessonId || null;

      const appUser: User = {
        id: fbUser.uid,
        email: (fbUser.email || '').toLowerCase().trim(),
        name: existingProfile?.name || fbUser.displayName || 'Learner',
        role,
        enrolledCourses: mergedEnrolled,
        isPrimaryOwner: adminCheck.isOwner,
      };

      setUser(appUser);
      setToken(idToken);

      await syncUserProfile({
        id: appUser.id,
        email: appUser.email,
        name: appUser.name,
        role: appUser.role,
        enrolledCourses: mergedEnrolled,
        completedLessons: existingProfile?.completedLessons || [],
        startedLessons: existingProfile?.startedLessons || [],
        bookmarks: existingProfile?.bookmarks || [],
        readNotificationIds: existingProfile?.readNotificationIds || [],
        ...(resolvedLastVisited ? { lastVisitedLessonId: resolvedLastVisited } : {}),
      }).catch(() => null);

      return { success: true };
    } catch (err: any) {
      console.error('Google Sign-In Error:', err);
      if (err.code === 'auth/account-exists-with-different-credential') {
        return {
          success: false,
          error:
            'An account already exists with this email using password login. Please sign in with your email and password.',
        };
      }
      if (err.code === 'auth/popup-closed-by-user') {
        return { success: false, error: 'Sign in was cancelled.' };
      }
      return {
        success: false,
        error: err.message || 'Google Sign-In failed. Please try again.',
      };
    }
  };

  // Real Email/Password Login via Firebase Auth
  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      const idToken = await cred.user.getIdToken();
      try {
        localStorage.setItem('coinedu_auth_token', idToken);
      } catch {}

      const adminCheck = await verifyAdminServer(idToken);
      const role: 'student' | 'admin' = adminCheck.authorized ? 'admin' : 'student';

      const appUser: User = {
        id: cred.user.uid,
        email: (cred.user.email || '').toLowerCase().trim(),
        name: cred.user.displayName || email.split('@')[0],
        role,
        enrolledCourses: [],
        isPrimaryOwner: adminCheck.isOwner,
      };

      setUser(appUser);
      setToken(idToken);

      return { success: true };
    } catch (err: any) {
      console.error('Email sign in error:', err);
      if (
        err.code === 'auth/user-not-found' ||
        err.code === 'auth/wrong-password' ||
        err.code === 'auth/invalid-credential'
      ) {
        return { success: false, error: 'Incorrect email or password. Please try again.' };
      }
      if (err.code === 'auth/too-many-requests') {
        return { success: false, error: 'Too many unsuccessful attempts. Please try again later.' };
      }
      return { success: false, error: err.message || 'Sign in failed.' };
    }
  };

  // Real Email/Password Registration via Firebase Auth
  const register = async (
    email: string,
    password: string,
    name: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      if (name.trim()) {
        await updateProfile(cred.user, { displayName: name.trim() });
      }

      const idToken = await cred.user.getIdToken();
      try {
        localStorage.setItem('coinedu_auth_token', idToken);
      } catch {}

      const appUser: User = {
        id: cred.user.uid,
        email: (cred.user.email || '').toLowerCase().trim(),
        name: name.trim() || email.split('@')[0],
        role: 'student',
        enrolledCourses: [],
      };

      setUser(appUser);
      setToken(idToken);

      await syncUserProfile({
        id: appUser.id,
        email: appUser.email,
        name: appUser.name,
        role: 'student',
        enrolledCourses: [],
        completedLessons: [],
        startedLessons: [],
        bookmarks: [],
        readNotificationIds: [],
      }).catch(() => null);

      return { success: true };
    } catch (err: any) {
      console.error('Registration error:', err);
      if (err.code === 'auth/email-already-in-use') {
        return {
          success: false,
          error: 'An account already exists with this email address. Please sign in.',
        };
      }
      if (err.code === 'auth/weak-password') {
        return {
          success: false,
          error: 'Password should be at least 6 characters.',
        };
      }
      return { success: false, error: err.message || 'Registration failed.' };
    }
  };

  // Real Password Reset Email via Firebase Auth
  const sendPasswordReset = async (email: string): Promise<{ success: boolean; error?: string }> => {
    const trimmed = email.trim();
    if (!trimmed || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    try {
      const actionCodeSettings =
        typeof window !== 'undefined'
          ? {
              url: `${window.location.origin}/reset-password`,
              handleCodeInApp: false,
            }
          : undefined;
      try {
        await sendPasswordResetEmail(auth, trimmed, actionCodeSettings);
      } catch (innerErr: any) {
        // Fallback if continue URL domain is not yet whitelisted in Firebase Console
        if (innerErr?.code === 'auth/unauthorized-continue-uri' || innerErr?.code === 'auth/invalid-continue-uri') {
          await sendPasswordResetEmail(auth, trimmed);
        } else {
          throw innerErr;
        }
      }
      return { success: true };
    } catch (err: any) {
      console.error('Password reset error:', err);
      // Do not reveal whether a specific email address exists in the system
      if (err.code === 'auth/user-not-found') {
        return { success: true };
      }
      if (err.code === 'auth/invalid-email') {
        return { success: false, error: 'Please enter a valid email address.' };
      }
      if (err.code === 'auth/too-many-requests') {
        return {
          success: false,
          error: 'Too many reset requests. Please wait a few minutes before trying again.',
        };
      }
      return {
        success: false,
        error: 'Unable to send reset link right now. Please check your connection and try again.',
      };
    }
  };

  // Verify a Firebase password reset action code (oobCode)
  const verifyPasswordResetActionCode = async (
    oobCode: string
  ): Promise<{ valid: boolean; email?: string; error?: string }> => {
    if (!oobCode || !oobCode.trim()) {
      return {
        valid: false,
        error: 'Missing password reset code. Please request a new password reset link.',
      };
    }
    try {
      const accountEmail = await verifyPasswordResetCode(auth, oobCode.trim());
      return { valid: true, email: accountEmail };
    } catch (err: any) {
      if (err.code === 'auth/expired-action-code') {
        return {
          valid: false,
          error: 'This password reset link has expired. Please request a fresh reset link.',
        };
      }
      if (err.code === 'auth/invalid-action-code') {
        return {
          valid: false,
          error: 'This password reset link is invalid or has already been used.',
        };
      }
      return {
        valid: false,
        error: 'Unable to verify this password reset link. Please request a new one.',
      };
    }
  };

  // Complete password reset using Firebase confirmPasswordReset
  const completePasswordResetWithCode = async (
    oobCode: string,
    newPassword: string
  ): Promise<{ success: boolean; error?: string }> => {
    if (!oobCode || !oobCode.trim()) {
      return { success: false, error: 'Invalid or missing reset code.' };
    }
    if (!newPassword || newPassword.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }
    try {
      await confirmPasswordReset(auth, oobCode.trim(), newPassword);
      return { success: true };
    } catch (err: any) {
      if (err.code === 'auth/expired-action-code') {
        return {
          success: false,
          error: 'This password reset link has expired. Please request a new link.',
        };
      }
      if (err.code === 'auth/invalid-action-code') {
        return {
          success: false,
          error: 'This password reset link is invalid or has already been used.',
        };
      }
      if (err.code === 'auth/weak-password') {
        return {
          success: false,
          error: 'Please choose a stronger password (at least 6 characters).',
        };
      }
      return {
        success: false,
        error: err.message || 'Could not reset password. Please request a new reset link.',
      };
    }
  };

  // Update Display Name
  const updateDisplayName = async (newName: string): Promise<{ success: boolean; error?: string }> => {
    const trimmed = newName.trim();
    if (!trimmed) {
      return { success: false, error: 'Display name cannot be empty.' };
    }
    if (!user) {
      return { success: false, error: 'You must be signed in to update your profile.' };
    }
    try {
      if (firebaseUser) {
        await updateProfile(firebaseUser, { displayName: trimmed }).catch(() => null);
      }
      const updatedUser: User = { ...user, name: trimmed };
      setUser(updatedUser);
      await syncUserProfile({
        id: updatedUser.id,
        email: updatedUser.email,
        name: updatedUser.name,
        role: updatedUser.role,
        enrolledCourses: updatedUser.enrolledCourses,
        completedLessons,
        startedLessons,
        bookmarks,
        readNotificationIds,
        ...(lastVisitedLessonId ? { lastVisitedLessonId } : {}),
      }).catch(() => null);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update display name.' };
    }
  };

  // Secure Account Deletion
  const deleteAccount = async (): Promise<{ success: boolean; error?: string }> => {
    if (!user) {
      return { success: false, error: 'Not signed in.' };
    }
    try {
      const uid = user.id;
      localStorage.removeItem(`coinedu_completed_${uid}`);
      localStorage.removeItem(`coinedu_started_${uid}`);
      localStorage.removeItem(`coinedu_bookmarks_${uid}`);
      localStorage.removeItem(`coinedu_read_notifs_${uid}`);
      localStorage.removeItem(`coinedu_last_visited_${uid}`);
      localStorage.removeItem(`coinedu_enrolled_${uid}`);
      localStorage.removeItem(`coinedu_flashcards_${uid}`);
      localStorage.removeItem(`coinedu_quiz_attempts_${uid}`);
      localStorage.removeItem(`coinedu_video_pos_${uid}`);
      localStorage.removeItem('coinedu_auth_token');

      setCompletedLessons([]);
      setStartedLessons([]);
      setBookmarks([]);
      setReadNotificationIds([]);
      setLastVisitedLessonId(null);
      setFlashcardAssessments({});
      setQuizAttempts({});
      setVideoPositions({});

      await deleteUserProfileFirestore(uid).catch(() => null);

      if (firebaseUser) {
        try {
          await deleteUser(firebaseUser);
        } catch {
          await firebaseSignOut(auth);
        }
      } else {
        await firebaseSignOut(auth);
      }

      setUser(null);
      setFirebaseUser(null);
      setToken(null);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Could not complete account deletion.' };
    }
  };

  const logout = async () => {
    try {
      await firebaseSignOut(auth);
      localStorage.removeItem('coinedu_auth_token');
    } catch {}
    setUser(null);
    setFirebaseUser(null);
    setToken(null);
    setCompletedLessons([]);
    setStartedLessons([]);
    setBookmarks([]);
    setReadNotificationIds([]);
    setLastVisitedLessonId(null);
    setFlashcardAssessments({});
    setQuizAttempts({});
    setVideoPositions({});
  };

  // Verify Admin via server
  const verifyAdmin = async (): Promise<boolean> => {
    if (!token) return false;
    const check = await verifyAdminServer(token);
    return check.authorized;
  };

  const enrollInCourse = (courseSlug: string) => {
    if (!user) return;
    if (user.enrolledCourses.includes(courseSlug)) return;
    const updatedCourses = [...user.enrolledCourses, courseSlug];
    setUser({
      ...user,
      enrolledCourses: updatedCourses,
    });
    writeScopedJson(`coinedu_enrolled_${user.id}`, updatedCourses);
    syncUserProfile({
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      enrolledCourses: updatedCourses,
      completedLessons,
      startedLessons,
      bookmarks,
      readNotificationIds,
      ...(lastVisitedLessonId ? { lastVisitedLessonId } : {}),
    }).catch(() => null);
  };

  const unenrollFromCourse = (courseSlug: string) => {
    if (!user) return;
    const updatedCourses = user.enrolledCourses.filter((s) => s !== courseSlug);
    setUser({
      ...user,
      enrolledCourses: updatedCourses,
    });
    writeScopedJson(`coinedu_enrolled_${user.id}`, updatedCourses);
    syncUserProfile({
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      enrolledCourses: updatedCourses,
      completedLessons,
      startedLessons,
      bookmarks,
      readNotificationIds,
      ...(lastVisitedLessonId ? { lastVisitedLessonId } : {}),
    }).catch(() => null);
  };

  const markLessonComplete = (lessonId: string) => {
    const updatedCompleted = completedLessons.includes(lessonId)
      ? completedLessons
      : [...completedLessons, lessonId];
    const updatedStarted = startedLessons.includes(lessonId)
      ? startedLessons
      : [...startedLessons, lessonId];

    setCompletedLessons(updatedCompleted);
    setStartedLessons(updatedStarted);

    if (user) {
      writeScopedJson(`coinedu_completed_${user.id}`, updatedCompleted);
      writeScopedJson(`coinedu_started_${user.id}`, updatedStarted);
      syncUserProfile({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        enrolledCourses: user.enrolledCourses,
        completedLessons: updatedCompleted,
        startedLessons: updatedStarted,
        bookmarks,
        readNotificationIds,
        ...(lastVisitedLessonId ? { lastVisitedLessonId } : {}),
      }).catch(() => null);
    }
  };

  const toggleBookmark = (itemId: string) => {
    setBookmarks((prev) => {
      const exists = prev.includes(itemId);
      const updated = exists ? prev.filter((id) => id !== itemId) : [...prev, itemId];
      if (user) {
        writeScopedJson(`coinedu_bookmarks_${user.id}`, updated);
        syncUserProfile({
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          enrolledCourses: user.enrolledCourses,
          completedLessons,
          startedLessons,
          bookmarks: updated,
          readNotificationIds,
          ...(lastVisitedLessonId ? { lastVisitedLessonId } : {}),
        }).catch(() => null);
      }
      return updated;
    });
  };

  const recordLessonVisit = (lessonId: string) => {
    setLastVisitedLessonId(lessonId);
    const updatedStarted = startedLessons.includes(lessonId)
      ? startedLessons
      : [...startedLessons, lessonId];
    setStartedLessons(updatedStarted);

    if (user) {
      try {
        localStorage.setItem(`coinedu_last_visited_${user.id}`, lessonId);
      } catch {}
      writeScopedJson(`coinedu_started_${user.id}`, updatedStarted);
      syncUserProfile({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        enrolledCourses: user.enrolledCourses,
        completedLessons,
        startedLessons: updatedStarted,
        bookmarks,
        readNotificationIds,
        lastVisitedLessonId: lessonId,
      }).catch(() => null);
    }
  };

  const recordFlashcardAssessment = (cardId: string, status: 'know' | 'review') => {
    setFlashcardAssessments((prev) => {
      const updated = { ...prev, [cardId]: status };
      if (user) {
        writeScopedJson(`coinedu_flashcards_${user.id}`, updated);
      }
      return updated;
    });
  };

  const recordQuizAttempt = (attempt: QuizAttemptRecord) => {
    setQuizAttempts((prev) => {
      const updated = {
        ...prev,
        [attempt.attemptId]: attempt,
      };
      if (user) {
        writeScopedJson(`coinedu_quiz_attempts_${user.id}`, updated);
      }
      return updated;
    });
  };

  const markNotificationRead = (notificationId: string) => {
    if (!notificationId) return;
    setReadNotificationIds((prev) => {
      if (prev.includes(notificationId)) return prev;
      const updated = [...prev, notificationId];
      if (user) {
        writeScopedJson(`coinedu_read_notifs_${user.id}`, updated);
        syncUserProfile({
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          enrolledCourses: user.enrolledCourses,
          completedLessons,
          startedLessons,
          bookmarks,
          readNotificationIds: updated,
          ...(lastVisitedLessonId ? { lastVisitedLessonId } : {}),
        }).catch(() => null);
      }
      return updated;
    });
  };

  const markAllNotificationsRead = (notificationIds: string[]) => {
    if (!notificationIds || notificationIds.length === 0) return;
    setReadNotificationIds((prev) => {
      const updated = Array.from(new Set([...prev, ...notificationIds]));
      if (user) {
        writeScopedJson(`coinedu_read_notifs_${user.id}`, updated);
        syncUserProfile({
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          enrolledCourses: user.enrolledCourses,
          completedLessons,
          startedLessons,
          bookmarks,
          readNotificationIds: updated,
          ...(lastVisitedLessonId ? { lastVisitedLessonId } : {}),
        }).catch(() => null);
      }
      return updated;
    });
  };

  const getVideoPlaybackTime = (lessonId: string): number => {
    return videoPositions[lessonId] || 0;
  };

  const saveVideoPlaybackTime = (lessonId: string, seconds: number) => {
    if (!lessonId || Number.isNaN(seconds) || seconds < 0) return;
    setVideoPositions((prev) => {
      const rounded = Math.floor(seconds);
      if (prev[lessonId] === rounded) return prev;
      const updated = { ...prev, [lessonId]: rounded };
      if (user) {
        writeScopedJson(`coinedu_video_pos_${user.id}`, updated);
      }
      return updated;
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        firebaseUser,
        token,
        isLoading,
        login,
        loginWithGoogle,
        register,
        sendPasswordReset,
        verifyPasswordResetActionCode,
        completePasswordResetWithCode,
        updateDisplayName,
        deleteAccount,
        logout,
        verifyAdmin,
        enrollInCourse,
        unenrollFromCourse,
        completedLessons,
        startedLessons,
        markLessonComplete,
        bookmarks,
        toggleBookmark,
        lastVisitedLessonId,
        recordLessonVisit,
        flashcardAssessments,
        recordFlashcardAssessment,
        recordQuizAttempt,
        quizAttempts,
        readNotificationIds,
        markNotificationRead,
        markAllNotificationsRead,
        getVideoPlaybackTime,
        saveVideoPlaybackTime,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
