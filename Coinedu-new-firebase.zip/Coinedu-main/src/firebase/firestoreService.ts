import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './config';
import type {
  CourseDetail,
  LessonItem,
  QuizData,
  FlashcardSet,
  LiveClassItem,
  GlossaryItem,
  NotificationItem,
} from '../data/learningPlatform';

export interface UserProfileDoc {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'admin';
  enrolledCourses?: string[];
  completedLessons?: string[];
  startedLessons?: string[];
  bookmarks?: string[];
  readNotificationIds?: string[];
  lastVisitedLessonId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface QuizAttemptDoc {
  attemptId: string;
  userId: string;
  quizId: string;
  score: number;
  total: number;
  passed: boolean;
  userAnswers: Record<string, number>;
  timestamp: string;
}

/**
 * Recursively removes keys with `undefined` values from objects and arrays
 * so Firestore setDoc() never throws "Unsupported field value: undefined".
 */
export function sanitizeFirestorePayload<T>(value: T): T {
  if (value === null || value === undefined || typeof value !== 'object') {
    return value;
  }

  if (Array.isArray(value)) {
    return value
      .filter((item) => item !== undefined)
      .map((item) => sanitizeFirestorePayload(item)) as unknown as T;
  }

  const cleaned: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
    if (val !== undefined) {
      cleaned[key] = sanitizeFirestorePayload(val);
    }
  }
  return cleaned as T;
}

// 1. Sync User Profile in Firestore
export async function syncUserProfile(profile: UserProfileDoc): Promise<void> {
  const path = `users/${profile.id}`;
  try {
    const userRef = doc(db, 'users', profile.id);
    const payload = sanitizeFirestorePayload({
      ...profile,
      updatedAt: new Date().toISOString(),
    });
    await setDoc(userRef, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// 2. Fetch User Profile from Firestore
export async function fetchUserProfile(userId: string): Promise<UserProfileDoc | null> {
  const path = `users/${userId}`;
  try {
    const userRef = doc(db, 'users', userId);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as UserProfileDoc;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

// 2b. Delete User Profile from Firestore (if permitted)
export async function deleteUserProfileFirestore(userId: string): Promise<void> {
  const path = `users/${userId}`;
  try {
    const userRef = doc(db, 'users', userId);
    await deleteDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// 3. Save Quiz Attempt in Firestore
export async function saveQuizAttemptFirestore(attempt: QuizAttemptDoc): Promise<void> {
  const path = `users/${attempt.userId}/quizAttempts/${attempt.attemptId}`;
  try {
    const ref = doc(db, 'users', attempt.userId, 'quizAttempts', attempt.attemptId);
    await setDoc(ref, sanitizeFirestorePayload(attempt));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// 4. Educational Content: Courses
export async function fetchCoursesFirestore(includeUnpublished = false): Promise<CourseDetail[]> {
  const path = 'courses';
  try {
    const colRef = collection(db, 'courses');
    const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
    const snapshot = await getDocs(q);
    const courses: CourseDetail[] = [];
    snapshot.forEach((d) => {
      courses.push(d.data() as CourseDetail);
    });
    return courses;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function saveCourseFirestore(course: CourseDetail): Promise<void> {
  const path = `courses/${course.slug}`;
  try {
    const ref = doc(db, 'courses', course.slug);
    await setDoc(
      ref,
      sanitizeFirestorePayload({
        ...course,
        updatedAt: new Date().toISOString(),
      })
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteCourseFirestore(slug: string): Promise<void> {
  const path = `courses/${slug}`;
  try {
    const ref = doc(db, 'courses', slug);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// 5. Educational Content: Quizzes
export async function fetchQuizzesFirestore(includeUnpublished = false): Promise<Record<string, QuizData>> {
  const path = 'quizzes';
  try {
    const colRef = collection(db, 'quizzes');
    const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
    const snapshot = await getDocs(q);
    const quizzes: Record<string, QuizData> = {};
    snapshot.forEach((d) => {
      const data = d.data() as QuizData;
      quizzes[data.quizId] = data;
    });
    return quizzes;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function saveQuizFirestore(quiz: QuizData): Promise<void> {
  const path = `quizzes/${quiz.quizId}`;
  try {
    const ref = doc(db, 'quizzes', quiz.quizId);
    await setDoc(ref, sanitizeFirestorePayload(quiz));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteQuizFirestore(quizId: string): Promise<void> {
  const path = `quizzes/${quizId}`;
  try {
    const ref = doc(db, 'quizzes', quizId);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// 6. Educational Content: Flashcards
export async function fetchFlashcardsFirestore(includeUnpublished = false): Promise<Record<string, FlashcardSet>> {
  const path = 'flashcards';
  try {
    const colRef = collection(db, 'flashcards');
    const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
    const snapshot = await getDocs(q);
    const flashcards: Record<string, FlashcardSet> = {};
    snapshot.forEach((d) => {
      const data = d.data() as FlashcardSet;
      flashcards[data.setId] = data;
    });
    return flashcards;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function saveFlashcardSetFirestore(set: FlashcardSet): Promise<void> {
  const path = `flashcards/${set.setId}`;
  try {
    const ref = doc(db, 'flashcards', set.setId);
    await setDoc(ref, sanitizeFirestorePayload(set));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteFlashcardSetFirestore(setId: string): Promise<void> {
  const path = `flashcards/${setId}`;
  try {
    const ref = doc(db, 'flashcards', setId);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// 7. Educational Content: Live Classes
export async function fetchLiveClassesFirestore(includeUnpublished = false): Promise<LiveClassItem[]> {
  const path = 'liveClasses';
  try {
    const colRef = collection(db, 'liveClasses');
    const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
    const snapshot = await getDocs(q);
    const classes: LiveClassItem[] = [];
    snapshot.forEach((d) => {
      classes.push(d.data() as LiveClassItem);
    });
    return classes;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function saveLiveClassFirestore(item: LiveClassItem): Promise<void> {
  const path = `liveClasses/${item.id}`;
  try {
    const ref = doc(db, 'liveClasses', item.id);
    await setDoc(ref, sanitizeFirestorePayload(item));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteLiveClassFirestore(id: string): Promise<void> {
  const path = `liveClasses/${id}`;
  try {
    const ref = doc(db, 'liveClasses', id);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// 8. Educational Content: Dictionary (Glossary)
export async function fetchGlossaryFirestore(includeUnpublished = false): Promise<GlossaryItem[]> {
  const path = 'glossary';
  try {
    const colRef = collection(db, 'glossary');
    const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
    const snapshot = await getDocs(q);
    const terms: GlossaryItem[] = [];
    snapshot.forEach((d) => {
      terms.push(d.data() as GlossaryItem);
    });
    return terms;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function saveGlossaryItemFirestore(item: GlossaryItem): Promise<void> {
  const termSlug = item.term.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const path = `glossary/${termSlug}`;
  try {
    const ref = doc(db, 'glossary', termSlug);
    await setDoc(ref, sanitizeFirestorePayload(item));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteGlossaryItemFirestore(term: string): Promise<void> {
  const termSlug = term.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const path = `glossary/${termSlug}`;
  try {
    const ref = doc(db, 'glossary', termSlug);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// 8b. Platform Announcements / Notifications
export async function saveNotificationFirestore(notification: NotificationItem): Promise<void> {
  const path = `notifications/${notification.id}`;
  try {
    const ref = doc(db, 'notifications', notification.id);
    await setDoc(ref, sanitizeFirestorePayload(notification));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteNotificationFirestore(id: string): Promise<void> {
  const path = `notifications/${id}`;
  try {
    const ref = doc(db, 'notifications', id);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// 9. Real-time Listeners
export function subscribeToCourses(
  onUpdate: (courses: CourseDetail[]) => void,
  includeUnpublished = false
): () => void {
  const path = 'courses';
  const colRef = collection(db, 'courses');
  const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
  return onSnapshot(
    q,
    (snap) => {
      const courses: CourseDetail[] = [];
      snap.forEach((d) => courses.push(d.data() as CourseDetail));
      onUpdate(courses);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export function subscribeToQuizzes(
  onUpdate: (quizzes: Record<string, QuizData>) => void,
  includeUnpublished = false
): () => void {
  const path = 'quizzes';
  const colRef = collection(db, 'quizzes');
  const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
  return onSnapshot(
    q,
    (snap) => {
      const quizzes: Record<string, QuizData> = {};
      snap.forEach((d) => {
        const data = d.data() as QuizData;
        if (data?.quizId) quizzes[data.quizId] = data;
      });
      onUpdate(quizzes);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export function subscribeToFlashcards(
  onUpdate: (flashcards: Record<string, FlashcardSet>) => void,
  includeUnpublished = false
): () => void {
  const path = 'flashcards';
  const colRef = collection(db, 'flashcards');
  const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
  return onSnapshot(
    q,
    (snap) => {
      const flashcards: Record<string, FlashcardSet> = {};
      snap.forEach((d) => {
        const data = d.data() as FlashcardSet;
        if (data?.setId) flashcards[data.setId] = data;
      });
      onUpdate(flashcards);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export function subscribeToLiveClasses(
  onUpdate: (liveClasses: LiveClassItem[]) => void,
  includeUnpublished = false
): () => void {
  const path = 'liveClasses';
  const colRef = collection(db, 'liveClasses');
  const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
  return onSnapshot(
    q,
    (snap) => {
      const classes: LiveClassItem[] = [];
      snap.forEach((d) => classes.push(d.data() as LiveClassItem));
      onUpdate(classes);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export function subscribeToGlossary(
  onUpdate: (terms: GlossaryItem[]) => void,
  includeUnpublished = false
): () => void {
  const path = 'glossary';
  const colRef = collection(db, 'glossary');
  const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
  return onSnapshot(
    q,
    (snap) => {
      const terms: GlossaryItem[] = [];
      snap.forEach((d) => terms.push(d.data() as GlossaryItem));
      onUpdate(terms);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export function subscribeToNotifications(
  onUpdate: (notifications: NotificationItem[]) => void,
  includeUnpublished = false
): () => void {
  const path = 'notifications';
  const colRef = collection(db, 'notifications');
  const q = includeUnpublished ? colRef : query(colRef, where('published', '==', true));
  return onSnapshot(
    q,
    (snap) => {
      const items: NotificationItem[] = [];
      snap.forEach((d) => items.push(d.data() as NotificationItem));
      onUpdate(items);
    },
    (err) => {
      // Until the updated firestore.rules (/notifications/{notificationId}) is approved and deployed
      // to live Firebase per Section 28, fall back cleanly without throwing a console error.
      if (err && (err as { code?: string }).code === 'permission-denied') {
        return;
      }
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}
