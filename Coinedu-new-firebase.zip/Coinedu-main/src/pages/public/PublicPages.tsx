import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  useContentStore,
  COURSE_CATEGORIES,
  filterRecommendedCourses,
  calculateCourseProgress,
} from '../../data/learningPlatform';
import { Hero } from '../../components/Hero';
import { GlossarySection } from '../../components/GlossarySection';
import {
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  FileText,
  Video,
  Send,
  HelpCircle,
  ChevronRight,
  ChevronDown,
  Plus,
  Search,
  ShieldAlert,
  Presentation,
  Award,
  Layers,
  Users,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

interface NavigationProps {
  navigate: (to: string) => void;
}

// 1. Home Page
export const HomePage: React.FC<NavigationProps> = ({ navigate }) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses } = useContentStore(isAdmin);
  const recommendedCourses = filterRecommendedCourses(courses);

  return (
    <div className="animate-fade-in">
      <Hero onExploreTracks={() => navigate('/courses')} />

      {/* Recommended Courses Preview */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800/80">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">
              Curated Learning Tracks
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              Recommended Courses
            </h2>
          </div>
          <div className="flex items-center gap-3">
            {isAdmin && (
              <button
                onClick={() => navigate('/admin/courses')}
                className="btn-interactive inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Manage Courses</span>
              </button>
            )}
            <button
              onClick={() => navigate('/courses')}
              className="btn-interactive inline-flex items-center gap-1.5 text-sm font-semibold text-cyan-400 hover:text-cyan-300 cursor-pointer"
            >
              <span>View Recommended Courses</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {recommendedCourses.length === 0 ? (
          <div className="text-center py-16 bg-[#0b1329] rounded-2xl border border-slate-800 p-8 max-w-2xl mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-cyan-950/50 border border-cyan-800/40 flex items-center justify-center text-cyan-400 mx-auto mb-4">
              <BookOpen className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">
              No recommended courses yet. Check back soon.
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-6">
              Courses marked as recommended and published by administrators will appear here.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              {isAdmin && (
                <button
                  onClick={() => navigate('/admin/courses')}
                  className="btn-interactive inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Course</span>
                </button>
              )}
              <button
                onClick={() => navigate('/live-classes')}
                className="btn-interactive inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
              >
                <span>How Live Classes Work</span>
              </button>
              <button
                onClick={() => navigate('/faq')}
                className="btn-interactive inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
              >
                <span>Beginner FAQ</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendedCourses.map((course) => (
              <div
                key={course.slug}
                onClick={() => navigate(`/courses/${course.slug}`)}
                className="card-interactive bg-[#0b1329] border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-6 cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3 text-xs text-slate-400 font-mono">
                    <span className="text-cyan-400 font-semibold">{course.level}</span>
                    <span className="px-2 py-0.5 rounded bg-blue-950/80 border border-blue-700/40 text-blue-300 text-[10px] font-bold uppercase">
                      Recommended
                    </span>
                  </div>
                  <h3 className="font-bold text-white text-lg group-hover:text-cyan-300 transition-colors mb-2">
                    {course.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                    {course.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span>
                    {course.lessons.filter((l) => l.published !== false).length} Lessons · {course.durationWeeks}w
                  </span>
                  <span className="text-cyan-400 font-semibold group-hover:underline flex items-center">
                    View Course <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Live Classes Informational Banner */}
      <section className="py-12 bg-slate-950/60 border-t border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-xl">
            <span className="text-xs font-mono text-amber-400 uppercase tracking-wider font-semibold">
              Interactive Educator Sessions
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
              Learn Together in CoinEdu Live Classes
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-2">
              Discover how our live instructor sessions, real-time wallet safety walkthroughs, and Q&A workshops help you master blockchain concepts safely.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/live-classes')}
              className="btn-interactive flex items-center gap-2 px-5 py-3 rounded-xl font-semibold text-sm text-slate-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 shadow-md shadow-amber-500/20 cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>How Live Classes Work</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

// 2. Public Courses Page (/courses) - Section 1: Display ONLY Recommended & Published Courses
export const CoursesCataloguePage: React.FC<NavigationProps> = ({ navigate }) => {
  const { user, enrollInCourse } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses } = useContentStore(isAdmin);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterLevel, setFilterLevel] = useState<string>('All');
  const [filterCategory, setFilterCategory] = useState<string>('All');

  // Strict Section 1 Requirement: Only courses that are BOTH published AND recommended
  const recommendedCourses = filterRecommendedCourses(courses);

  const filtered = recommendedCourses.filter((c) => {
    const matchesLevel = filterLevel === 'All' || c.level === filterLevel;
    const matchesCategory =
      filterCategory === 'All' || (c.category || 'Blockchain Basics') === filterCategory;
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !q ||
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      (c.category && c.category.toLowerCase().includes(q)) ||
      (c.curriculumSummary && c.curriculumSummary.some((item) => item.toLowerCase().includes(q)));
    return matchesLevel && matchesCategory && matchesSearch;
  });

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">
            Featured Learning Tracks
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1">
            Recommended Courses
          </h1>
          <p className="text-sm sm:text-base text-slate-300 mt-2 max-w-2xl leading-relaxed">
            Curated step-by-step courses explaining blockchain fundamentals, digital wallet security, and responsible crypto practices.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => navigate('/admin/courses')}
            className="btn-interactive inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20 cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Manage Courses</span>
          </button>
        )}
      </div>

      {recommendedCourses.length > 0 && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-4 sm:p-5 mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search recommended courses by title or topic..."
                aria-label="Search recommended courses"
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              aria-label="Filter by category"
              className="bg-slate-900 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-400 cursor-pointer"
            >
              <option value="All">All Categories</option>
              {COURSE_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
            <div
              className="flex flex-wrap items-center gap-1.5"
              role="group"
              aria-label="Filter by difficulty level"
            >
              <span className="text-xs text-slate-400 mr-1.5">Difficulty:</span>
              {['All', 'Beginner', 'Intermediate', 'Advanced'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setFilterLevel(lvl)}
                  className={`btn-interactive px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                    filterLevel === lvl
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>

            {(searchQuery || filterLevel !== 'All' || filterCategory !== 'All') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setFilterLevel('All');
                  setFilterCategory('All');
                }}
                className="text-xs text-cyan-400 hover:underline cursor-pointer"
              >
                Reset filters
              </button>
            )}
          </div>
        </div>
      )}

      {filtered.length === 0 ? (
        <div
          data-testid="recommended-courses-empty"
          className="text-center py-20 bg-[#0b1329] rounded-2xl border border-slate-800 p-8 max-w-2xl mx-auto"
        >
          <div className="w-16 h-16 rounded-2xl bg-cyan-950/50 border border-cyan-800/40 flex items-center justify-center text-cyan-400 mx-auto mb-4">
            <BookOpen className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">
            {recommendedCourses.length === 0
              ? 'No recommended courses yet. Check back soon.'
              : 'No recommended courses match your current filters.'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-6">
            {recommendedCourses.length === 0
              ? 'Courses marked as recommended and published by administrators will appear here.'
              : 'Try clearing your search words or selecting "All" for category and difficulty.'}
          </p>
          {recommendedCourses.length === 0 && isAdmin && (
            <button
              onClick={() => navigate('/admin/courses')}
              className="btn-interactive inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Manage Courses in Admin</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((course) => {
            const publishedLessonCount = (course.lessons || []).filter(
              (l) => l.published !== false
            ).length;
            return (
              <div
                key={course.slug}
                onClick={() => navigate(`/courses/${course.slug}`)}
                className="card-interactive bg-[#0b1329] border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-6 shadow-sm flex flex-col justify-between cursor-pointer group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
                    <div className="flex items-center gap-1.5 font-mono">
                      <span className="text-cyan-400 font-bold">{course.level}</span>
                      <span>·</span>
                      <span>{course.category || 'Blockchain Basics'}</span>
                      <span>·</span>
                      <span>{course.durationWeeks}w</span>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-950/80 border border-blue-700/40 text-blue-300 text-[10px] font-bold uppercase">
                      Recommended
                    </span>
                  </div>

                  <h2 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors mb-2">
                    {course.title}
                  </h2>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4">
                    {course.description}
                  </p>

                  {course.curriculumSummary && course.curriculumSummary.length > 0 && (
                    <div className="space-y-1.5 mb-6">
                      <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                        What you will learn:
                      </span>
                      {course.curriculumSummary.slice(0, 3).map((item, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-400">
                          <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Lessons</span>
                    <span className="text-xs font-semibold text-slate-300">
                      {publishedLessonCount} {publishedLessonCount === 1 ? 'Lesson' : 'Lessons'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {user?.enrolledCourses?.includes(course.slug) ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate('/my-courses');
                        }}
                        className="btn-interactive flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-600/50 hover:bg-emerald-900/60 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Enrolled</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!user) {
                            navigate('/login');
                            return;
                          }
                          enrollInCourse(course.slug);
                        }}
                        className="btn-interactive flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 shadow-sm shadow-cyan-500/20 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Enroll</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/courses/${course.slug}`);
                      }}
                      className="btn-interactive flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700/80 cursor-pointer"
                    >
                      <span>Course Outline</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// 3. Course Details Page (/courses/:slug) - Section 2 Complete Course Structure
export const CourseDetailPage: React.FC<{ slug: string; navigate: (to: string) => void }> = ({
  slug,
  navigate,
}) => {
  const { user, enrollInCourse, unenrollFromCourse, completedLessons } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, quizzes, flashcards } = useContentStore(isAdmin);
  const course = courses.find((c) => c.slug === slug && (isAdmin || c.published));

  const [curriculumExpanded, setCurriculumExpanded] = useState(true);
  const [enrollSuccessMessage, setEnrollSuccessMessage] = useState<string | null>(null);

  if (!course) {
    return (
      <div className="py-20 text-center max-w-xl mx-auto px-4 animate-fade-in">
        <h2 className="text-2xl font-bold text-white mb-2">Course Not Found</h2>
        <p className="text-sm text-slate-400 mb-6">
          The requested course "{slug}" is not available or has not been published yet.
        </p>
        <button
          onClick={() => navigate('/courses')}
          className="btn-interactive px-4 py-2 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold cursor-pointer"
        >
          Back to Recommended Courses
        </button>
      </div>
    );
  }

  const visibleLessons = (course.lessons || []).filter((l) => isAdmin || l.published !== false);
  const courseQuizzes = Object.values(quizzes).filter(
    (q) => q.courseSlug === course.slug && (isAdmin || q.published !== false)
  );
  const courseFlashcards = Object.values(flashcards).filter(
    (f) => f.courseSlug === course.slug && (isAdmin || f.published !== false)
  );

  const isEnrolled = Boolean(user?.enrolledCourses?.includes(course.slug));
  const progress = calculateCourseProgress(course, completedLessons);

  const handleEnrollClick = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    enrollInCourse(course.slug);
    setEnrollSuccessMessage('You are now enrolled! Access this course anytime in My Courses.');
    setTimeout(() => setEnrollSuccessMessage(null), 5000);
  };

  const handleEnrollOrStart = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!isEnrolled) {
      enrollInCourse(course.slug);
    }
    if (visibleLessons.length > 0) {
      const nextLesson =
        visibleLessons.find((l) => !completedLessons.includes(l.lessonId)) || visibleLessons[0];
      navigate(`/learn/${nextLesson.lessonId}`);
    } else {
      navigate('/my-courses');
    }
  };

  const renderLessonTypeBadge = (type: 'written' | 'video' | 'pptx') => {
    if (type === 'video') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-700/40 text-cyan-300 text-[11px] font-mono">
          <Video className="w-3 h-3" /> Video Lesson
        </span>
      );
    }
    if (type === 'pptx') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-950/80 border border-blue-700/40 text-blue-300 text-[11px] font-mono">
          <Presentation className="w-3 h-3" /> PPTX Presentation
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-950/80 border border-amber-700/40 text-amber-300 text-[11px] font-mono">
        <FileText className="w-3 h-3" /> Written Lesson
      </span>
    );
  };

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <button
          onClick={() => navigate('/courses')}
          className="btn-interactive inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
        >
          <ChevronRight className="w-3.5 h-3.5 rotate-180" />
          <span>Back to Recommended Courses</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          {!isEnrolled ? (
            <button
              onClick={handleEnrollClick}
              className="btn-interactive inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 shadow-md shadow-cyan-500/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{user ? 'Enroll in Course' : 'Sign In to Enroll'}</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => navigate('/my-courses')}
                className="btn-interactive inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-600/50 hover:bg-emerald-900/60 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Open in My Courses</span>
              </button>
              <button
                onClick={() => {
                  unenrollFromCourse(course.slug);
                  setEnrollSuccessMessage('Course removed from your enrolled courses.');
                  setTimeout(() => setEnrollSuccessMessage(null), 3500);
                }}
                className="btn-interactive px-2.5 py-2 rounded-xl text-xs text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 border border-slate-800 cursor-pointer"
              >
                Unenroll
              </button>
            </div>
          )}

          {isAdmin && (
            <button
              onClick={() => navigate('/admin/lessons')}
              className="btn-interactive inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Manage Lessons</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
        <div className="lg:col-span-8 space-y-8">
          {/* Course Header & Full Description */}
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-mono mb-3">
              <span className="text-cyan-400 font-bold">{course.level}</span>
              <span>·</span>
              <span>{course.category || 'Blockchain Basics'}</span>
              <span>·</span>
              <span>{course.durationWeeks} Weeks Estimated</span>
              {course.recommended && (
                <>
                  <span>·</span>
                  <span className="text-blue-400 font-bold">Recommended Track</span>
                </>
              )}
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
              {course.title}
            </h1>

            <p className="text-base text-slate-300 leading-relaxed">{course.description}</p>
          </div>

          {/* Learning Objectives / Outcomes & Prerequisites */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5">
              <h2 className="text-sm font-bold text-white mb-3">Learning Objectives & Outcomes</h2>
              {course.curriculumSummary && course.curriculumSummary.length > 0 ? (
                <ul className="space-y-2 text-xs text-slate-300">
                  {course.curriculumSummary.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-slate-400">
                  Step-by-step foundational concepts covered across the course modules below.
                </p>
              )}
            </div>

            <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5">
              <h2 className="text-sm font-bold text-white mb-3">Prerequisites</h2>
              {course.prerequisites && course.prerequisites.length > 0 ? (
                <ul className="space-y-2 text-xs text-slate-300">
                  {course.prerequisites.map((req, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-slate-300 leading-relaxed">
                  {course.level === 'Beginner'
                    ? 'No prior cryptocurrency or finance experience required. Designed for beginners.'
                    : 'Basic familiarity with digital wallets and blockchain transactions is recommended.'}
                </p>
              )}
            </div>
          </div>

          {/* Course Lessons & Modules Outline */}
          <div className="bg-[#0b1329] border border-slate-800 rounded-2xl overflow-hidden">
            <button
              type="button"
              onClick={() => setCurriculumExpanded(!curriculumExpanded)}
              aria-expanded={curriculumExpanded}
              className="w-full p-5 flex items-center justify-between text-left hover:bg-slate-900/50 transition-colors cursor-pointer"
            >
              <div>
                <h2 className="text-lg font-bold text-white">Course Modules & Lessons</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {visibleLessons.length} {visibleLessons.length === 1 ? 'lesson' : 'lessons'} in this course
                </p>
              </div>
              <ChevronDown
                className={`w-5 h-5 text-slate-400 transition-transform duration-200 ${
                  curriculumExpanded ? 'rotate-180' : ''
                }`}
              />
            </button>

            {curriculumExpanded && (
              <div className="p-5 pt-0 border-t border-slate-800/80 animate-fade-in">
                {visibleLessons.length === 0 ? (
                  <div className="p-8 text-center">
                    <FileText className="w-10 h-10 text-slate-500 mx-auto mb-2" />
                    <h3 className="text-base font-bold text-white mb-1">
                      No lessons have been published yet.
                    </h3>
                    <p className="text-xs text-slate-400">
                      Lessons for this course will appear here once published by an administrator.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 pt-4">
                    {visibleLessons.map((lesson, idx) => {
                      const isDone = completedLessons.includes(lesson.lessonId);
                      return (
                        <div
                          key={lesson.lessonId}
                          className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
                        >
                          <div className="flex items-start gap-3">
                            <div
                              className={`w-8 h-8 rounded-lg flex items-center justify-center font-mono text-xs font-bold shrink-0 mt-0.5 ${
                                isDone
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-700/60'
                                  : 'bg-slate-800 text-cyan-400'
                              }`}
                            >
                              {isDone ? '✓' : idx + 1}
                            </div>
                            <div>
                              <div className="flex flex-wrap items-center gap-2 mb-1">
                                <span className="text-xs sm:text-sm font-bold text-white">
                                  {lesson.title}
                                </span>
                                {renderLessonTypeBadge(lesson.type)}
                              </div>
                              <p className="text-xs text-slate-400 line-clamp-2">{lesson.summary}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-3 self-end sm:self-auto shrink-0">
                            <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5" />
                              {lesson.durationMinutes}m
                            </span>
                            <button
                              onClick={() =>
                                user ? navigate(`/learn/${lesson.lessonId}`) : navigate('/login')
                              }
                              className="btn-interactive px-3.5 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
                            >
                              {!user ? 'Sign In' : isDone ? 'Review' : 'Open Lesson'}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Course Quizzes & Flashcard Sets Structure */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Award className="w-4 h-4 text-cyan-400" />
                  <span>Course Quizzes ({courseQuizzes.length})</span>
                </h3>
              </div>
              {courseQuizzes.length === 0 ? (
                <p className="text-xs text-slate-400">
                  No quizzes published for this course yet.
                </p>
              ) : (
                <ul className="space-y-2">
                  {courseQuizzes.map((quiz) => (
                    <li
                      key={quiz.quizId}
                      className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div>
                        <p className="text-xs font-bold text-white">{quiz.title}</p>
                        <p className="text-[11px] text-slate-400">
                          {quiz.questions.length} questions · Pass: {quiz.passingScore}%
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => (user ? navigate(`/quiz/${quiz.quizId}`) : navigate('/login'))}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold cursor-pointer"
                      >
                        {user ? 'Open' : 'Sign In'}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-amber-400" />
                  <span>Course Flashcards ({courseFlashcards.length})</span>
                </h3>
              </div>
              {courseFlashcards.length === 0 ? (
                <p className="text-xs text-slate-400">
                  No flashcard sets published for this course yet.
                </p>
              ) : (
                <ul className="space-y-2">
                  {courseFlashcards.map((deck) => (
                    <li
                      key={deck.setId}
                      className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div>
                        <p className="text-xs font-bold text-white">{deck.title}</p>
                        <p className="text-[11px] text-slate-400">{deck.cards.length} cards</p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          user ? navigate(`/flashcards/${deck.setId}`) : navigate('/login')
                        }
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold cursor-pointer"
                      >
                        {user ? 'Study' : 'Sign In'}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Info Card */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Course Access & Progress</h3>
              {isEnrolled && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700/60 font-semibold">
                  Enrolled ✓
                </span>
              )}
            </div>

            {user && (
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-slate-400">{progress.statusLabel}</span>
                  <span className="font-mono font-bold text-cyan-400">{progress.percentage}%</span>
                </div>
                <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${progress.percentage}%` }}
                    className="h-full bg-cyan-400 transition-[width] duration-500 ease-out"
                  />
                </div>
              </div>
            )}

            {enrollSuccessMessage && (
              <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-xs text-emerald-200 animate-fade-in space-y-2">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p>{enrollSuccessMessage}</p>
                </div>
                <button
                  type="button"
                  onClick={() => navigate('/my-courses')}
                  className="text-cyan-300 font-bold hover:underline text-[11px] flex items-center gap-1 cursor-pointer"
                >
                  <span>Go to My Courses</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            )}

            {!user ? (
              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => navigate('/login')}
                  className="btn-interactive w-full py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-xs cursor-pointer shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
                >
                  <span>Sign In to Start Course</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[11px] text-slate-400 text-center">
                  Create a free CoinEdu student account to enroll, access lessons, quizzes, and flashcards.
                </p>
              </div>
            ) : !isEnrolled ? (
              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={handleEnrollClick}
                  className="btn-interactive w-full py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-xs cursor-pointer shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Enroll in Course</span>
                </button>
                {visibleLessons.length > 0 && (
                  <button
                    type="button"
                    onClick={handleEnrollOrStart}
                    className="btn-interactive w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700/80 font-semibold text-xs cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <span>Enroll & Start Lesson 1</span>
                    <ChevronRight className="w-3.5 h-3.5 text-cyan-400" />
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={handleEnrollOrStart}
                  className="btn-interactive w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md shadow-cyan-500/20 flex items-center justify-center gap-2"
                >
                  <span>
                    {visibleLessons.length > 0
                      ? progress.completedLessonsCount > 0
                        ? 'Continue Course'
                        : 'Start Lesson 1'
                      : 'Open in My Courses'}
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

            <p className="text-[11px] text-slate-400 leading-relaxed pt-2 border-t border-slate-800/80">
              <strong>Educational Notice:</strong> This course is for educational purposes only and does not provide financial or investment advice.
            </p>
          </div>

          {course.instructor && (
            <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                Course Educator
              </h3>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-950 text-cyan-300 border border-cyan-800 flex items-center justify-center font-bold text-sm">
                  {course.instructor.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">{course.instructor}</h4>
                  {course.instructorTitle && (
                    <p className="text-xs text-slate-400">{course.instructorTitle}</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// 4. Public Live Classes Informational Page (/live-classes) - Section 3
export const LiveClassesPage: React.FC<NavigationProps> = ({ navigate }) => {
  const { user } = useAuth();

  const sessionHighlights = [
    {
      icon: Users,
      title: 'Live Educator-Led Sessions',
      description:
        'Learn directly from experienced blockchain educators who break down complex cryptocurrency mechanisms into clear, practical steps.',
    },
    {
      icon: BookOpen,
      title: 'Guided Crypto & Blockchain Walkthroughs',
      description:
        'Follow real-time demonstrations of block explorers, transaction verification, network fees, and decentralized protocol mechanics.',
    },
    {
      icon: MessageSquare,
      title: 'Live Q&A and Open Discussion',
      description:
        'Ask questions during class and get direct, hype-free answers tailored to beginners and intermediate learners.',
    },
    {
      icon: ShieldAlert,
      title: 'Practical Scam-Awareness & Wallet-Safety Demos',
      description:
        'Learn how to spot phishing links, fake token approvals, and recovery-phrase traps before they put your funds at risk.',
    },
    {
      icon: Sparkles,
      title: 'Course-Related Revision & Quiz Preparation',
      description:
        'Review key takeaways from your enrolled courses, work through flashcard concepts, and prepare for course practice quizzes.',
    },
  ];

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="max-w-3xl mb-12">
        <span className="text-xs font-mono text-amber-400 uppercase tracking-wider font-semibold">
          Interactive Group Learning
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
          What Happens in CoinEdu Live Classes
        </h1>
        <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
          CoinEdu Live Classes bring students and educators together in real time. Instead of pre-recorded hype, every live session focuses on practical understanding, wallet security, and interactive Q&A connected to your courses.
        </p>
      </div>

      {/* 5 Core Pillars of CoinEdu Live Classes */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {sessionHighlights.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 flex flex-col justify-between"
            >
              <div>
                <div className="w-11 h-11 rounded-xl bg-amber-950/60 border border-amber-500/30 text-amber-400 flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h2 className="text-lg font-bold text-white mb-2">{item.title}</h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* How Students Access Live Classes */}
      <div className="bg-gradient-to-br from-[#0b1329] to-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="max-w-xl space-y-2">
          <h3 className="text-xl font-bold text-white">
            Accessing Your Student Live Class Schedule
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Scheduled live sessions and join links are available exclusively inside the student portal under <strong>My Live Classes</strong>. Sign in to view upcoming sessions for your courses.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {user ? (
            <button
              onClick={() => navigate('/my-live-classes')}
              className="btn-interactive inline-flex items-center gap-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 cursor-pointer shadow-md shadow-cyan-500/20"
            >
              <Calendar className="w-4 h-4" />
              <span>Open My Live Classes</span>
            </button>
          ) : (
            <>
              <button
                onClick={() => navigate('/login')}
                className="btn-interactive inline-flex items-center gap-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 cursor-pointer shadow-md shadow-cyan-500/20"
              >
                <span>Sign In to View Schedule</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigate('/courses')}
                className="btn-interactive inline-flex items-center gap-2 px-4 py-3 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
              >
                <span>Explore Recommended Courses</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// 5. Protected Student Dictionary Page (/dictionary)
export const GlossaryPage: React.FC<NavigationProps> = ({ navigate }) => {
  return <GlossarySection navigate={navigate} />;
};

// 7. FAQ & Beginner Help Page (/faq)
interface FaqItem {
  id: string;
  category: 'Getting Started' | 'Account & Progress' | 'Safety & Disclaimer';
  question: string;
  answer: string;
}

const PLATFORM_FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'Getting Started',
    question: 'Who is CoinEdu built for, and do I need prior finance knowledge?',
    answer:
      'CoinEdu is designed for everyday Indian learners who want to understand cryptocurrency and blockchain in simple, clear English. You do not need any background in finance, coding, or economics to start.',
  },
  {
    id: 'faq-2',
    category: 'Safety & Disclaimer',
    question: 'Does CoinEdu give investment tips or tell me which coin to buy?',
    answer:
      'No. CoinEdu is strictly an educational website. We never recommend buying or selling any cryptocurrency, never promise profits, and never accept paid promotions. Cryptocurrency prices are highly volatile (they go up and down rapidly), and you should never invest money you cannot afford to lose.',
  },
  {
    id: 'faq-3',
    category: 'Account & Progress',
    question: 'How is my learning progress, quiz score, and bookmark list saved?',
    answer:
      'When you sign in with your Google Account or email and password, your enrolled courses, completed lessons, saved bookmarks, and quiz results are linked to your private student profile and cached locally in your browser so you can continue learning smoothly.',
  },
  {
    id: 'faq-4',
    category: 'Account & Progress',
    question: 'Can I reset my password or delete my student account?',
    answer:
      'Yes. You can request a password reset email from the Sign In page or inside Account Settings (/settings). You can also permanently delete your student account and clear your saved learning history at any time from Account Settings.',
  },
  {
    id: 'faq-5',
    category: 'Getting Started',
    question: 'Why does the course catalogue or flashcard list show as empty right now?',
    answer:
      'CoinEdu does not display fake sample courses or fabricated student counts. Courses, lessons, quizzes, flashcards, and dictionary words appear automatically as soon as the platform administrator publishes them.',
  },
  {
    id: 'faq-6',
    category: 'Safety & Disclaimer',
    question: 'What is the most important safety rule in cryptocurrency?',
    answer:
      'Never share your wallet recovery phrase (12 or 24 secret words) or private keys with anyone. No genuine support team, educator, or website will ever ask for your recovery phrase or ask you to send coins to "double" your money.',
  },
];

export const FaqHelpPage: React.FC<NavigationProps> = ({ navigate }) => {
  const [openId, setOpenId] = useState<string | null>('faq-1');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const filteredFaqs = PLATFORM_FAQ_ITEMS.filter(
    (item) => selectedCategory === 'All' || item.category === selectedCategory
  );

  return (
    <div className="py-14 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">
        Help & Support Center
      </span>
      <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1">
        Frequently Asked Questions (FAQ)
      </h1>
      <p className="text-sm sm:text-base text-slate-300 mt-2 leading-relaxed">
        Clear answers about how CoinEdu works, how your account and progress are handled, and how to stay safe while learning.
      </p>

      {/* Category Filter Buttons */}
      <div className="flex flex-wrap gap-2 mt-6 mb-8">
        {['All', 'Getting Started', 'Account & Progress', 'Safety & Disclaimer'].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`btn-interactive px-3.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
              selectedCategory === cat
                ? 'bg-cyan-500 text-slate-950'
                : 'bg-[#0b1329] text-slate-300 border border-slate-800 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Expandable Accordion List */}
      <div className="space-y-3">
        {filteredFaqs.map((item) => {
          const isOpen = openId === item.id;
          return (
            <div
              key={item.id}
              className="bg-[#0b1329] border border-slate-800 rounded-2xl overflow-hidden transition-colors"
            >
              <button
                type="button"
                onClick={() => setOpenId(isOpen ? null : item.id)}
                aria-expanded={isOpen}
                className="w-full p-5 text-left flex items-center justify-between gap-4 hover:bg-slate-900/60 transition-colors cursor-pointer"
              >
                <div>
                  <span className="text-[11px] font-mono text-cyan-400 block mb-1">
                    {item.category}
                  </span>
                  <h2 className="text-sm sm:text-base font-bold text-white">{item.question}</h2>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180 text-cyan-400' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-2 border-t border-slate-800/70 text-xs sm:text-sm text-slate-300 leading-relaxed animate-fade-in">
                  {item.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Helpful Links Footer Card */}
      <div className="mt-10 p-6 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-white">Still need help or have feedback?</h3>
          <p className="text-xs text-slate-400 mt-1">
            Visit our Contact page or review our Privacy Policy and Educational Disclaimer.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => navigate('/contact')}
            className="btn-interactive px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold cursor-pointer"
          >
            Contact Page
          </button>
          <button
            onClick={() => navigate('/disclaimer')}
            className="btn-interactive px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
          >
            Educational Disclaimer
          </button>
        </div>
      </div>
    </div>
  );
};

// 8. About Page
export const AboutPage: React.FC<NavigationProps> = ({ navigate }) => {
  return (
    <div className="py-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">
        Our Purpose
      </span>
      <h1 className="text-3xl sm:text-5xl font-extrabold text-white mt-2 tracking-tight">
        About CoinEdu
      </h1>
      <p className="mt-3 text-lg font-bold text-amber-300">
        “Learn Smart. Invest Wise. Grow Together.”
      </p>

      {/* Clear definitions of key concepts for beginners */}
      <div className="mt-6 p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-3">
        <div className="flex items-start gap-2">
          <HelpCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-cyan-300">Decentralised: </strong>
            <span>A system that is not controlled by one single authority or company. Instead, independent computers on a network verify records together.</span>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <HelpCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-cyan-300">Consensus: </strong>
            <span>How computers on a blockchain agree that transactions are valid without needing a central middleman.</span>
          </div>
        </div>
      </div>

      <div className="mt-8 space-y-6 text-slate-300 leading-relaxed text-sm sm:text-base">
        <p>
          CoinEdu is an educational platform built to explain cryptocurrency, blockchain technology, and digital security in simple, everyday Indian English.
        </p>
        <p>
          The internet has many confusing technical terms and risky schemes that promise quick money. CoinEdu focuses on clear, honest learning: understanding how digital systems work, recognizing common online scams, and knowing the risks before making any decisions.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-8">
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
            <h3 className="font-bold text-white mb-1">Learn Smart</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Understand how blockchain and digital wallets work step by step in plain language.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
            <h3 className="font-bold text-white mb-1">Invest Wise</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Learn about price volatility (how much prices go up and down) and how much loss you can handle before taking any financial risk.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
            <h3 className="font-bold text-white mb-1">Grow Together</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Study through structured courses, flashcards, and quizzes with zero paid promotions or hype.
            </p>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-white pt-4">Our Educational Standards</h2>
        <ul className="list-disc list-inside space-y-2 text-slate-300 text-xs sm:text-sm">
          <li><strong>No Financial Advice:</strong> Everything on CoinEdu is for educational study only, never investment or trading advice.</li>
          <li><strong>No Paid Promotions:</strong> We do not promote specific coins, tokens, or exchanges.</li>
          <li><strong>Transparent Practice Tools:</strong> Our calculators and scam checklists run openly in your browser to help you understand math and security concepts.</li>
        </ul>

        <div className="pt-4 flex flex-wrap gap-3">
          <button
            onClick={() => navigate('/courses')}
            className="btn-interactive px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs cursor-pointer"
          >
            Browse Courses
          </button>
          <button
            onClick={() => navigate('/faq')}
            className="btn-interactive px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs cursor-pointer"
          >
            Read FAQ & Help
          </button>
        </div>
      </div>
    </div>
  );
};

// 9. Contact Page (Honest configuration placeholders — no invented email, address, or SLA claims)
export const ContactPage: React.FC<NavigationProps> = ({ navigate }) => {
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', topic: 'Course Question', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setTimeout(() => {
      try {
        const saved = JSON.parse(localStorage.getItem('coinedu_contact_submissions') || '[]');
        saved.unshift({
          ...form,
          timestamp: new Date().toISOString(),
        });
        localStorage.setItem('coinedu_contact_submissions', JSON.stringify(saved.slice(0, 20)));
      } catch {}
      setSubmitting(false);
      setSubmitted(true);
    }, 350);
  };

  return (
    <div className="py-16 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">
        Questions & Feedback
      </span>
      <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1">
        Contact & Support
      </h1>
      <p className="text-sm text-slate-300 mt-2 leading-relaxed">
        Have a question about a lesson, found a technical issue, or want to suggest a topic? Use the feedback form below or check our{' '}
        <button onClick={() => navigate('/faq')} className="text-cyan-400 hover:underline cursor-pointer font-semibold">
          Frequently Asked Questions
        </button>.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 mb-8">
        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">Official Support Email</span>
          <span className="text-xs font-mono text-slate-300">
            [To be configured by platform administrator]
          </span>
        </div>
        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">Important Safety Reminder</span>
          <span className="text-xs text-amber-300">
            Never include wallet recovery phrases, passwords, or private keys in any message.
          </span>
        </div>
      </div>

      {submitted ? (
        <div className="p-8 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 text-center animate-fade-in">
          <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-3" />
          <h2 className="text-lg font-bold text-white">Feedback Recorded</h2>
          <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
            Thank you, {form.name}. Your message regarding "{form.topic}" has been recorded for administrator review.
          </p>
          <button
            onClick={() => {
              setSubmitted(false);
              setForm({ name: '', email: '', topic: 'Course Question', message: '' });
            }}
            className="btn-interactive mt-5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 cursor-pointer"
          >
            Send Another Message
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="contact-name" className="block text-xs font-semibold text-slate-300 mb-1">
                Your Name *
              </label>
              <input
                id="contact-name"
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                placeholder="Enter your name"
              />
            </div>
            <div>
              <label htmlFor="contact-email" className="block text-xs font-semibold text-slate-300 mb-1">
                Email Address *
              </label>
              <input
                id="contact-email"
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                placeholder="you@example.com"
              />
            </div>
          </div>

          <div>
            <label htmlFor="contact-topic" className="block text-xs font-semibold text-slate-300 mb-1">
              Topic
            </label>
            <select
              id="contact-topic"
              value={form.topic}
              onChange={(e) => setForm({ ...form, topic: e.target.value })}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
            >
              <option value="Course Question">Course or Lesson Question</option>
              <option value="Account Help">Account or Sign-In Help</option>
              <option value="Website Issue">Report a Technical Issue</option>
              <option value="Topic Suggestion">Suggest a New Educational Topic</option>
            </select>
          </div>

          <div>
            <label htmlFor="contact-message" className="block text-xs font-semibold text-slate-300 mb-1">
              Message *
            </label>
            <textarea
              id="contact-message"
              required
              rows={4}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              placeholder="Write your question or feedback clearly..."
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="btn-interactive flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-60 text-slate-950 font-bold text-sm cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>{submitting ? 'Sending...' : 'Submit Feedback'}</span>
          </button>
        </form>
      )}
    </div>
  );
};

// 10. Legal Pages (Privacy, Terms, Disclaimer)
export const PrivacyPage: React.FC = () => {
  const [allowLocalCache, setAllowLocalCache] = useState<boolean>(() => {
    try {
      return localStorage.getItem('coinedu_privacy_cache_optout') !== 'true';
    } catch {
      return true;
    }
  });
  const [savedNotice, setSavedNotice] = useState(false);

  const handleToggleCache = (checked: boolean) => {
    setAllowLocalCache(checked);
    try {
      if (!checked) {
        localStorage.setItem('coinedu_privacy_cache_optout', 'true');
      } else {
        localStorage.removeItem('coinedu_privacy_cache_optout');
      }
    } catch {}
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <div className="py-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 text-slate-300 text-sm leading-relaxed animate-fade-in">
      <h1 className="text-3xl font-extrabold text-white">Privacy Policy & Data Handling</h1>
      <p>
        At CoinEdu, we respect your privacy. We do not sell your personal information, run third-party advertising trackers, or collect unnecessary personal data.
      </p>

      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-3">
        <h2 className="text-lg font-bold text-white">1. Personal Information We Collect</h2>
        <p className="text-xs sm:text-sm text-slate-300">
          When you sign in using Google or create an account with your email address and password through Firebase Authentication, we store:
        </p>
        <ul className="list-disc list-inside text-xs sm:text-sm space-y-1 text-slate-300">
          <li><strong>Account Identifier & Email:</strong> Used strictly to sign you in and secure your account.</li>
          <li><strong>Display Name:</strong> Shown on your learning dashboard and profile.</li>
          <li><strong>Learning Progress:</strong> Enrolled courses, completed lessons, saved bookmarks, and quiz scores so you can resume where you left off.</li>
        </ul>
      </div>

      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-3">
        <h2 className="text-lg font-bold text-white">2. How Your Data Is Protected</h2>
        <p className="text-xs sm:text-sm text-slate-300">
          Each student's profile and quiz history are protected by strict database security rules so that other students cannot view or modify your private learning records. You can permanently delete your account and clear your saved progress at any time in <strong>Account Settings (/settings)</strong>.
        </p>
      </div>

      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-4">
        <h2 className="text-lg font-bold text-white">3. Cookie & Browser Storage Preferences</h2>
        <p className="text-xs sm:text-sm text-slate-300">
          CoinEdu does not use third-party advertising cookies. We use essential browser storage (<code>localStorage</code> and Firebase authentication tokens) to keep you signed in and cache your learning progress and calculator inputs on your device.
        </p>

        <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div>
            <span className="text-xs font-bold text-white block">Essential Authentication & Security Storage</span>
            <span className="text-[11px] text-slate-400">Required for login sessions and protecting account access.</span>
          </div>
          <span className="text-xs font-mono text-cyan-400">Always Active</span>
        </div>

        <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div>
            <label htmlFor="toggle-local-cache" className="text-xs font-bold text-white block cursor-pointer">
              Save Practice Calculator & Flashcard Preferences Locally
            </label>
            <span className="text-[11px] text-slate-400">
              Remembers your flashcard self-assessments and bookmarks on this device.
            </span>
          </div>
          <input
            id="toggle-local-cache"
            type="checkbox"
            checked={allowLocalCache}
            onChange={(e) => handleToggleCache(e.target.checked)}
            className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
          />
        </div>

        {savedNotice && (
          <p className="text-xs text-emerald-400 font-semibold animate-fade-in">
            Storage preference updated ✓
          </p>
        )}
      </div>
    </div>
  );
};

export const TermsPage: React.FC = () => (
  <div className="py-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 text-slate-300 text-sm leading-relaxed animate-fade-in">
    <h1 className="text-3xl font-extrabold text-white">Terms of Service</h1>
    <p>
      By accessing and using CoinEdu, you agree to these Terms of Service. Please read them carefully.
    </p>

    <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-4">
      <h2 className="text-lg font-bold text-white">1. Educational Use Only</h2>
      <p className="text-xs sm:text-sm">
        All courses, written lessons, videos, quizzes, flashcards, calculators, and dictionary definitions on CoinEdu are provided strictly for personal educational purposes. Nothing on this platform constitutes financial, investment, legal, or tax advice.
      </p>

      <h2 className="text-lg font-bold text-white pt-2">2. User Accounts & Security</h2>
      <p className="text-xs sm:text-sm">
        You are responsible for keeping your account login credentials secure. All newly created accounts are assigned the student role. Attempting to bypass platform security rules or access another user's private records is strictly prohibited.
      </p>

      <h2 className="text-lg font-bold text-white pt-2">3. No Guarantee of Financial Outcomes</h2>
      <p className="text-xs sm:text-sm">
        Cryptocurrency and digital assets involve high risk and extreme price volatility. CoinEdu makes no representations or guarantees regarding the profitability or safety of any cryptocurrency, token, protocol, or financial strategy.
      </p>
    </div>
  </div>
);

export const DisclaimerPage: React.FC = () => (
  <div className="py-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 text-slate-300 text-sm leading-relaxed animate-fade-in">
    <h1 className="text-3xl font-extrabold text-white">Educational & Financial Risk Disclaimer</h1>

    <div className="p-5 rounded-2xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-sm flex items-start gap-3">
      <ShieldAlert className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
      <div>
        <strong className="block text-amber-300 mb-1">IMPORTANT EDUCATIONAL NOTICE</strong>
        Nothing on CoinEdu is financial, investment, trading, legal, or tax advice. We never recommend buying or selling any cryptocurrency and never promise investment returns.
      </div>
    </div>

    <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-4 text-xs sm:text-sm">
      <h2 className="text-lg font-bold text-white">1. Understanding Cryptocurrency Risks</h2>
      <p>
        Cryptocurrencies are highly volatile digital assets. Prices can rise or fall sharply at any time, and you can lose some or all of the money you put in. Past price performance in any calculator or historical example never guarantees future results.
      </p>

      <h2 className="text-lg font-bold text-white pt-2">2. Self-Custody & Scam Awareness</h2>
      <p>
        Transactions on a public blockchain cannot be reversed. If you lose your private keys or recovery phrase, or if you send funds to a scammer, no bank or website can recover your funds. Always verify information independently before making any financial decision.
      </p>
    </div>
  </div>
);
