import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { CoinEduLogo } from '../../components/CoinEduLogo';
import { LogIn, UserPlus, KeyRound, CheckCircle2, AlertCircle } from 'lucide-react';

interface AuthPageProps {
  navigate: (to: string) => void;
}

// Google "G" icon
const GoogleIcon: React.FC = () => (
  <svg className="w-4 h-4" viewBox="0 0 24 24">
    <path
      fill="#4285F4"
      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
    />
    <path
      fill="#34A853"
      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
    />
    <path
      fill="#FBBC05"
      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
    />
    <path
      fill="#EA4335"
      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
    />
  </svg>
);

// 1. Sign In Page (/login) - Completely free of demo credentials
export const LoginPage: React.FC<AuthPageProps> = ({ navigate }) => {
  const { login, loginWithGoogle } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    const result = await login(email, password);
    setIsSubmitting(false);

    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.error || 'Sign in failed. Please check your credentials.');
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setIsSubmitting(true);
    const result = await loginWithGoogle();
    setIsSubmitting(false);

    if (result.success) {
      navigate('/dashboard');
    } else if (result.error) {
      setError(result.error);
    }
  };

  return (
    <div className="py-16 max-w-md mx-auto px-4">
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="text-center mb-6">
          <CoinEduLogo size="md" variant="full" className="justify-center mb-3" />
          <h1 className="text-xl sm:text-2xl font-bold text-white">Sign In to CoinEdu</h1>
          <p className="text-xs text-slate-400 mt-1">
            Access your courses, quizzes, and My Learning space.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-500/50 flex items-center gap-2 text-xs text-rose-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Google Sign-In Button */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={isSubmitting}
          className="w-full mb-4 py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-900 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2.5 shadow-sm disabled:opacity-60 cursor-pointer"
        >
          <GoogleIcon />
          <span>Continue with Google</span>
        </button>

        <div className="flex items-center gap-3 my-4">
          <div className="h-px bg-slate-800 flex-1" />
          <span className="text-[11px] text-slate-500 uppercase tracking-wider font-mono">or email</span>
          <div className="h-px bg-slate-800 flex-1" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              placeholder="you@domain.com"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-xs font-semibold text-slate-300">Password</label>
              <button
                type="button"
                onClick={() => navigate('/forgot-password')}
                className="text-[11px] text-cyan-400 hover:underline cursor-pointer"
              >
                Forgot password?
              </button>
            </div>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-all disabled:opacity-50 cursor-pointer shadow-md shadow-cyan-500/20"
          >
            <LogIn className="w-4 h-4" />
            <span>{isSubmitting ? 'Signing in...' : 'Sign In with Email'}</span>
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-800 text-center text-xs text-slate-400">
          <span>Do not have an account yet? </span>
          <button
            onClick={() => navigate('/signup')}
            className="text-cyan-400 font-bold hover:underline cursor-pointer"
          >
            Create Free Account
          </button>
        </div>
      </div>
    </div>
  );
};

// 2. Sign Up Page (/signup)
export const SignupPage: React.FC<AuthPageProps> = ({ navigate }) => {
  const { register, loginWithGoogle } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    const result = await register(email, password, name);
    setIsSubmitting(false);

    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.error || 'Account creation failed. Please try again.');
    }
  };

  const handleGoogleSignUp = async () => {
    setError(null);
    setIsSubmitting(true);
    const result = await loginWithGoogle();
    setIsSubmitting(false);

    if (result.success) {
      navigate('/dashboard');
    } else if (result.error) {
      setError(result.error);
    }
  };

  return (
    <div className="py-16 max-w-md mx-auto px-4">
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="text-center mb-6">
          <CoinEduLogo size="md" variant="full" className="justify-center mb-3" />
          <h1 className="text-xl sm:text-2xl font-bold text-white">Create Your Free Account</h1>
          <p className="text-xs text-slate-400 mt-1">
            100% free learning. No fees or credit card required.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-500/50 flex items-center gap-2 text-xs text-rose-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Google Sign-In Button */}
        <button
          type="button"
          onClick={handleGoogleSignUp}
          disabled={isSubmitting}
          className="w-full mb-4 py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-900 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2.5 shadow-sm disabled:opacity-60 cursor-pointer"
        >
          <GoogleIcon />
          <span>Continue with Google</span>
        </button>

        <div className="flex items-center gap-3 my-4">
          <div className="h-px bg-slate-800 flex-1" />
          <span className="text-[11px] text-slate-500 uppercase tracking-wider font-mono">or register with email</span>
          <div className="h-px bg-slate-800 flex-1" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              placeholder="e.g. Rahul Sharma"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              placeholder="you@domain.com"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              placeholder="At least 6 characters"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-bold text-sm transition-all disabled:opacity-50 cursor-pointer shadow-md shadow-cyan-500/20"
          >
            <UserPlus className="w-4 h-4" />
            <span>{isSubmitting ? 'Creating Account...' : 'Create Free Account'}</span>
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-800 text-center text-xs text-slate-400">
          <span>Already registered? </span>
          <button
            onClick={() => navigate('/login')}
            className="text-cyan-400 font-bold hover:underline cursor-pointer"
          >
            Sign In
          </button>
        </div>
      </div>
    </div>
  );
};

// 3. Forgot Password Page (/forgot-password) - Section 7 Branded Password Reset Flow
export const ForgotPasswordPage: React.FC<AuthPageProps> = ({ navigate }) => {
  const { sendPasswordReset } = useAuth();
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [resentSuccess, setResentSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateEmailFormat = (value: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResentSuccess(false);

    if (!validateEmailFormat(email)) {
      setError('Please enter a valid email address (for example, name@example.com).');
      return;
    }

    setIsSubmitting(true);
    const res = await sendPasswordReset(email);
    setIsSubmitting(false);

    if (res.success) {
      setSent(true);
    } else {
      setError(res.error || 'Could not send reset link right now. Please try again.');
    }
  };

  const handleResend = async () => {
    setError(null);
    setResentSuccess(false);
    setIsSubmitting(true);
    const res = await sendPasswordReset(email);
    setIsSubmitting(false);
    if (res.success) {
      setResentSuccess(true);
    } else {
      setError(res.error || 'Please wait a moment before requesting another link.');
    }
  };

  return (
    <div className="py-16 max-w-md mx-auto px-4 animate-fade-in">
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="text-center mb-6">
          <CoinEduLogo size="md" variant="full" className="justify-center mb-4" />
          <h1 className="text-xl sm:text-2xl font-bold text-white">Reset your password</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
            Enter the email address for your CoinEdu account and we'll send you a password reset link.
          </p>
        </div>

        {error && (
          <div
            role="alert"
            className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-500/50 flex items-center gap-2 text-xs text-rose-300"
          >
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {sent ? (
          <div className="p-5 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-center space-y-4">
            <CheckCircle2 className="w-9 h-9 text-emerald-400 mx-auto" />
            <div className="space-y-2">
              <p className="text-sm font-bold text-white">Check your email</p>
              <p className="text-xs text-slate-300 leading-relaxed">
                If an account exists for this email address, a password reset link has been sent. Please check your inbox and spam folder.
              </p>
            </div>

            {resentSuccess && (
              <p className="text-xs font-semibold text-emerald-300">
                A fresh reset link request has been sent.
              </p>
            )}

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={handleResend}
                disabled={isSubmitting}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition-colors disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? 'Sending...' : 'Resend reset link'}
              </button>
              <button
                type="button"
                onClick={() => navigate('/login')}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
              >
                Back to Sign In
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <div>
              <label
                htmlFor="reset-email-input"
                className="block text-xs font-semibold text-slate-300 mb-1"
              >
                Email Address
              </label>
              <input
                id="reset-email-input"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                placeholder="you@domain.com"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer disabled:opacity-50 shadow-md shadow-cyan-500/20"
            >
              {isSubmitting ? 'Sending reset link...' : 'Send reset link'}
            </button>

            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => navigate('/login')}
                className="text-xs font-semibold text-slate-400 hover:text-white cursor-pointer"
              >
                Back to Sign In
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

// 4. Branded Password Reset Completion Page (/reset-password or ?mode=resetPassword&oobCode=...)
export const ResetPasswordCompletePage: React.FC<AuthPageProps> = ({ navigate }) => {
  const { verifyPasswordResetActionCode, completePasswordResetWithCode } = useAuth();
  const [oobCode] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    const params = new URLSearchParams(window.location.search);
    return params.get('oobCode') || '';
  });

  const [verifying, setVerifying] = useState<boolean>(Boolean(oobCode));
  const [accountEmail, setAccountEmail] = useState<string | null>(null);
  const [codeError, setCodeError] = useState<string | null>(
    oobCode ? null : 'This password reset link is missing a valid security code. Please request a new password reset link.'
  );
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completed, setCompleted] = useState(false);

  React.useEffect(() => {
    if (!oobCode) {
      setVerifying(false);
      return;
    }
    let active = true;
    setVerifying(true);
    verifyPasswordResetActionCode(oobCode).then((res) => {
      if (!active) return;
      setVerifying(false);
      if (res.valid) {
        setAccountEmail(res.email || null);
        setCodeError(null);
      } else {
        setCodeError(res.error || 'This password reset link is invalid or has expired.');
      }
    });
    return () => {
      active = false;
    };
  }, [oobCode, verifyPasswordResetActionCode]);

  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (newPassword.length < 6) {
      setSubmitError('New password must be at least 6 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setSubmitError('Passwords do not match. Please re-enter carefully.');
      return;
    }

    setIsSubmitting(true);
    const res = await completePasswordResetWithCode(oobCode, newPassword);
    setIsSubmitting(false);

    if (res.success) {
      setCompleted(true);
      if (typeof window !== 'undefined' && window.location.search) {
        window.history.replaceState(null, '', '/reset-password');
      }
    } else {
      setSubmitError(res.error || 'Failed to update password. Please request a new reset link.');
    }
  };

  return (
    <div className="py-16 max-w-md mx-auto px-4 animate-fade-in">
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="text-center mb-6">
          <CoinEduLogo size="md" variant="full" className="justify-center mb-4" />
          <h1 className="text-xl sm:text-2xl font-bold text-white">Choose a new password</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            {accountEmail
              ? `Setting a new password for ${accountEmail}`
              : 'Complete your CoinEdu account password reset below.'}
          </p>
        </div>

        {verifying ? (
          <div className="py-8 text-center">
            <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs text-slate-300 font-medium">Verifying your security reset code...</p>
          </div>
        ) : completed ? (
          <div className="p-5 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-center space-y-4">
            <CheckCircle2 className="w-9 h-9 text-emerald-400 mx-auto" />
            <div className="space-y-1">
              <p className="text-sm font-bold text-white">Password updated</p>
              <p className="text-xs text-slate-300">
                Your CoinEdu password has been changed. You can now sign in with your new password.
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('/login')}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs cursor-pointer"
            >
              Sign In to CoinEdu
            </button>
          </div>
        ) : codeError ? (
          <div className="p-5 rounded-xl bg-rose-950/30 border border-rose-500/40 text-center space-y-4">
            <KeyRound className="w-8 h-8 text-rose-400 mx-auto" />
            <div className="space-y-1">
              <p className="text-sm font-bold text-white">Reset Link Unavailable</p>
              <p className="text-xs text-slate-300 leading-relaxed">{codeError}</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 justify-center pt-1">
              <button
                type="button"
                onClick={() => navigate('/forgot-password')}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs cursor-pointer"
              >
                Request New Reset Link
              </button>
              <button
                type="button"
                onClick={() => navigate('/login')}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs cursor-pointer"
              >
                Back to Sign In
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleResetSubmit} className="space-y-4">
            {submitError && (
              <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/50 flex items-center gap-2 text-xs text-rose-300">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{submitError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                New Password
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Confirm New Password
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter your new password"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'Updating password...' : 'Save New Password'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
