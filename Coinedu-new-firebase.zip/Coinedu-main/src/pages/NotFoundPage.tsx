import React from 'react';
import { HelpCircle, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NotFoundProps {
  path: string;
  navigate: (to: string) => void;
}

export const NotFoundPage: React.FC<NotFoundProps> = ({ path, navigate }) => {
  const { user } = useAuth();
  const homeTarget = user ? '/dashboard' : '/';

  return (
    <div className="py-24 text-center max-w-md mx-auto px-4">
      <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 mx-auto mb-4">
        <HelpCircle className="w-8 h-8 text-cyan-400" />
      </div>
      <span className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-bold">
        Error 404
      </span>
      <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1 mb-2">
        Page Not Found
      </h1>
      <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed">
        The requested path <code className="text-cyan-300 font-mono bg-slate-900 px-1.5 py-0.5 rounded">{path}</code> does not exist on CoinEdu.
      </p>
      <button
        onClick={() => navigate('/')}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors shadow-md shadow-cyan-500/20"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Homepage</span>
      </button>
    </div>
  );
};
