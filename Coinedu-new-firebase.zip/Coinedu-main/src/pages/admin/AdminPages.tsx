import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  useContentStore,
  COURSE_CATEGORIES,
  saveCourse,
  deleteCourse,
  toggleCoursePublish,
  toggleCourseRecommended,
  saveLesson,
  deleteLesson,
  toggleLessonPublish,
  reorderLesson,
  saveQuiz,
  deleteQuiz,
  toggleQuizPublish,
  saveFlashcardSet,
  deleteFlashcardSet,
  toggleFlashcardPublish,
  saveLiveClass,
  deleteLiveClass,
  toggleLiveClassPublish,
  saveGlossaryItem,
  deleteGlossaryItem,
  toggleGlossaryPublish,
  saveNotification,
  deleteNotification,
  toggleNotificationPublish,
  toggleNotificationArchive,
  clearAdminActivityLogs,
  CourseDetail,
  LessonItem,
  PptxSlideData,
  QuizData,
  FlashcardSet,
  LiveClassItem,
  QuizQuestion,
  Flashcard,
  NotificationItem,
} from '../../data/learningPlatform';
import { GlossaryItem } from '../../data/glossary';
import { PptxViewer, parsePptxFile } from '../../components/PptxViewer';
import { VideoLessonPlayer } from '../../components/VideoLessonPlayer';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../firebase/config';
import {
  ShieldAlert,
  BookOpen,
  FileText,
  HelpCircle,
  Layers,
  Calendar,
  Users,
  LayoutDashboard,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  X,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Activity,
  Star,
  Bell,
  Upload,
  Presentation,
  Video,
  Archive,
} from 'lucide-react';

interface AdminPageProps {
  navigate: (to: string) => void;
  subroute?:
    | 'overview'
    | 'courses'
    | 'lessons'
    | 'quizzes'
    | 'flashcards'
    | 'live-classes'
    | 'glossary'
    | 'notifications'
    | 'students';
}

export const AdminPage: React.FC<AdminPageProps> = ({ navigate, subroute = 'overview' }) => {
  const { user, verifyAdmin } = useAuth();
  const [isVerifying, setIsVerifying] = useState(true);
  const [isAdminAuthorized, setIsAdminAuthorized] = useState(false);

  // Content Store Hook (Admin Mode = true, includes unpublished drafts)
  const {
    courses,
    quizzes,
    flashcards,
    liveClasses,
    glossaryTerms,
    notifications,
    activityLogs,
  } = useContentStore(true);

  // Modal States
  const [activeModal, setActiveModal] = useState<
    'course' | 'lesson' | 'quiz' | 'flashcard' | 'live-class' | 'glossary' | 'notification' | null
  >(null);
  const [lessonFilterType, setLessonFilterType] = useState<'all' | 'written' | 'pptx' | 'video'>('all');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [confirmAction, setConfirmAction] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // 1. Course Form State
  const [courseForm, setCourseForm] = useState<Partial<CourseDetail>>({
    slug: '',
    title: '',
    category: 'Foundations',
    level: 'Beginner',
    durationWeeks: 4,
    instructor: '',
    instructorTitle: '',
    description: '',
    prerequisites: [],
    curriculumSummary: [],
    published: false,
    recommended: false,
  });

  // 2. Lesson Form State (supports written, pptx, video)
  const [lessonForm, setLessonForm] = useState<{
    courseSlug: string;
    lessonId: string;
    title: string;
    type: 'written' | 'pptx' | 'video';
    durationMinutes: number;
    summary: string;
    videoUrl?: string;
    subtitleUrl?: string;
    pptxUrl?: string;
    pptxFileName?: string;
    pptxSlides: PptxSlideData[];
    heading: string;
    paragraphsText: string;
    callout?: string;
    quizId?: string;
    flashcardSetId?: string;
    published: boolean;
  }>({
    courseSlug: '',
    lessonId: '',
    title: '',
    type: 'written',
    durationMinutes: 10,
    summary: '',
    videoUrl: '',
    subtitleUrl: '',
    pptxUrl: '',
    pptxFileName: '',
    pptxSlides: [],
    heading: 'Core Concepts',
    paragraphsText: '',
    callout: '',
    quizId: '',
    flashcardSetId: '',
    published: false,
  });
  const [pptxParsing, setPptxParsing] = useState(false);
  const [pptxParseError, setPptxParseError] = useState<string | null>(null);

  // 3. Multi-Question Quiz Form State
  const [quizForm, setQuizForm] = useState<{
    quizId: string;
    title: string;
    courseSlug: string;
    lessonId: string;
    passingScore: number;
    instructions: string;
    questions: QuizQuestion[];
    published: boolean;
  }>({
    quizId: '',
    title: '',
    courseSlug: '',
    lessonId: '',
    passingScore: 70,
    instructions: '',
    questions: [
      {
        id: 'q1',
        question: '',
        options: ['', '', '', ''],
        correctIndex: 0,
        explanation: '',
      },
    ],
    published: false,
  });

  // 4. Multi-Card Flashcard Form State
  const [flashcardForm, setFlashcardForm] = useState<{
    setId: string;
    title: string;
    courseSlug: string;
    lessonId: string;
    cards: Flashcard[];
    published: boolean;
  }>({
    setId: '',
    title: '',
    courseSlug: '',
    lessonId: '',
    cards: [
      {
        id: 'c1',
        front: '',
        back: '',
        category: 'Foundations',
      },
    ],
    published: false,
  });

  // 5. Live Class Form State
  const [liveClassForm, setLiveClassForm] = useState<{
    id: string;
    title: string;
    courseSlug: string;
    instructor: string;
    instructorRole: string;
    date: string;
    time: string;
    durationMinutes: number;
    level: 'Beginner' | 'Intermediate' | 'Advanced';
    agendaText: string;
    meetingUrl: string;
    status: 'upcoming' | 'completed' | 'cancelled';
    published: boolean;
  }>({
    id: '',
    title: '',
    courseSlug: '',
    instructor: '',
    instructorRole: 'Head Instructor',
    date: 'Saturday, Nov 14, 2026',
    time: '6:00 PM - 7:30 PM IST',
    durationMinutes: 90,
    level: 'Beginner',
    agendaText: 'Introduction\nLive Demo\nInteractive Q&A',
    meetingUrl: 'https://meet.google.com/coinedu-live',
    status: 'upcoming',
    published: false,
  });

  // 6. Dictionary (Glossary) Form State
  const [glossaryForm, setGlossaryForm] = useState<GlossaryItem>({
    term: '',
    category: 'Blockchain',
    shortDef: '',
    fullDef: '',
    realWorldAnalogy: '',
    beginnerPitfall: '',
    published: false,
  });

  // 7. Notification Form State
  const [notificationForm, setNotificationForm] = useState<{
    id: string;
    title: string;
    message: string;
    linkPath: string;
    expiresAt: string;
    published: boolean;
    archived: boolean;
  }>({
    id: '',
    title: '',
    message: '',
    linkPath: '',
    expiresAt: '',
    published: false,
    archived: false,
  });

  const [studentsList, setStudentsList] = useState<
    Array<{ id: string; name: string; email: string; role: string; enrolledCourses?: string[] }>
  >([]);
  const [staffInfo, setStaffInfo] = useState<{
    primaryOwner: string;
    staffCount: number;
    staffUids: string[];
    staffRecords?: Array<{
      uid: string;
      email: string;
      name?: string;
      addedBy?: string;
      addedAt?: string;
    }>;
  } | null>(null);
  const [newStaffUid, setNewStaffUid] = useState('');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [staffActionMsg, setStaffActionMsg] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    const checkServerAdmin = async () => {
      setIsVerifying(true);
      const isAuth = await verifyAdmin();
      if (mounted) {
        setIsAdminAuthorized(isAuth);
        setIsVerifying(false);

        if (isAuth) {
          try {
            const usersSnap = await getDocs(collection(db, 'users'));
            const list: Array<{
              id: string;
              name: string;
              email: string;
              role: string;
              enrolledCourses?: string[];
            }> = [];
            usersSnap.forEach((d) => {
              const data = d.data();
              list.push({
                id: d.id,
                name: data.name || 'Student',
                email: data.email || '',
                role: data.role || 'student',
                enrolledCourses: data.enrolledCourses || [],
              });
            });
            if (mounted) setStudentsList(list);
          } catch (err) {
            console.warn('Could not query students from Firestore:', err);
          }

          try {
            const authHeader = localStorage.getItem('coinedu_auth_token');
            if (authHeader) {
              const res = await fetch('/api/admin/staff', {
                headers: { Authorization: `Bearer ${authHeader}` },
              });
              if (res.ok) {
                const info = await res.json();
                if (mounted) setStaffInfo(info);
              }
            }
          } catch (err) {
            console.warn('Could not query staff info:', err);
          }
        }
      }
    };
    checkServerAdmin();
    return () => {
      mounted = false;
    };
  }, [user]);

  if (isVerifying) {
    return (
      <div className="py-24 text-center max-w-md mx-auto px-4">
        <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-xs font-mono text-slate-400">
          Verifying administrator credentials with server...
        </p>
      </div>
    );
  }

  if (!isAdminAuthorized) {
    return (
      <div className="py-24 text-center max-w-lg mx-auto px-4">
        <div className="w-16 h-16 rounded-2xl bg-rose-950/70 border border-rose-500/50 flex items-center justify-center text-rose-400 mx-auto mb-4">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">403 Forbidden: Administrator Only</h1>
        <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed">
          Access to CoinEdu administrative consoles requires a server-verified admin token.
          {user
            ? ` Your current account (${user.email}) is assigned the "${user.role}" role.`
            : ' You are currently not signed in.'}
        </p>
        <div className="flex justify-center gap-3">
          <button
            onClick={() => navigate('/login')}
            className="px-4 py-2 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold"
          >
            Sign In as Admin
          </button>
          <button
            onClick={() => navigate('/')}
            className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold border border-slate-700"
          >
            Return to Homepage
          </button>
        </div>
      </div>
    );
  }

  const adminNav = [
    { id: 'overview', label: 'Dashboard', path: '/admin', icon: LayoutDashboard },
    { id: 'courses', label: 'Courses', path: '/admin/courses', icon: BookOpen },
    { id: 'lessons', label: 'Lessons (Text/PPTX/Video)', path: '/admin/lessons', icon: FileText },
    { id: 'quizzes', label: 'Quizzes', path: '/admin/quizzes', icon: HelpCircle },
    { id: 'flashcards', label: 'Flashcards', path: '/admin/flashcards', icon: Layers },
    { id: 'live-classes', label: 'Live Classes', path: '/admin/live-classes', icon: Calendar },
    { id: 'glossary', label: 'Dictionary', path: '/admin/glossary', icon: BookOpen },
    { id: 'notifications', label: 'Notifications', path: '/admin/notifications', icon: Bell },
    { id: 'students', label: 'Students', path: '/admin/students', icon: Users },
  ];

  const totalLessons = courses.reduce((acc, c) => acc + c.lessons.length, 0);

  // Open Lesson Modal for Editing an Existing Lesson
  const openEditLessonModal = (l: LessonItem) => {
    const firstSec = l.content?.[0];
    setPptxParseError(null);
    setLessonForm({
      courseSlug: l.courseSlug,
      lessonId: l.lessonId,
      title: l.title,
      type: l.type || 'written',
      durationMinutes: l.durationMinutes || 10,
      summary: l.summary || '',
      videoUrl: l.videoUrl || '',
      subtitleUrl: l.subtitleUrl || '',
      pptxUrl: l.pptxUrl || '',
      pptxFileName: l.pptxFileName || '',
      pptxSlides: l.pptxSlides || [],
      heading: firstSec?.heading || 'Core Concepts',
      paragraphsText: firstSec?.paragraphs?.join('\n') || '',
      callout: firstSec?.callout || '',
      quizId: l.quizId || '',
      flashcardSetId: l.flashcardSetId || '',
      published: Boolean(l.published),
    });
    setActiveModal('lesson');
  };

  // Handle .pptx File Upload in Lesson Editor
  const handlePptxFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPptxParsing(true);
    setPptxParseError(null);
    try {
      const slides = await parsePptxFile(file);
      if (slides.length === 0) {
        setPptxParseError(
          'No slides could be extracted from this file. Please ensure it is a valid .pptx presentation.'
        );
      } else {
        setLessonForm((prev) => ({
          ...prev,
          pptxFileName: file.name,
          pptxSlides: slides,
        }));
      }
    } catch (err) {
      setPptxParseError(
        err instanceof Error ? err.message : 'Failed to parse .pptx presentation.'
      );
    } finally {
      setPptxParsing(false);
    }
  };

  // Form Handlers
  const handleSaveCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseForm.title) return;
    const slug =
      courseForm.slug?.trim() ||
      courseForm.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
    const summary = Array.isArray(courseForm.curriculumSummary)
      ? courseForm.curriculumSummary.map((s) => s.trim()).filter(Boolean)
      : String(courseForm.curriculumSummary || '')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean);
    const prereqs = Array.isArray(courseForm.prerequisites)
      ? courseForm.prerequisites.map((s) => s.trim()).filter(Boolean)
      : String(courseForm.prerequisites || '')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean);

    saveCourse({
      slug,
      title: courseForm.title,
      category: courseForm.category || 'Foundations',
      level: courseForm.level || 'Beginner',
      durationWeeks: Number(courseForm.durationWeeks) || 4,
      instructor: courseForm.instructor || '',
      instructorTitle: courseForm.instructorTitle || '',
      description: courseForm.description || '',
      prerequisites: prereqs,
      curriculumSummary: summary,
      lessons: courseForm.lessons || [],
      published: Boolean(courseForm.published),
      recommended: Boolean(courseForm.recommended),
    });
    setFeedbackMsg({ type: 'success', text: `Saved course "${courseForm.title}".` });
    setActiveModal(null);
  };

  const handleSaveLesson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lessonForm.courseSlug || !lessonForm.title) return;
    const lessonId = lessonForm.lessonId?.trim() || 'les_' + Date.now();
    const paragraphs = lessonForm.paragraphsText
      .split('\n')
      .map((p) => p.trim())
      .filter(Boolean);

    const newLesson: LessonItem = {
      lessonId,
      courseSlug: lessonForm.courseSlug,
      title: lessonForm.title,
      type: lessonForm.type,
      durationMinutes: Number(lessonForm.durationMinutes) || 10,
      summary: lessonForm.summary,
      ...(lessonForm.videoUrl ? { videoUrl: lessonForm.videoUrl.trim() } : {}),
      ...(lessonForm.subtitleUrl ? { subtitleUrl: lessonForm.subtitleUrl.trim() } : {}),
      ...(lessonForm.pptxUrl ? { pptxUrl: lessonForm.pptxUrl.trim() } : {}),
      ...(lessonForm.pptxFileName ? { pptxFileName: lessonForm.pptxFileName } : {}),
      ...(lessonForm.pptxSlides && lessonForm.pptxSlides.length > 0
        ? { pptxSlides: lessonForm.pptxSlides }
        : {}),
      content:
        paragraphs.length > 0 || lessonForm.type === 'written'
          ? [
              {
                heading: lessonForm.heading || 'Lesson Content',
                paragraphs:
                  paragraphs.length > 0 ? paragraphs : ['Lesson summary and notes.'],
                ...(lessonForm.callout ? { callout: lessonForm.callout } : {}),
              },
            ]
          : [],
      ...(lessonForm.quizId ? { quizId: lessonForm.quizId } : {}),
      ...(lessonForm.flashcardSetId ? { flashcardSetId: lessonForm.flashcardSetId } : {}),
      published: Boolean(lessonForm.published),
    };

    saveLesson(lessonForm.courseSlug, newLesson);
    setFeedbackMsg({ type: 'success', text: `Saved lesson "${lessonForm.title}".` });
    setActiveModal(null);
  };

  const handleSaveQuiz = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quizForm.title) return;
    const quizId = quizForm.quizId?.trim() || 'quiz_' + Date.now();
    const cleanedQuestions: QuizQuestion[] = quizForm.questions
      .filter((q) => q.question.trim() !== '')
      .map((q, idx) => ({
        id: q.id || `q${idx + 1}`,
        question: q.question.trim(),
        options: q.options.map((o) => o.trim()).filter(Boolean),
        correctIndex: Number(q.correctIndex) || 0,
        explanation: q.explanation.trim(),
      }))
      .filter((q) => q.options.length >= 2);

    saveQuiz({
      quizId,
      title: quizForm.title.trim(),
      courseSlug: quizForm.courseSlug || '',
      lessonId: quizForm.lessonId || '',
      passingScore: Number(quizForm.passingScore) || 70,
      ...(quizForm.instructions.trim()
        ? { instructions: quizForm.instructions.trim() }
        : {}),
      questions: cleanedQuestions,
      published: Boolean(quizForm.published),
    });
    setFeedbackMsg({ type: 'success', text: `Saved quiz "${quizForm.title}".` });
    setActiveModal(null);
  };

  const handleSaveFlashcards = (e: React.FormEvent) => {
    e.preventDefault();
    if (!flashcardForm.title) return;
    const setId = flashcardForm.setId?.trim() || 'fc_' + Date.now();
    const cleanedCards: Flashcard[] = flashcardForm.cards
      .filter((c) => c.front.trim() !== '' && c.back.trim() !== '')
      .map((c, idx) => ({
        id: c.id || `c${idx + 1}`,
        front: c.front.trim(),
        back: c.back.trim(),
        category: c.category.trim() || 'Core',
      }));

    saveFlashcardSet({
      setId,
      title: flashcardForm.title.trim(),
      courseSlug: flashcardForm.courseSlug || '',
      lessonId: flashcardForm.lessonId || '',
      cards: cleanedCards,
      published: Boolean(flashcardForm.published),
    });
    setFeedbackMsg({ type: 'success', text: `Saved flashcard set "${flashcardForm.title}".` });
    setActiveModal(null);
  };

  const handleSaveLiveClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!liveClassForm.title) return;
    const id = liveClassForm.id?.trim() || 'lc_' + Date.now();
    const agenda = liveClassForm.agendaText
      .split('\n')
      .map((a) => a.trim())
      .filter(Boolean);

    saveLiveClass({
      id,
      title: liveClassForm.title,
      ...(liveClassForm.courseSlug ? { courseSlug: liveClassForm.courseSlug } : {}),
      instructor: liveClassForm.instructor || 'Instructor',
      instructorRole: liveClassForm.instructorRole || 'Educator',
      date: liveClassForm.date,
      time: liveClassForm.time,
      durationMinutes: Number(liveClassForm.durationMinutes) || 60,
      level: liveClassForm.level,
      agenda,
      meetingUrl: liveClassForm.meetingUrl,
      status: liveClassForm.status,
      published: Boolean(liveClassForm.published),
    });
    setFeedbackMsg({ type: 'success', text: `Saved live class "${liveClassForm.title}".` });
    setActiveModal(null);
  };

  const handleSaveGlossary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!glossaryForm.term) return;
    saveGlossaryItem({
      ...glossaryForm,
      published: Boolean(glossaryForm.published),
    });
    setFeedbackMsg({ type: 'success', text: `Saved dictionary term "${glossaryForm.term}".` });
    setActiveModal(null);
  };

  const handleSaveNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notificationForm.title.trim() || !notificationForm.message.trim()) return;
    const id = notificationForm.id?.trim() || 'notif_' + Date.now();
    const item: NotificationItem = {
      id,
      title: notificationForm.title.trim(),
      message: notificationForm.message.trim(),
      ...(notificationForm.linkPath.trim()
        ? { linkPath: notificationForm.linkPath.trim() }
        : {}),
      createdAt: new Date().toISOString(),
      ...(notificationForm.expiresAt
        ? { expiresAt: new Date(notificationForm.expiresAt).toISOString() }
        : {}),
      published: Boolean(notificationForm.published),
      archived: Boolean(notificationForm.archived),
    };
    saveNotification(item);
    setFeedbackMsg({
      type: 'success',
      text: `Saved notification "${notificationForm.title}".`,
    });
    setActiveModal(null);
  };

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold uppercase">
              {user?.isPrimaryOwner ? 'Primary Owner' : 'Authorized Administrator'}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {user?.email || 'Administrator'}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            CoinEdu Administration Console
          </h1>
        </div>

        <button
          onClick={() => navigate('/dashboard')}
          className="text-xs text-cyan-400 hover:underline cursor-pointer"
        >
          Switch to Student View →
        </button>
      </div>

      {feedbackMsg && (
        <div
          className={`mb-6 p-3.5 rounded-xl border text-xs flex items-center justify-between gap-2 ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Admin Navigation Bar */}
      <nav
        className="flex flex-wrap gap-1.5 p-1.5 rounded-xl bg-slate-900 border border-slate-800 mb-8"
        aria-label="Admin Navigation"
      >
        {adminNav.map((item) => {
          const Icon = item.icon;
          const isActive = subroute === item.id;
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                isActive
                  ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* 1. Admin Dashboard Overview (/admin) */}
      {subroute === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4">
            <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Courses</span>
              <span className="text-2xl font-extrabold text-white font-mono">
                {courses.length}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Recommended</span>
              <span className="text-2xl font-extrabold text-amber-300 font-mono">
                {courses.filter((c) => c.recommended).length}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Lessons</span>
              <span className="text-2xl font-extrabold text-cyan-400 font-mono">
                {totalLessons}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Quizzes</span>
              <span className="text-2xl font-extrabold text-amber-300 font-mono">
                {Object.keys(quizzes).length}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Flashcards</span>
              <span className="text-2xl font-extrabold text-purple-400 font-mono">
                {Object.keys(flashcards).length}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Dictionary</span>
              <span className="text-2xl font-extrabold text-blue-400 font-mono">
                {glossaryTerms.length}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Notifications</span>
              <span className="text-2xl font-extrabold text-emerald-400 font-mono">
                {notifications.length}
              </span>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#0b1329] border border-slate-800">
            <h2 className="text-lg font-bold text-white mb-2">Create and Manage Content</h2>
            <p className="text-xs text-slate-400 leading-relaxed mb-6">
              Create, edit, preview, publish, and delete courses, written/PPTX/video lessons, multi-question quizzes, flashcard decks, live classes, dictionary definitions, and student notifications.
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => {
                  setCourseForm({
                    slug: '',
                    title: '',
                    level: 'Beginner',
                    durationWeeks: 4,
                    instructor: '',
                    instructorTitle: '',
                    description: '',
                    curriculumSummary: [],
                    published: false,
                    recommended: false,
                  });
                  setActiveModal('course');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Course</span>
              </button>
              <button
                onClick={() => {
                  setPptxParseError(null);
                  setLessonForm({
                    courseSlug: courses[0]?.slug || '',
                    lessonId: '',
                    title: '',
                    type: 'written',
                    durationMinutes: 10,
                    summary: '',
                    videoUrl: '',
                    subtitleUrl: '',
                    pptxUrl: '',
                    pptxFileName: '',
                    pptxSlides: [],
                    heading: 'Core Concepts',
                    paragraphsText: '',
                    callout: '',
                    quizId: '',
                    flashcardSetId: '',
                    published: false,
                  });
                  setActiveModal('lesson');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 hover:bg-cyan-900 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Lesson (Text / PPTX / Video)</span>
              </button>
              <button
                onClick={() => {
                  setQuizForm({
                    quizId: '',
                    title: '',
                    courseSlug: courses[0]?.slug || '',
                    lessonId: '',
                    passingScore: 70,
                    instructions: '',
                    questions: [
                      {
                        id: 'q1',
                        question: '',
                        options: ['', '', '', ''],
                        correctIndex: 0,
                        explanation: '',
                      },
                    ],
                    published: false,
                  });
                  setActiveModal('quiz');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Create Quiz</span>
              </button>
              <button
                onClick={() => {
                  setFlashcardForm({
                    setId: '',
                    title: '',
                    courseSlug: courses[0]?.slug || '',
                    lessonId: '',
                    cards: [
                      {
                        id: 'c1',
                        front: '',
                        back: '',
                        category: 'Foundations',
                      },
                    ],
                    published: false,
                  });
                  setActiveModal('flashcard');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-purple-950 text-purple-300 border border-purple-800 hover:bg-purple-900 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Flashcards</span>
              </button>
              <button
                onClick={() => {
                  setNotificationForm({
                    id: '',
                    title: '',
                    message: '',
                    linkPath: '',
                    expiresAt: '',
                    published: true,
                    archived: false,
                  });
                  setActiveModal('notification');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-800 hover:bg-emerald-900 cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                <span>Send Notification</span>
              </button>
            </div>
          </div>

          {/* Admin Activity & Error Reporting Panel */}
          <div className="p-6 rounded-2xl bg-[#0b1329] border border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <h2 className="text-base font-bold text-white">Content Activity & System Log</h2>
              </div>
              {activityLogs.length > 0 && (
                <button
                  onClick={() => clearAdminActivityLogs()}
                  className="text-xs text-slate-400 hover:text-rose-400 cursor-pointer"
                >
                  Clear Log
                </button>
              )}
            </div>
            {activityLogs.length === 0 ? (
              <p className="text-xs text-slate-500">
                No recent content edits or system errors recorded in this session.
              </p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {activityLogs.map((log) => (
                  <div
                    key={log.id}
                    className={`flex items-center justify-between p-3 rounded-xl border text-xs ${
                      log.status === 'error'
                        ? 'bg-rose-950/30 border-rose-500/40 text-rose-200'
                        : 'bg-slate-900/70 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {log.status === 'error' ? (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      )}
                      <span className="font-bold text-white">{log.action}:</span>
                      <span>{log.details}</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. Manage Courses (/admin/courses) */}
      {subroute === 'courses' && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Course Catalogue & Recommended Toggle</h2>
              <span className="text-xs text-slate-400 font-mono">
                {courses.length} Courses Total · {courses.filter((c) => c.recommended).length} Recommended
              </span>
            </div>
            <button
              onClick={() => {
                setCourseForm({
                  slug: '',
                  title: '',
                  level: 'Beginner',
                  durationWeeks: 4,
                  instructor: '',
                  instructorTitle: '',
                  description: '',
                  curriculumSummary: [],
                  published: false,
                  recommended: false,
                });
                setActiveModal('course');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Course</span>
            </button>
          </div>

          {courses.length === 0 ? (
            <div className="py-12 text-center border border-slate-800 rounded-xl bg-slate-900/40">
              <BookOpen className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-white mb-1">No courses available yet.</p>
              <p className="text-xs text-slate-400 mb-4">
                Click "Add Course" to manually author your first course track.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900 text-slate-400 uppercase font-mono">
                  <tr>
                    <th className="p-3">Course Title</th>
                    <th className="p-3">Level</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Recommended</th>
                    <th className="p-3">Lessons</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-slate-200">
                  {courses.map((c) => (
                    <tr key={c.slug} className="hover:bg-slate-850/50">
                      <td className="p-3 font-bold text-white">{c.title}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono text-[10px]">
                          {c.level}
                        </span>
                      </td>
                      <td className="p-3">
                        <button
                          onClick={() => toggleCoursePublish(c.slug)}
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded font-mono text-[10px] cursor-pointer ${
                            c.published
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {c.published ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                          <span>{c.published ? 'Published' : 'Draft'}</span>
                        </button>
                      </td>
                      <td className="p-3">
                        <button
                          onClick={() => toggleCourseRecommended(c.slug)}
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded font-mono text-[10px] cursor-pointer ${
                            c.recommended
                              ? 'bg-amber-400/20 text-amber-300 border border-amber-400/50 font-bold'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                          title="Toggle visibility on the public Recommended Courses page"
                        >
                          <Star className="w-3 h-3" />
                          <span>{c.recommended ? 'Recommended ★' : 'Standard'}</span>
                        </button>
                      </td>
                      <td className="p-3 font-mono">{c.lessons.length}</td>
                      <td className="p-3 text-right space-x-2">
                        <button
                          onClick={() => navigate(`/courses/${c.slug}`)}
                          className="text-cyan-400 hover:underline cursor-pointer"
                        >
                          Preview
                        </button>
                        <button
                          onClick={() => {
                            setCourseForm({ ...c });
                            setActiveModal('course');
                          }}
                          className="text-amber-400 hover:underline cursor-pointer"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => {
                            setConfirmAction({
                              title: 'Delete Course',
                              message: `Are you sure you want to permanently delete the course "${c.title}" and all its lessons?`,
                              onConfirm: () => {
                                deleteCourse(c.slug);
                                setFeedbackMsg({
                                  type: 'success',
                                  text: `Deleted course "${c.title}".`,
                                });
                              },
                            });
                          }}
                          className="text-rose-400 hover:underline cursor-pointer"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 3. Manage Lessons (/admin/lessons) */}
      {subroute === 'lessons' && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">
                Written, PPTX Presentation & Video Lessons
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                {totalLessons} Lessons Total
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex rounded-xl bg-slate-900 border border-slate-800 p-1">
                {(['all', 'written', 'pptx', 'video'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setLessonFilterType(t)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold uppercase cursor-pointer ${
                      lessonFilterType === t
                        ? 'bg-cyan-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <button
                onClick={() => {
                  setPptxParseError(null);
                  setLessonForm({
                    courseSlug: courses[0]?.slug || '',
                    lessonId: '',
                    title: '',
                    type: lessonFilterType === 'all' ? 'written' : lessonFilterType,
                    durationMinutes: 10,
                    summary: '',
                    videoUrl: '',
                    subtitleUrl: '',
                    pptxUrl: '',
                    pptxFileName: '',
                    pptxSlides: [],
                    heading: 'Core Concepts',
                    paragraphsText: '',
                    callout: '',
                    quizId: '',
                    flashcardSetId: '',
                    published: false,
                  });
                  setActiveModal('lesson');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Lesson</span>
              </button>
            </div>
          </div>

          {totalLessons === 0 ? (
            <div className="py-12 text-center border border-slate-800 rounded-xl bg-slate-900/40">
              <FileText className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-white mb-1">No lessons have been added yet.</p>
              <p className="text-xs text-slate-400 mb-4">
                Click "Add Lesson" to add written, PowerPoint (.pptx), or video lessons to a course.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {courses
                .flatMap((c) =>
                  c.lessons.map((l, idx) => ({
                    ...l,
                    orderIndex: idx,
                    totalInCourse: c.lessons.length,
                  }))
                )
                .filter((l) => lessonFilterType === 'all' || l.type === lessonFilterType)
                .map((l) => (
                  <div
                    key={l.lessonId}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500 font-mono">#{l.orderIndex + 1}</span>
                        <span className="font-bold text-white text-sm">{l.title}</span>
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono uppercase text-[10px]">
                          {l.type}
                        </span>
                        <button
                          onClick={() => toggleLessonPublish(l.lessonId)}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                            l.published
                              ? 'bg-emerald-950 text-emerald-300'
                              : 'bg-amber-950 text-amber-300'
                          }`}
                        >
                          {l.published ? 'Published' : 'Draft'}
                        </button>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                        Course: {l.courseSlug} • {l.durationMinutes}m • ID: {l.lessonId}
                        {l.type === 'pptx' && (
                          <span className="ml-2 text-amber-300">
                            ({l.pptxSlides?.length || 0} slides)
                          </span>
                        )}
                        {l.type === 'video' && (
                          <span className="ml-2 text-cyan-400">
                            ({l.videoUrl ? 'Video URL ready' : 'No video URL'})
                          </span>
                        )}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 self-end sm:self-auto">
                      <button
                        onClick={() => reorderLesson(l.courseSlug, l.lessonId, 'up')}
                        disabled={l.orderIndex === 0}
                        className="p-1.5 rounded bg-slate-800 text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                        title="Move lesson up"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => reorderLesson(l.courseSlug, l.lessonId, 'down')}
                        disabled={l.orderIndex >= l.totalInCourse - 1}
                        className="p-1.5 rounded bg-slate-800 text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                        title="Move lesson down"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => navigate(`/learn/${l.lessonId}`)}
                        className="px-3 py-1 rounded bg-slate-800 text-cyan-400 hover:text-white cursor-pointer"
                      >
                        Preview
                      </button>
                      <button
                        onClick={() => openEditLessonModal(l)}
                        className="px-3 py-1 rounded bg-slate-800 text-amber-400 hover:text-white cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => {
                          setConfirmAction({
                            title: 'Delete Lesson',
                            message: `Are you sure you want to permanently delete the lesson "${l.title}"?`,
                            onConfirm: () => {
                              deleteLesson(l.lessonId);
                              setFeedbackMsg({
                                type: 'success',
                                text: `Deleted lesson "${l.title}".`,
                              });
                            },
                          });
                        }}
                        className="px-3 py-1 rounded bg-slate-800 text-rose-400 hover:text-white cursor-pointer"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* 4. Manage Quizzes (/admin/quizzes) */}
      {subroute === 'quizzes' && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">
                Multi-Question Quizzes & Course Assessments
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                {Object.keys(quizzes).length} Quizzes Total
              </span>
            </div>
            <button
              onClick={() => {
                setQuizForm({
                  quizId: '',
                  title: '',
                  courseSlug: courses[0]?.slug || '',
                  lessonId: '',
                  passingScore: 70,
                  instructions: '',
                  questions: [
                    {
                      id: 'q1',
                      question: '',
                      options: ['', '', '', ''],
                      correctIndex: 0,
                      explanation: '',
                    },
                  ],
                  published: false,
                });
                setActiveModal('quiz');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Quiz</span>
            </button>
          </div>

          {Object.keys(quizzes).length === 0 ? (
            <div className="py-12 text-center border border-slate-800 rounded-xl bg-slate-900/40">
              <HelpCircle className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-white mb-1">No quizzes available yet.</p>
              <p className="text-xs text-slate-400 mb-4">
                Click "Create Quiz" to author multi-question assessments linked to a course.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {Object.values(quizzes).map((q) => (
                <div
                  key={q.quizId}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{q.title}</span>
                      <button
                        onClick={() => toggleQuizPublish(q.quizId)}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                          q.published
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {q.published ? 'Published' : 'Draft'}
                      </button>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                      Course: {q.courseSlug || 'Unassigned'} • {q.questions.length} Questions • Pass Score: {q.passingScore}% • ID: {q.quizId}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button
                      onClick={() => navigate(`/quiz/${q.quizId}`)}
                      className="px-3 py-1 rounded bg-slate-800 text-cyan-400 hover:text-white cursor-pointer"
                    >
                      Preview
                    </button>
                    <button
                      onClick={() => {
                        setQuizForm({
                          quizId: q.quizId,
                          title: q.title,
                          courseSlug: q.courseSlug || '',
                          lessonId: q.lessonId || '',
                          passingScore: q.passingScore || 70,
                          instructions: q.instructions || '',
                          questions:
                            q.questions.length > 0
                              ? q.questions.map((item) => ({
                                  ...item,
                                  options: [
                                    item.options[0] || '',
                                    item.options[1] || '',
                                    item.options[2] || '',
                                    item.options[3] || '',
                                  ],
                                }))
                              : [
                                  {
                                    id: 'q1',
                                    question: '',
                                    options: ['', '', '', ''],
                                    correctIndex: 0,
                                    explanation: '',
                                  },
                                ],
                          published: Boolean(q.published),
                        });
                        setActiveModal('quiz');
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-amber-400 hover:text-white cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        setConfirmAction({
                          title: 'Delete Quiz',
                          message: `Are you sure you want to permanently delete the quiz "${q.title}"?`,
                          onConfirm: () => deleteQuiz(q.quizId),
                        });
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-rose-400 hover:text-white cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 5. Manage Flashcards (/admin/flashcards) */}
      {subroute === 'flashcards' && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Multi-Card Flashcard Decks</h2>
              <span className="text-xs text-slate-400 font-mono">
                {Object.keys(flashcards).length} Decks Total
              </span>
            </div>
            <button
              onClick={() => {
                setFlashcardForm({
                  setId: '',
                  title: '',
                  courseSlug: courses[0]?.slug || '',
                  lessonId: '',
                  cards: [
                    {
                      id: 'c1',
                      front: '',
                      back: '',
                      category: 'Foundations',
                    },
                  ],
                  published: false,
                });
                setActiveModal('flashcard');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Flashcard Set</span>
            </button>
          </div>

          {Object.keys(flashcards).length === 0 ? (
            <div className="py-12 text-center border border-slate-800 rounded-xl bg-slate-900/40">
              <Layers className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-white mb-1">
                No flashcards have been added yet.
              </p>
              <p className="text-xs text-slate-400 mb-4">
                Click "Add Flashcard Set" to create multi-card study decks linked to a course.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {Object.values(flashcards).map((fc) => (
                <div
                  key={fc.setId}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{fc.title}</span>
                      <button
                        onClick={() => toggleFlashcardPublish(fc.setId)}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                          fc.published
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {fc.published ? 'Published' : 'Draft'}
                      </button>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                      Course: {fc.courseSlug || 'Unassigned'} • {fc.cards.length} Cards • ID: {fc.setId}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button
                      onClick={() => navigate(`/flashcards/${fc.setId}`)}
                      className="px-3 py-1 rounded bg-slate-800 text-cyan-400 hover:text-white cursor-pointer"
                    >
                      Preview
                    </button>
                    <button
                      onClick={() => {
                        setFlashcardForm({
                          setId: fc.setId,
                          title: fc.title,
                          courseSlug: fc.courseSlug || '',
                          lessonId: fc.lessonId || '',
                          cards:
                            fc.cards.length > 0
                              ? fc.cards.map((c) => ({ ...c }))
                              : [
                                  {
                                    id: 'c1',
                                    front: '',
                                    back: '',
                                    category: 'Foundations',
                                  },
                                ],
                          published: Boolean(fc.published),
                        });
                        setActiveModal('flashcard');
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-amber-400 hover:text-white cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        setConfirmAction({
                          title: 'Delete Flashcard Set',
                          message: `Are you sure you want to permanently delete the flashcard set "${fc.title}"?`,
                          onConfirm: () => deleteFlashcardSet(fc.setId),
                        });
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-rose-400 hover:text-white cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 6. Manage Live Classes (/admin/live-classes) */}
      {subroute === 'live-classes' && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Live Online Classes</h2>
              <span className="text-xs text-slate-400 font-mono">
                {liveClasses.length} Scheduled Total
              </span>
            </div>
            <button
              onClick={() => {
                setLiveClassForm({
                  id: '',
                  title: '',
                  courseSlug: courses[0]?.slug || '',
                  instructor: '',
                  instructorRole: 'Head Researcher',
                  date: 'Saturday, Nov 14, 2026',
                  time: '6:00 PM - 7:30 PM IST',
                  durationMinutes: 90,
                  level: 'Beginner',
                  agendaText: 'Overview\nLive Analysis\nQ&A',
                  meetingUrl: 'https://meet.google.com/coinedu-live',
                  status: 'upcoming',
                  published: false,
                });
                setActiveModal('live-class');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Schedule Live Class</span>
            </button>
          </div>

          {liveClasses.length === 0 ? (
            <div className="py-12 text-center border border-slate-800 rounded-xl bg-slate-900/40">
              <Calendar className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-white mb-1">No upcoming live classes.</p>
              <p className="text-xs text-slate-400 mb-4">
                Click "Schedule Live Class" to schedule a live online session for students.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {liveClasses.map((cls) => (
                <div
                  key={cls.id}
                  className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{cls.title}</span>
                      <button
                        onClick={() => toggleLiveClassPublish(cls.id)}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                          cls.published
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {cls.published ? 'Published' : 'Draft'}
                      </button>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono uppercase text-[10px]">
                      {cls.status}
                    </span>
                  </div>
                  <p className="text-slate-400">
                    Instructor: {cls.instructor} | Date: {cls.date} ({cls.time})
                  </p>
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] font-mono text-cyan-400">
                      Meeting: {cls.meetingUrl}
                    </span>
                    <div className="space-x-3">
                      <button
                        onClick={() => {
                          setLiveClassForm({
                            id: cls.id,
                            title: cls.title,
                            courseSlug: cls.courseSlug || '',
                            instructor: cls.instructor,
                            instructorRole: cls.instructorRole,
                            date: cls.date,
                            time: cls.time,
                            durationMinutes: cls.durationMinutes,
                            level: cls.level,
                            agendaText: cls.agenda.join('\n'),
                            meetingUrl: cls.meetingUrl,
                            status: cls.status,
                            published: Boolean(cls.published),
                          });
                          setActiveModal('live-class');
                        }}
                        className="text-amber-400 hover:underline cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => {
                          setConfirmAction({
                            title: 'Delete Live Class',
                            message: `Are you sure you want to permanently delete the live class "${cls.title}"?`,
                            onConfirm: () => deleteLiveClass(cls.id),
                          });
                        }}
                        className="text-rose-400 hover:underline cursor-pointer"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 7. Manage Dictionary (/admin/glossary) */}
      {subroute === 'glossary' && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Dictionary Terms</h2>
              <span className="text-xs text-slate-400 font-mono">
                {glossaryTerms.length} Terms Total
              </span>
            </div>
            <button
              onClick={() => {
                setGlossaryForm({
                  term: '',
                  category: 'Blockchain',
                  shortDef: '',
                  fullDef: '',
                  realWorldAnalogy: '',
                  beginnerPitfall: '',
                  published: false,
                });
                setActiveModal('glossary');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Dictionary Term</span>
            </button>
          </div>

          {glossaryTerms.length === 0 ? (
            <div className="py-12 text-center border border-slate-800 rounded-xl bg-slate-900/40">
              <BookOpen className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-white mb-1">No dictionary terms available yet.</p>
              <p className="text-xs text-slate-400 mb-4">
                Click "Add Dictionary Term" to add definitions for the student Dictionary.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {glossaryTerms.map((g) => (
                <div
                  key={g.term}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{g.term}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono text-[10px]">
                        {g.category}
                      </span>
                      <button
                        onClick={() => toggleGlossaryPublish(g.term)}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                          g.published
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {g.published ? 'Published' : 'Draft'}
                      </button>
                    </div>
                    <p className="text-slate-400 mt-1 line-clamp-1">{g.shortDef}</p>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button
                      onClick={() => navigate('/dictionary')}
                      className="px-3 py-1 rounded bg-slate-800 text-cyan-400 hover:text-white cursor-pointer"
                    >
                      Preview
                    </button>
                    <button
                      onClick={() => {
                        setGlossaryForm({ ...g });
                        setActiveModal('glossary');
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-amber-400 hover:text-white cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        setConfirmAction({
                          title: 'Delete Dictionary Term',
                          message: `Are you sure you want to permanently delete the term "${g.term}"?`,
                          onConfirm: () => deleteGlossaryItem(g.term),
                        });
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-rose-400 hover:text-white cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 8. Manage Notifications (/admin/notifications) */}
      {subroute === 'notifications' && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Student Notifications</h2>
              <span className="text-xs text-slate-400 font-mono">
                {notifications.length} Notifications Total
              </span>
            </div>
            <button
              onClick={() => {
                setNotificationForm({
                  id: '',
                  title: '',
                  message: '',
                  linkPath: '',
                  expiresAt: '',
                  published: true,
                  archived: false,
                });
                setActiveModal('notification');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-400 hover:bg-emerald-300 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Notification</span>
            </button>
          </div>

          {notifications.length === 0 ? (
            <div className="py-12 text-center border border-slate-800 rounded-xl bg-slate-900/40">
              <Bell className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-white mb-1">No notifications created yet.</p>
              <p className="text-xs text-slate-400 mb-4">
                Create announcements for new courses, live classes, or quizzes that appear in the student notification bell.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {notifications.map((n) => (
                <div
                  key={n.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs gap-3"
                >
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-white text-sm">{n.title}</span>
                      <button
                        onClick={() => toggleNotificationPublish(n.id)}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                          n.published
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {n.published ? 'Published' : 'Draft'}
                      </button>
                      {n.archived && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono text-[10px]">
                          Archived
                        </span>
                      )}
                    </div>
                    <p className="text-slate-300 mt-1">{n.message}</p>
                    <span className="text-[11px] text-slate-500 font-mono block mt-1">
                      Created: {new Date(n.createdAt).toLocaleString('en-IN')}
                      {n.linkPath ? ` • Link: ${n.linkPath}` : ''}
                      {n.expiresAt
                        ? ` • Expires: ${new Date(n.expiresAt).toLocaleDateString('en-IN')}`
                        : ''}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    <button
                      onClick={() => toggleNotificationArchive(n.id)}
                      className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:text-white cursor-pointer flex items-center gap-1"
                    >
                      <Archive className="w-3 h-3" />
                      <span>{n.archived ? 'Unarchive' : 'Archive'}</span>
                    </button>
                    <button
                      onClick={() => {
                        setNotificationForm({
                          id: n.id,
                          title: n.title,
                          message: n.message,
                          linkPath: n.linkPath || '',
                          expiresAt: n.expiresAt ? n.expiresAt.slice(0, 10) : '',
                          published: Boolean(n.published),
                          archived: Boolean(n.archived),
                        });
                        setActiveModal('notification');
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-amber-400 hover:text-white cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        setConfirmAction({
                          title: 'Delete Notification',
                          message: `Are you sure you want to permanently delete the notification "${n.title}"?`,
                          onConfirm: () => deleteNotification(n.id),
                        });
                      }}
                      className="px-3 py-1 rounded bg-slate-800 text-rose-400 hover:text-white cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 9. Manage Students (/admin/students) */}
      {subroute === 'students' && (
        <div className="space-y-8">
          <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-bold text-white">Registered Students</h2>
                <p className="text-xs text-slate-400">
                  All registered users are assigned the "student" role by default.
                </p>
              </div>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-3 py-1 rounded-lg border border-cyan-800/40">
                {studentsList.length} Registered
              </span>
            </div>

            {studentsList.length === 0 ? (
              <div className="py-16 text-center border border-slate-800 rounded-xl bg-slate-900/40 p-8">
                <Users className="w-12 h-12 text-slate-500 mx-auto mb-3" />
                <p className="text-base font-bold text-white mb-1">No students registered yet.</p>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Real student accounts will appear here automatically as learners register with Google or email.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 text-slate-400 uppercase font-mono">
                    <tr>
                      <th className="p-3">Student Name</th>
                      <th className="p-3">Email Address</th>
                      <th className="p-3">System Role</th>
                      <th className="p-3">Enrolled Courses</th>
                      <th className="p-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-200">
                    {studentsList.map((st) => (
                      <tr key={st.id}>
                        <td className="p-3 font-bold text-white">{st.name}</td>
                        <td className="p-3 font-mono text-slate-400">{st.email}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono text-[10px]">
                            {st.role}
                          </span>
                        </td>
                        <td className="p-3 font-mono">
                          {st.enrolledCourses?.length || 0} courses
                        </td>
                        <td className="p-3 text-emerald-400 font-medium">Active</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Server-Side Staff Management */}
          <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-5">
            <div>
              <h2 className="text-lg font-bold text-white mb-1">Administrator Privileges</h2>
              <p className="text-xs text-slate-400">
                Active administrators with verified access to the CoinEdu Administration Console.
              </p>
            </div>

            {/* Active Administrators List (Visible to all verified admins) */}
            <div className="space-y-2.5">
              {/* 1. Primary Owner */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3.5 rounded-xl bg-slate-900/90 border border-amber-500/30 text-xs">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white font-mono">
                      {staffInfo?.primaryOwner || 'rakshiths056@gmail.com'}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-700/60 font-mono text-[10px] font-bold uppercase">
                      Primary Owner
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Full platform ownership, content management, and administrator access control.
                  </p>
                </div>
                <span className="text-[11px] font-mono text-emerald-400 shrink-0">
                  Protected Owner Account
                </span>
              </div>

              {/* 2. Additional Administrators */}
              {(staffInfo?.staffRecords && staffInfo.staffRecords.length > 0
                ? staffInfo.staffRecords
                : (staffInfo?.staffUids || ['liDG3eSTJuS8eTxin2JWt6SpqvD2']).map((uid) => ({
                    uid,
                    email:
                      uid === 'liDG3eSTJuS8eTxin2JWt6SpqvD2'
                        ? 'jeffery158540@gmail.com'
                        : '',
                    name: 'Additional Administrator',
                  }))
              ).map((adminRec) => (
                <div
                  key={adminRec.uid}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-white font-mono">
                        {adminRec.email || adminRec.uid}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/60 font-mono text-[10px] font-bold uppercase">
                        Additional Administrator
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-mono">
                      Firebase UID: {adminRec.uid}
                    </p>
                  </div>

                  {user?.isPrimaryOwner ? (
                    <button
                      onClick={async () => {
                        const authHeader = localStorage.getItem('coinedu_auth_token');
                        try {
                          const res = await fetch('/api/admin/staff/revoke', {
                            method: 'POST',
                            headers: {
                              Authorization: `Bearer ${authHeader}`,
                              'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({ staffUid: adminRec.uid }),
                          });
                          const data = await res.json();
                          setStaffActionMsg(data.message || data.error);
                          const r = await fetch('/api/admin/staff', {
                            headers: { Authorization: `Bearer ${authHeader}` },
                          });
                          if (r.ok) setStaffInfo(await r.json());
                        } catch {
                          setStaffActionMsg('Network error');
                        }
                      }}
                      className="text-rose-400 hover:underline text-[11px] font-semibold cursor-pointer self-end sm:self-auto"
                    >
                      Revoke Access
                    </button>
                  ) : (
                    <span className="text-[11px] font-mono text-cyan-400 shrink-0">
                      Active Admin
                    </span>
                  )}
                </div>
              ))}
            </div>

            {user?.isPrimaryOwner ? (
              <div className="space-y-4 pt-4 border-t border-slate-800">
                <p className="text-xs text-slate-300">
                  As the primary owner (<span className="font-mono text-amber-300">rakshiths056@gmail.com</span>), you can grant or revoke additional administrator access using a user&apos;s Firebase UID.
                </p>

                {staffActionMsg && (
                  <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-xs text-cyan-300">
                    {staffActionMsg}
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-2 max-w-2xl">
                  <input
                    type="text"
                    value={newStaffUid}
                    onChange={(e) => setNewStaffUid(e.target.value)}
                    placeholder="Enter Staff Firebase UID (required)"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                  />
                  <input
                    type="email"
                    value={newStaffEmail}
                    onChange={(e) => setNewStaffEmail(e.target.value)}
                    placeholder="Staff Email (optional)"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                  />
                  <button
                    onClick={async () => {
                      if (!newStaffUid.trim()) return;
                      const authHeader = localStorage.getItem('coinedu_auth_token');
                      try {
                        const res = await fetch('/api/admin/staff/grant', {
                          method: 'POST',
                          headers: {
                            Authorization: `Bearer ${authHeader}`,
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({
                            staffUid: newStaffUid.trim(),
                            staffEmail: newStaffEmail.trim(),
                          }),
                        });
                        const data = await res.json();
                        if (res.ok) {
                          setStaffActionMsg(data.message);
                          setNewStaffUid('');
                          setNewStaffEmail('');
                          const r = await fetch('/api/admin/staff', {
                            headers: { Authorization: `Bearer ${authHeader}` },
                          });
                          if (r.ok) setStaffInfo(await r.json());
                        } else {
                          setStaffActionMsg(data.error || 'Failed to grant admin');
                        }
                      } catch {
                        setStaffActionMsg('Network error');
                      }
                    }}
                    className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl cursor-pointer shrink-0"
                  >
                    Grant Admin
                  </button>
                </div>
              </div>
            ) : (
              <div className="pt-3 border-t border-slate-800">
                <p className="text-xs text-slate-400 italic">
                  Only the designated primary owner ({staffInfo?.primaryOwner || 'rakshiths056@gmail.com'}) can grant or revoke additional administrator privileges.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODALS */}
      {/* 1. Add/Edit Course Modal */}
      {activeModal === 'course' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-xl w-full p-6 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Author Course Track</h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCourse} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Course Title *</label>
                <input
                  type="text"
                  required
                  value={courseForm.title || ''}
                  onChange={(e) => setCourseForm({ ...courseForm, title: e.target.value })}
                  placeholder="e.g. Crypto Foundations & Wallets"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Category</label>
                  <select
                    value={courseForm.category || 'Foundations'}
                    onChange={(e) =>
                      setCourseForm({ ...courseForm, category: e.target.value as any })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    {COURSE_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Difficulty Level</label>
                  <select
                    value={courseForm.level}
                    onChange={(e) =>
                      setCourseForm({ ...courseForm, level: e.target.value as any })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Duration (Weeks)</label>
                  <input
                    type="number"
                    min={1}
                    max={52}
                    value={courseForm.durationWeeks || 4}
                    onChange={(e) =>
                      setCourseForm({ ...courseForm, durationWeeks: Number(e.target.value) })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Instructor Name (optional)
                  </label>
                  <input
                    type="text"
                    value={courseForm.instructor || ''}
                    onChange={(e) => setCourseForm({ ...courseForm, instructor: e.target.value })}
                    placeholder="Instructor name"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Instructor Role (optional)
                  </label>
                  <input
                    type="text"
                    value={courseForm.instructorTitle || ''}
                    onChange={(e) =>
                      setCourseForm({ ...courseForm, instructorTitle: e.target.value })
                    }
                    placeholder="e.g. Blockchain Educator"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Description</label>
                <textarea
                  rows={2}
                  value={courseForm.description || ''}
                  onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
                  placeholder="Overview of syllabus and learning outcomes..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Prerequisites (one per line)
                </label>
                <textarea
                  rows={2}
                  value={
                    Array.isArray(courseForm.prerequisites)
                      ? courseForm.prerequisites.join('\n')
                      : courseForm.prerequisites || ''
                  }
                  onChange={(e) =>
                    setCourseForm({ ...courseForm, prerequisites: e.target.value.split('\n') })
                  }
                  placeholder="Basic internet usage&#10;No prior trading experience needed"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Learning Outcomes (one per line)
                </label>
                <textarea
                  rows={2}
                  value={
                    Array.isArray(courseForm.curriculumSummary)
                      ? courseForm.curriculumSummary.join('\n')
                      : courseForm.curriculumSummary
                  }
                  onChange={(e) =>
                    setCourseForm({
                      ...courseForm,
                      curriculumSummary: e.target.value.split('\n'),
                    })
                  }
                  placeholder="How digital money works&#10;What are private keys"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <input
                    type="checkbox"
                    id="coursePublished"
                    checked={Boolean(courseForm.published)}
                    onChange={(e) =>
                      setCourseForm({ ...courseForm, published: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-cyan-500"
                  />
                  <label
                    htmlFor="coursePublished"
                    className="text-slate-300 font-medium cursor-pointer"
                  >
                    Publish course
                  </label>
                </div>

                <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-950/30 border border-amber-500/30">
                  <input
                    type="checkbox"
                    id="courseRecommended"
                    checked={Boolean(courseForm.recommended)}
                    onChange={(e) =>
                      setCourseForm({ ...courseForm, recommended: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-amber-400"
                  />
                  <label
                    htmlFor="courseRecommended"
                    className="text-amber-200 font-medium cursor-pointer"
                  >
                    Mark as Recommended ★
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 font-bold text-slate-950"
                >
                  Save Course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. Add/Edit Lesson Modal (Written, PPTX, Video) */}
      {activeModal === 'lesson' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-4 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {lessonForm.lessonId ? 'Edit Lesson' : 'Add Lesson (Written / PPTX / Video)'}
              </h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLesson} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Select Course *
                  </label>
                  {courses.length === 0 ? (
                    <p className="text-rose-400 font-medium">
                      Please add a course first before adding lessons.
                    </p>
                  ) : (
                    <select
                      required
                      value={lessonForm.courseSlug}
                      onChange={(e) =>
                        setLessonForm({ ...lessonForm, courseSlug: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    >
                      {courses.map((c) => (
                        <option key={c.slug} value={c.slug}>
                          {c.title} ({c.slug})
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Lesson Format *
                  </label>
                  <select
                    value={lessonForm.type}
                    onChange={(e) =>
                      setLessonForm({ ...lessonForm, type: e.target.value as any })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="written">Written Text Lesson</option>
                    <option value="pptx">PowerPoint Presentation (.pptx)</option>
                    <option value="video">Video Lesson</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-semibold mb-1">
                    Lesson Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={lessonForm.title}
                    onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })}
                    placeholder="e.g. Digital Money & The Double Spend Problem"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={lessonForm.durationMinutes}
                    onChange={(e) =>
                      setLessonForm({
                        ...lessonForm,
                        durationMinutes: Number(e.target.value),
                      })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Lesson Summary</label>
                <input
                  type="text"
                  value={lessonForm.summary}
                  onChange={(e) => setLessonForm({ ...lessonForm, summary: e.target.value })}
                  placeholder="Brief synopsis for course syllabus..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              {/* PPTX Presentation Upload & Slide Editor */}
              {lessonForm.type === 'pptx' && (
                <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/30 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-amber-300 font-bold">
                      <Presentation className="w-4 h-4" />
                      <span>PowerPoint (.pptx) Presentation Deck</span>
                    </div>
                    {lessonForm.pptxFileName && (
                      <span className="text-[11px] font-mono text-emerald-400">
                        File: {lessonForm.pptxFileName} ({lessonForm.pptxSlides.length} slides)
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Upload .pptx File (Extracts Slides Automatically)
                      </label>
                      <label className="flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-300 font-bold cursor-pointer">
                        <Upload className="w-4 h-4" />
                        <span>{pptxParsing ? 'Extracting Slides...' : 'Choose .pptx File'}</span>
                        <input
                          type="file"
                          accept=".pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                          onChange={handlePptxFileUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Or Direct .pptx File URL (Optional)
                      </label>
                      <input
                        type="text"
                        value={lessonForm.pptxUrl || ''}
                        onChange={(e) =>
                          setLessonForm({ ...lessonForm, pptxUrl: e.target.value })
                        }
                        placeholder="https://example.com/deck.pptx"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                      />
                    </div>
                  </div>

                  {pptxParseError && (
                    <p className="text-rose-400 text-xs">{pptxParseError}</p>
                  )}

                  {/* Add / Edit Slides Manually or Review Extracted Slides */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300 font-semibold">
                        Slide Deck Content ({lessonForm.pptxSlides.length} Slides)
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setLessonForm((prev) => ({
                            ...prev,
                            pptxSlides: [
                              ...prev.pptxSlides,
                              {
                                slideNumber: prev.pptxSlides.length + 1,
                                title: `Slide ${prev.pptxSlides.length + 1}`,
                                bullets: ['Key point 1'],
                                notes: '',
                              },
                            ],
                          }))
                        }
                        className="px-2.5 py-1 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-500/30 font-bold cursor-pointer"
                      >
                        + Add Slide
                      </button>
                    </div>

                    {lessonForm.pptxSlides.map((slide, sIdx) => (
                      <div
                        key={sIdx}
                        className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-amber-400 font-bold">
                            Slide {sIdx + 1}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setLessonForm((prev) => ({
                                ...prev,
                                pptxSlides: prev.pptxSlides
                                  .filter((_, i) => i !== sIdx)
                                  .map((s, idx) => ({ ...s, slideNumber: idx + 1 })),
                              }))
                            }
                            className="text-rose-400 hover:underline"
                          >
                            Remove Slide
                          </button>
                        </div>
                        <input
                          type="text"
                          value={slide.title}
                          onChange={(e) => {
                            const updated = [...lessonForm.pptxSlides];
                            updated[sIdx] = { ...updated[sIdx], title: e.target.value };
                            setLessonForm({ ...lessonForm, pptxSlides: updated });
                          }}
                          placeholder="Slide Title"
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                        />
                        <textarea
                          rows={2}
                          value={slide.bullets.join('\n')}
                          onChange={(e) => {
                            const updated = [...lessonForm.pptxSlides];
                            updated[sIdx] = {
                              ...updated[sIdx],
                              bullets: e.target.value.split('\n'),
                            };
                            setLessonForm({ ...lessonForm, pptxSlides: updated });
                          }}
                          placeholder="Bullet points (one per line)"
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                        />
                      </div>
                    ))}
                  </div>

                  {lessonForm.pptxSlides.length > 0 && (
                    <div className="pt-2">
                      <span className="block text-slate-400 font-mono text-[11px] mb-2">
                        Live In-Browser Slide Deck Preview:
                      </span>
                      <PptxViewer
                        title={lessonForm.title || 'Slide Preview'}
                        pptxFileName={lessonForm.pptxFileName}
                        slides={lessonForm.pptxSlides}
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Video Lesson Settings & Preview */}
              {lessonForm.type === 'video' && (
                <div className="p-4 rounded-xl bg-slate-900/90 border border-cyan-500/30 space-y-3">
                  <div className="flex items-center gap-2 text-cyan-300 font-bold">
                    <Video className="w-4 h-4" />
                    <span>Video Stream & Subtitles Configuration</span>
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">
                      Video Stream URL (MP4 / WebM) *
                    </label>
                    <input
                      type="text"
                      value={lessonForm.videoUrl || ''}
                      onChange={(e) =>
                        setLessonForm({ ...lessonForm, videoUrl: e.target.value })
                      }
                      placeholder="https://example.com/lesson-video.mp4"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">
                      Subtitles / Captions URL (.vtt, optional)
                    </label>
                    <input
                      type="text"
                      value={lessonForm.subtitleUrl || ''}
                      onChange={(e) =>
                        setLessonForm({ ...lessonForm, subtitleUrl: e.target.value })
                      }
                      placeholder="https://example.com/captions.vtt"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                  {lessonForm.videoUrl && (
                    <div className="pt-2">
                      <span className="block text-slate-400 font-mono text-[11px] mb-2">
                        Video Player Preview:
                      </span>
                      <VideoLessonPlayer
                        lessonId={lessonForm.lessonId || 'preview'}
                        title={lessonForm.title || 'Video Preview'}
                        videoUrl={lessonForm.videoUrl}
                        subtitleUrl={lessonForm.subtitleUrl}
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Written Content / Additional Lesson Notes */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Section Heading
                </label>
                <input
                  type="text"
                  value={lessonForm.heading}
                  onChange={(e) => setLessonForm({ ...lessonForm, heading: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Lesson Paragraphs / Notes (separate by newline)
                </label>
                <textarea
                  rows={3}
                  value={lessonForm.paragraphsText}
                  onChange={(e) =>
                    setLessonForm({ ...lessonForm, paragraphsText: e.target.value })
                  }
                  placeholder="Paragraph 1...&#10;Paragraph 2..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <input
                  type="checkbox"
                  id="lessonPublished"
                  checked={lessonForm.published}
                  onChange={(e) =>
                    setLessonForm({ ...lessonForm, published: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-cyan-500"
                />
                <label
                  htmlFor="lessonPublished"
                  className="text-slate-300 font-medium cursor-pointer"
                >
                  Publish lesson immediately (keep unchecked for draft)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={courses.length === 0}
                  className="px-4 py-2 rounded-xl bg-cyan-500 font-bold text-slate-950 disabled:opacity-50"
                >
                  Save Lesson
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Create / Edit Multi-Question Quiz Modal */}
      {activeModal === 'quiz' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-4 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {quizForm.quizId ? 'Edit Multi-Question Quiz' : 'Create Multi-Question Quiz'}
              </h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveQuiz} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Quiz Title *</label>
                  <input
                    type="text"
                    required
                    value={quizForm.title}
                    onChange={(e) => setQuizForm({ ...quizForm, title: e.target.value })}
                    placeholder="e.g. Self-Custody & Keypair Mastery Quiz"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Assign to Course
                  </label>
                  <select
                    value={quizForm.courseSlug}
                    onChange={(e) => setQuizForm({ ...quizForm, courseSlug: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="">General / Unassigned</option>
                    {courses.map((c) => (
                      <option key={c.slug} value={c.slug}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Passing Score (%)
                  </label>
                  <input
                    type="number"
                    min={10}
                    max={100}
                    value={quizForm.passingScore}
                    onChange={(e) =>
                      setQuizForm({ ...quizForm, passingScore: Number(e.target.value) })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Custom Instructions (optional)
                  </label>
                  <input
                    type="text"
                    value={quizForm.instructions}
                    onChange={(e) =>
                      setQuizForm({ ...quizForm, instructions: e.target.value })
                    }
                    placeholder="Instructions shown before starting..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              {/* Multi-Question List */}
              <div className="space-y-4 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">
                    Questions ({quizForm.questions.length})
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setQuizForm((prev) => ({
                        ...prev,
                        questions: [
                          ...prev.questions,
                          {
                            id: `q${Date.now()}`,
                            question: '',
                            options: ['', '', '', ''],
                            correctIndex: 0,
                            explanation: '',
                          },
                        ],
                      }))
                    }
                    className="px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold cursor-pointer"
                  >
                    + Add Question
                  </button>
                </div>

                {quizForm.questions.map((q, qIdx) => (
                  <div
                    key={q.id || qIdx}
                    className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-amber-300 font-bold">
                        Question #{qIdx + 1}
                      </span>
                      <div className="flex items-center gap-2">
                        {quizForm.questions.length > 1 && (
                          <button
                            type="button"
                            onClick={() =>
                              setQuizForm((prev) => ({
                                ...prev,
                                questions: prev.questions.filter((_, i) => i !== qIdx),
                              }))
                            }
                            className="text-rose-400 hover:underline"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    </div>

                    <input
                      type="text"
                      required
                      value={q.question}
                      onChange={(e) => {
                        const updated = [...quizForm.questions];
                        updated[qIdx] = { ...updated[qIdx], question: e.target.value };
                        setQuizForm({ ...quizForm, questions: updated });
                      }}
                      placeholder="Question prompt..."
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {[0, 1, 2, 3].map((optIdx) => (
                        <input
                          key={optIdx}
                          type="text"
                          required={optIdx < 2}
                          value={q.options[optIdx] || ''}
                          onChange={(e) => {
                            const updated = [...quizForm.questions];
                            const nextOpts = [...updated[qIdx].options];
                            nextOpts[optIdx] = e.target.value;
                            updated[qIdx] = { ...updated[qIdx], options: nextOpts };
                            setQuizForm({ ...quizForm, questions: updated });
                          }}
                          placeholder={`Option ${optIdx + 1}${optIdx < 2 ? ' *' : ''}`}
                          className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                        />
                      ))}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div>
                        <label className="block text-slate-400 mb-1">Correct Option</label>
                        <select
                          value={q.correctIndex}
                          onChange={(e) => {
                            const updated = [...quizForm.questions];
                            updated[qIdx] = {
                              ...updated[qIdx],
                              correctIndex: Number(e.target.value),
                            };
                            setQuizForm({ ...quizForm, questions: updated });
                          }}
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                        >
                          <option value={0}>Option 1</option>
                          <option value={1}>Option 2</option>
                          <option value={2}>Option 3</option>
                          <option value={3}>Option 4</option>
                        </select>
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-slate-400 mb-1">
                          Answer Explanation
                        </label>
                        <input
                          type="text"
                          value={q.explanation}
                          onChange={(e) => {
                            const updated = [...quizForm.questions];
                            updated[qIdx] = {
                              ...updated[qIdx],
                              explanation: e.target.value,
                            };
                            setQuizForm({ ...quizForm, questions: updated });
                          }}
                          placeholder="Why this answer is right..."
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <input
                  type="checkbox"
                  id="quizPublished"
                  checked={quizForm.published}
                  onChange={(e) =>
                    setQuizForm({ ...quizForm, published: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-amber-500"
                />
                <label
                  htmlFor="quizPublished"
                  className="text-slate-300 font-medium cursor-pointer"
                >
                  Publish quiz immediately (keep unchecked for draft)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-400 font-bold text-slate-950"
                >
                  Save Quiz
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Add / Edit Multi-Card Flashcard Set Modal */}
      {activeModal === 'flashcard' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-4 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {flashcardForm.setId ? 'Edit Flashcard Deck' : 'Create Multi-Card Flashcard Deck'}
              </h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveFlashcards} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Deck Title *</label>
                  <input
                    type="text"
                    required
                    value={flashcardForm.title}
                    onChange={(e) =>
                      setFlashcardForm({ ...flashcardForm, title: e.target.value })
                    }
                    placeholder="e.g. DeFi & Automated Market Makers"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Assign to Course
                  </label>
                  <select
                    value={flashcardForm.courseSlug}
                    onChange={(e) =>
                      setFlashcardForm({ ...flashcardForm, courseSlug: e.target.value })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="">General / Unassigned</option>
                    {courses.map((c) => (
                      <option key={c.slug} value={c.slug}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-3 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">
                    Cards in Deck ({flashcardForm.cards.length})
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setFlashcardForm((prev) => ({
                        ...prev,
                        cards: [
                          ...prev.cards,
                          {
                            id: `c${Date.now()}`,
                            front: '',
                            back: '',
                            category: 'Foundations',
                          },
                        ],
                      }))
                    }
                    className="px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold cursor-pointer"
                  >
                    + Add Card
                  </button>
                </div>

                {flashcardForm.cards.map((card, cIdx) => (
                  <div
                    key={card.id || cIdx}
                    className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-amber-300 font-bold">
                        Card #{cIdx + 1}
                      </span>
                      {flashcardForm.cards.length > 1 && (
                        <button
                          type="button"
                          onClick={() =>
                            setFlashcardForm((prev) => ({
                              ...prev,
                              cards: prev.cards.filter((_, i) => i !== cIdx),
                            }))
                          }
                          className="text-rose-400 hover:underline"
                        >
                          Remove
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div className="sm:col-span-2">
                        <input
                          type="text"
                          required
                          value={card.front}
                          onChange={(e) => {
                            const updated = [...flashcardForm.cards];
                            updated[cIdx] = { ...updated[cIdx], front: e.target.value };
                            setFlashcardForm({ ...flashcardForm, cards: updated });
                          }}
                          placeholder="Front (Term / Question) *"
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                        />
                      </div>
                      <div>
                        <input
                          type="text"
                          value={card.category}
                          onChange={(e) => {
                            const updated = [...flashcardForm.cards];
                            updated[cIdx] = { ...updated[cIdx], category: e.target.value };
                            setFlashcardForm({ ...flashcardForm, cards: updated });
                          }}
                          placeholder="Category Tag"
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                        />
                      </div>
                    </div>

                    <textarea
                      rows={2}
                      required
                      value={card.back}
                      onChange={(e) => {
                        const updated = [...flashcardForm.cards];
                        updated[cIdx] = { ...updated[cIdx], back: e.target.value };
                        setFlashcardForm({ ...flashcardForm, cards: updated });
                      }}
                      placeholder="Back (Plain English Definition / Meaning) *"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <input
                  type="checkbox"
                  id="flashcardPublished"
                  checked={flashcardForm.published}
                  onChange={(e) =>
                    setFlashcardForm({ ...flashcardForm, published: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-amber-500"
                />
                <label
                  htmlFor="flashcardPublished"
                  className="text-slate-300 font-medium cursor-pointer"
                >
                  Publish deck immediately (keep unchecked for draft)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-400 font-bold text-slate-950"
                >
                  Save Flashcard Deck
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. Schedule Live Class Modal */}
      {activeModal === 'live-class' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-xl w-full p-6 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Schedule Live Class</h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLiveClass} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Class Title *</label>
                <input
                  type="text"
                  required
                  value={liveClassForm.title}
                  onChange={(e) =>
                    setLiveClassForm({ ...liveClassForm, title: e.target.value })
                  }
                  placeholder="e.g. Bitcoin Halving Dynamics & Macro Liquidity"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Instructor Name
                  </label>
                  <input
                    type="text"
                    required
                    value={liveClassForm.instructor}
                    onChange={(e) =>
                      setLiveClassForm({ ...liveClassForm, instructor: e.target.value })
                    }
                    placeholder="Instructor Name"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Instructor Role
                  </label>
                  <input
                    type="text"
                    value={liveClassForm.instructorRole}
                    onChange={(e) =>
                      setLiveClassForm({
                        ...liveClassForm,
                        instructorRole: e.target.value,
                      })
                    }
                    placeholder="e.g. Head Researcher"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Date String</label>
                  <input
                    type="text"
                    value={liveClassForm.date}
                    onChange={(e) =>
                      setLiveClassForm({ ...liveClassForm, date: e.target.value })
                    }
                    placeholder="e.g. Saturday, Nov 14, 2026"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Time String</label>
                  <input
                    type="text"
                    value={liveClassForm.time}
                    onChange={(e) =>
                      setLiveClassForm({ ...liveClassForm, time: e.target.value })
                    }
                    placeholder="e.g. 6:00 PM - 7:30 PM IST"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Meeting Room URL
                </label>
                <input
                  type="text"
                  required
                  value={liveClassForm.meetingUrl}
                  onChange={(e) =>
                    setLiveClassForm({ ...liveClassForm, meetingUrl: e.target.value })
                  }
                  placeholder="https://meet.google.com/..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Agenda Items (one per line)
                </label>
                <textarea
                  rows={2}
                  value={liveClassForm.agendaText}
                  onChange={(e) =>
                    setLiveClassForm({ ...liveClassForm, agendaText: e.target.value })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <input
                  type="checkbox"
                  id="liveClassPublished"
                  checked={liveClassForm.published}
                  onChange={(e) =>
                    setLiveClassForm({ ...liveClassForm, published: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-emerald-500"
                />
                <label
                  htmlFor="liveClassPublished"
                  className="text-slate-300 font-medium cursor-pointer"
                >
                  Publish class immediately (keep unchecked for draft)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-500 font-bold text-slate-950"
                >
                  Save Live Class
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. Add / Edit Dictionary Term Modal */}
      {activeModal === 'glossary' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-xl w-full p-6 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Add / Edit Dictionary Term</h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveGlossary} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Term *</label>
                  <input
                    type="text"
                    required
                    value={glossaryForm.term}
                    onChange={(e) =>
                      setGlossaryForm({ ...glossaryForm, term: e.target.value })
                    }
                    placeholder="e.g. Proof of Stake"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Category</label>
                  <select
                    value={glossaryForm.category}
                    onChange={(e) =>
                      setGlossaryForm({ ...glossaryForm, category: e.target.value as any })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Blockchain">Blockchain</option>
                    <option value="DeFi">DeFi</option>
                    <option value="Security">Security</option>
                    <option value="Trading">Trading</option>
                    <option value="Macroeconomics">Macroeconomics</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Short Definition
                </label>
                <input
                  type="text"
                  required
                  value={glossaryForm.shortDef}
                  onChange={(e) =>
                    setGlossaryForm({ ...glossaryForm, shortDef: e.target.value })
                  }
                  placeholder="One sentence plain English explanation..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Full Technical Definition
                </label>
                <textarea
                  rows={2}
                  value={glossaryForm.fullDef}
                  onChange={(e) =>
                    setGlossaryForm({ ...glossaryForm, fullDef: e.target.value })
                  }
                  placeholder="Comprehensive technical details..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Everyday Example
                </label>
                <input
                  type="text"
                  value={glossaryForm.realWorldAnalogy}
                  onChange={(e) =>
                    setGlossaryForm({
                      ...glossaryForm,
                      realWorldAnalogy: e.target.value,
                    })
                  }
                  placeholder="e.g. Like a digital locker where only you have the secret key..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Common Mistake to Avoid
                </label>
                <input
                  type="text"
                  value={glossaryForm.beginnerPitfall}
                  onChange={(e) =>
                    setGlossaryForm({
                      ...glossaryForm,
                      beginnerPitfall: e.target.value,
                    })
                  }
                  placeholder="Assuming high APY implies zero risk..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <input
                  type="checkbox"
                  id="glossaryPublished"
                  checked={Boolean(glossaryForm.published)}
                  onChange={(e) =>
                    setGlossaryForm({ ...glossaryForm, published: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-blue-500"
                />
                <label
                  htmlFor="glossaryPublished"
                  className="text-slate-300 font-medium cursor-pointer"
                >
                  Publish term immediately (keep unchecked for draft)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-500 font-bold text-slate-950 cursor-pointer"
                >
                  Save Dictionary Term
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. Create / Edit Notification Modal */}
      {activeModal === 'notification' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-xl w-full p-6 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {notificationForm.id ? 'Edit Notification' : 'Create Student Notification'}
              </h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNotification} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Notification Title *
                </label>
                <input
                  type="text"
                  required
                  value={notificationForm.title}
                  onChange={(e) =>
                    setNotificationForm({ ...notificationForm, title: e.target.value })
                  }
                  placeholder="e.g. New Course Published: Crypto Security Fundamentals"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Message *
                </label>
                <textarea
                  rows={3}
                  required
                  value={notificationForm.message}
                  onChange={(e) =>
                    setNotificationForm({ ...notificationForm, message: e.target.value })
                  }
                  placeholder="Write a clear announcement for students..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Target Link Path (optional)
                  </label>
                  <input
                    type="text"
                    value={notificationForm.linkPath}
                    onChange={(e) =>
                      setNotificationForm({
                        ...notificationForm,
                        linkPath: e.target.value,
                      })
                    }
                    placeholder="e.g. /my-courses or /my-live-classes"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Expiration Date (optional)
                  </label>
                  <input
                    type="date"
                    value={notificationForm.expiresAt}
                    onChange={(e) =>
                      setNotificationForm({
                        ...notificationForm,
                        expiresAt: e.target.value,
                      })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <input
                  type="checkbox"
                  id="notifPublished"
                  checked={notificationForm.published}
                  onChange={(e) =>
                    setNotificationForm({
                      ...notificationForm,
                      published: e.target.checked,
                    })
                  }
                  className="w-4 h-4 rounded text-emerald-500"
                />
                <label
                  htmlFor="notifPublished"
                  className="text-slate-300 font-medium cursor-pointer"
                >
                  Publish notification immediately
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-400 font-bold text-slate-950 cursor-pointer"
                >
                  Save Notification
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Destructive Action Confirmation Dialog Modal */}
      {confirmAction && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="confirm-dialog-title"
        >
          <div className="bg-[#0b1329] border border-rose-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 animate-modal-in shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-950 border border-rose-800 flex items-center justify-center text-rose-400 shrink-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <h3 id="confirm-dialog-title" className="text-base font-bold text-white">
                {confirmAction.title}
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{confirmAction.message}</p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmAction(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  confirmAction.onConfirm();
                  setConfirmAction(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 text-xs font-bold cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
