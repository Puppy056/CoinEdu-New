import React, { useState, useEffect } from 'react';
import { useAuth, QuizAttemptRecord } from '../../context/AuthContext';
import {
  useContentStore,
  LessonItem,
  CourseDetail,
  calculateCourseProgress,
  QuizData,
  FlashcardSet,
} from '../../data/learningPlatform';
import { PptxViewer } from '../../components/PptxViewer';
import { VideoLessonPlayer } from '../../components/VideoLessonPlayer';
import {
  BookOpen,
  CheckCircle2,
  RotateCcw,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  Award,
  Layers,
  Calendar,
  Settings,
  FileText,
  Video,
  Presentation,
  Clock,
  LogOut,
  AlertTriangle,
  History,
  Trash2,
  KeyRound,
  Check,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

interface StudentPageProps {
  navigate: (to: string) => void;
}

// 1. Student Dashboard (/dashboard) -> "DASHBOARD"
export const StudentDashboardPage: React.FC<StudentPageProps> = ({ navigate }) => {
  const {
    user,
    completedLessons,
    startedLessons,
    lastVisitedLessonId,
    quizAttempts,
  } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, quizzes, flashcards, liveClasses } = useContentStore(isAdmin);

  const enrolled = courses.filter((c) => user?.enrolledCourses?.includes(c.slug));

  // Accurate progress calculation across enrolled courses (or all published courses if none enrolled yet)
  const relevantCourses = enrolled.length > 0 ? enrolled : courses;
  const totalLessons = relevantCourses.reduce((acc, c) => acc + c.lessons.length, 0);
  const validLessonIds = new Set(
    relevantCourses.flatMap((c) => c.lessons.map((l) => l.lessonId))
  );
  const completedCount = completedLessons.filter((id) => validLessonIds.has(id)).length;
  const progressPercent =
    totalLessons > 0 ? Math.min(100, Math.round((completedCount / totalLessons) * 100)) : 0;

  const upcomingLiveClasses = liveClasses.filter((cls) => cls.status === 'upcoming');
  const nextLiveClass = upcomingLiveClasses[0] || liveClasses[0];

  // Find last visited lesson details if available
  let lastVisitedLesson: LessonItem | undefined;
  let lastVisitedCourse: CourseDetail | undefined;
  if (lastVisitedLessonId) {
    for (const c of courses) {
      const found = c.lessons.find((l) => l.lessonId === lastVisitedLessonId);
      if (found) {
        lastVisitedLesson = found;
        lastVisitedCourse = c;
        break;
      }
    }
  }

  const recentAttempts = Object.values(quizAttempts)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 3);

  return (
    <div className="py-6 sm:py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      {/* Compact, Mobile-Friendly Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 bg-[#0b1329] border border-slate-800 rounded-2xl p-5 sm:p-6">
        <div>
          <span className="text-[11px] font-mono text-cyan-400 uppercase tracking-widest font-bold">
            DASHBOARD
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">
            Welcome back, {user?.name || 'Student'}
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Track your enrolled courses, lessons, flashcards, quizzes, and live sessions.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => navigate('/history')}
            className="btn-interactive px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer flex items-center gap-1.5"
          >
            <History className="w-3.5 h-3.5 text-cyan-400" />
            <span>Learning History</span>
          </button>
          <button
            onClick={() => navigate('/dictionary')}
            className="btn-interactive px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
          >
            Dictionary
          </button>
          <button
            onClick={() => navigate('/settings')}
            className="btn-interactive p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 cursor-pointer"
            title="Account Settings"
            aria-label="Account Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Prominent Quick Actions Grid (4 Primary Student Actions) */}
      <div className="mb-8">
        <h2 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold mb-3">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <button
            onClick={() => navigate('/my-courses')}
            className="card-interactive text-left p-4 sm:p-5 rounded-2xl bg-[#0b1329] border border-slate-800 hover:border-cyan-500/50 flex flex-col justify-between group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-950/80 border border-cyan-800/60 text-cyan-400 flex items-center justify-center mb-3">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm sm:text-base font-bold text-white group-hover:text-cyan-300 transition-colors block">
                My Courses
              </span>
              <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                {enrolled.length} Enrolled
              </span>
            </div>
          </button>

          <button
            onClick={() => navigate('/flashcards')}
            className="card-interactive text-left p-4 sm:p-5 rounded-2xl bg-[#0b1329] border border-slate-800 hover:border-amber-500/50 flex flex-col justify-between group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-950/80 border border-amber-800/60 text-amber-400 flex items-center justify-center mb-3">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm sm:text-base font-bold text-white group-hover:text-amber-300 transition-colors block">
                My Flashcards
              </span>
              <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                {Object.keys(flashcards).length} Study Sets
              </span>
            </div>
          </button>

          <button
            onClick={() => navigate('/my-quizzes')}
            className="card-interactive text-left p-4 sm:p-5 rounded-2xl bg-[#0b1329] border border-slate-800 hover:border-purple-500/50 flex flex-col justify-between group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-950/80 border border-purple-800/60 text-purple-400 flex items-center justify-center mb-3">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm sm:text-base font-bold text-white group-hover:text-purple-300 transition-colors block">
                My Quizzes
              </span>
              <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                {Object.keys(quizzes).length} Available
              </span>
            </div>
          </button>

          <button
            onClick={() => navigate('/my-live-classes')}
            className="card-interactive text-left p-4 sm:p-5 rounded-2xl bg-[#0b1329] border border-slate-800 hover:border-emerald-500/50 flex flex-col justify-between group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-800/60 text-emerald-400 flex items-center justify-center mb-3">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm sm:text-base font-bold text-white group-hover:text-emerald-300 transition-colors block">
                My Live Classes
              </span>
              <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                {upcomingLiveClasses.length} Upcoming
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* Last Visited Lesson / Quick Resume Banner */}
      {lastVisitedLesson && lastVisitedCourse && (
        <div className="mb-8 p-5 rounded-2xl bg-gradient-to-r from-cyan-950/60 to-slate-900 border border-cyan-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider font-semibold block">
              Last Lesson Visited · {lastVisitedCourse.title}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-white mt-0.5">
              {lastVisitedLesson.title}
            </h2>
            <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
              {lastVisitedLesson.summary}
            </p>
          </div>
          <button
            onClick={() => navigate(`/learn/${lastVisitedLesson!.lessonId}`)}
            className="btn-interactive inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shrink-0 cursor-pointer"
          >
            <span>Resume Lesson</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Progress Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-10">
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5">
          <span className="text-xs text-slate-400 block mb-1">Overall Lesson Progress</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-mono">{progressPercent}%</span>
            <span className="text-xs text-cyan-400 font-mono">
              ({completedCount}/{totalLessons} lessons)
            </span>
          </div>
          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden mt-3">
            <div
              style={{ width: `${progressPercent}%` }}
              className="h-full bg-cyan-400 transition-[width] duration-500 ease-out"
            />
          </div>
        </div>

        <div
          onClick={() => navigate('/my-courses')}
          className="card-interactive bg-[#0b1329] border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-5 cursor-pointer"
        >
          <span className="text-xs text-slate-400 block mb-1">Enrolled Courses</span>
          <div className="text-3xl font-extrabold text-cyan-400 font-mono">{enrolled.length}</div>
          <p className="text-xs text-slate-400 mt-2">
            {enrolled.length === 0 ? 'Browse courses to start' : 'Click to open your courses'}
          </p>
        </div>

        <div
          onClick={() => navigate('/my-live-classes')}
          className="card-interactive bg-[#0b1329] border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-5 cursor-pointer"
        >
          <span className="text-xs text-slate-400 block mb-1">Next Live Class</span>
          {nextLiveClass ? (
            <>
              <div className="text-sm font-bold text-amber-300 mt-1 line-clamp-1">
                {nextLiveClass.title}
              </div>
              <p className="text-xs text-slate-400 mt-2">
                {nextLiveClass.date} ({nextLiveClass.time})
              </p>
            </>
          ) : (
            <>
              <div className="text-sm font-semibold text-slate-400 mt-1">
                No live classes scheduled yet.
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Check back soon for new schedules.
              </p>
            </>
          )}
        </div>
      </div>

      {/* Continue Learning & Recent Activity Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">Continue Learning</h2>
            <button
              onClick={() => navigate('/courses')}
              className="text-xs font-semibold text-cyan-400 hover:underline cursor-pointer"
            >
              Recommended Courses
            </button>
          </div>

          {enrolled.length === 0 ? (
            <div className="p-8 text-center bg-[#0b1329] border border-slate-800 rounded-2xl">
              <BookOpen className="w-10 h-10 text-slate-500 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white mb-1">No enrolled courses yet.</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
                You have not enrolled in any courses yet. Explore our recommended courses to start your learning path.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <button
                  onClick={() => navigate('/courses')}
                  className="btn-interactive px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Explore Recommended Courses
                </button>
                <button
                  onClick={() => navigate('/dictionary')}
                  className="btn-interactive px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Open Dictionary
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {enrolled.map((course) => {
                const prog = calculateCourseProgress(course, completedLessons);

                const nextLesson =
                  course.lessons.find((l) => !completedLessons.includes(l.lessonId)) ||
                  course.lessons[0];

                return (
                  <div
                    key={course.slug}
                    className="card-interactive bg-[#0b1329] border border-slate-800 rounded-2xl p-6 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2 text-xs font-mono">
                        <span className="text-cyan-400 font-semibold uppercase">{course.level}</span>
                        <span className="text-cyan-400 font-bold">
                          {prog.totalPublishedLessons === 0
                            ? 'No lessons yet'
                            : `${prog.percentage}% Completed`}
                        </span>
                      </div>

                      <h3 className="text-lg font-bold text-white mb-2">{course.title}</h3>
                      <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                        {course.description}
                      </p>

                      <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden mb-4">
                        <div
                          style={{ width: `${prog.percentage}%` }}
                          className="h-full bg-cyan-400 transition-[width] duration-500 ease-out"
                        />
                      </div>
                    </div>

                    <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                      <span className="text-xs text-slate-400">
                        {prog.totalPublishedLessons === 0
                          ? '0 lessons published'
                          : `${prog.completedLessonsCount} of ${prog.totalPublishedLessons} lessons done`}
                      </span>
                      {nextLesson ? (
                        <button
                          onClick={() => navigate(`/learn/${nextLesson.lessonId}`)}
                          className="btn-interactive flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
                        >
                          <span>
                            {prog.completedLessonsCount === 0
                              ? 'Start'
                              : prog.isCompleted
                              ? 'Review'
                              : 'Continue'}
                          </span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <button
                          onClick={() => navigate(`/courses/${course.slug}`)}
                          className="text-xs text-cyan-400 hover:underline cursor-pointer"
                        >
                          Open Course
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Recent Activity & Study Options */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-white">Recent Quiz Results</h2>
              <button
                onClick={() => navigate('/history')}
                className="text-xs text-cyan-400 hover:underline cursor-pointer"
              >
                Full History
              </button>
            </div>

            {recentAttempts.length === 0 ? (
              <p className="text-xs text-slate-400">
                You have not taken any quizzes yet. Open My Quizzes or complete a lesson to test your knowledge.
              </p>
            ) : (
              <div className="space-y-3">
                {recentAttempts.map((att) => {
                  const quizTitle = quizzes[att.quizId]?.title || att.quizId;
                  return (
                    <div
                      key={att.attemptId}
                      onClick={() => navigate(`/quiz/${att.quizId}/results/${att.attemptId}`)}
                      className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-between cursor-pointer text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block">{quizTitle}</span>
                        <span className="text-[11px] text-slate-400">
                          {new Date(att.timestamp).toLocaleDateString('en-IN')}
                        </span>
                      </div>
                      <span
                        className={`font-mono font-bold ${
                          att.passed ? 'text-emerald-400' : 'text-amber-400'
                        }`}
                      >
                        {att.score}%
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 space-y-3">
            <h2 className="text-base font-bold text-white">Student Resources</h2>
            <button
              onClick={() => navigate('/dictionary')}
              className="btn-interactive w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-between text-xs text-slate-200 cursor-pointer"
            >
              <span>Crypto & Blockchain Dictionary</span>
              <ChevronRight className="w-4 h-4 text-amber-400" />
            </button>
            <button
              onClick={() => navigate('/history')}
              className="btn-interactive w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-between text-xs text-slate-200 cursor-pointer"
            >
              <span>Learning History & Quiz Review</span>
              <ChevronRight className="w-4 h-4 text-cyan-400" />
            </button>
            <button
              onClick={() => navigate('/faq')}
              className="btn-interactive w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-between text-xs text-slate-200 cursor-pointer"
            >
              <span>Beginner FAQ & Safety Guide</span>
              <ChevronRight className="w-4 h-4 text-emerald-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// 2. Student Courses Page (/my-courses) with Course Workspace (Lessons, Quizzes, Flashcards)
export const MyCoursesPage: React.FC<StudentPageProps> = ({ navigate }) => {
  const { user, completedLessons, enrollInCourse } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, quizzes, flashcards } = useContentStore(isAdmin);

  const enrolled = courses.filter((c) => user?.enrolledCourses?.includes(c.slug));
  const availableToEnroll = courses.filter((c) => !user?.enrolledCourses?.includes(c.slug));

  const [selectedCourseSlug, setSelectedCourseSlug] = useState<string | null>(null);
  const [activeCourseTab, setActiveCourseTab] = useState<'lessons' | 'quizzes' | 'flashcards'>('lessons');

  const activeCourse =
    courses.find((c) => c.slug === selectedCourseSlug) ||
    (enrolled.length > 0 ? enrolled[0] : null);

  const courseQuizzes: QuizData[] = activeCourse
    ? Object.values(quizzes).filter(
        (q) =>
          q.courseSlug === activeCourse.slug ||
          activeCourse.lessons.some((l) => l.quizId === q.quizId)
      )
    : [];

  const courseFlashcards: FlashcardSet[] = activeCourse
    ? Object.values(flashcards).filter(
        (f) =>
          f.courseSlug === activeCourse.slug ||
          activeCourse.lessons.some((l) => l.flashcardSetId === f.setId)
      )
    : [];

  return (
    <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">
            Student Learning Workspace
          </span>
          <h1 className="text-3xl font-extrabold text-white mt-1">My Courses</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2">
            Access your enrolled courses, lessons, course-specific quizzes, and flashcard decks.
          </p>
        </div>
        <button
          onClick={() => navigate('/courses')}
          className="btn-interactive inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
        >
          <span>Recommended Courses</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {enrolled.length === 0 ? (
        <div className="space-y-8">
          <div className="text-center py-16 bg-[#0b1329] rounded-2xl border border-slate-800 p-8 max-w-2xl mx-auto">
            <BookOpen className="w-12 h-12 text-slate-500 mx-auto mb-3" />
            <h2 className="text-xl font-bold text-white mb-2">No courses enrolled yet.</h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-6">
              Enrol in a published course below or browse the Recommended Courses catalogue to begin.
            </p>
            <button
              onClick={() => navigate('/courses')}
              className="btn-interactive px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-xl text-xs font-bold cursor-pointer"
            >
              Browse Recommended Courses
            </button>
          </div>

          {availableToEnroll.length > 0 && (
            <div>
              <h2 className="text-lg font-bold text-white mb-4">Available Courses to Enrol</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {availableToEnroll.map((course) => (
                  <div
                    key={course.slug}
                    className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 flex flex-col justify-between"
                  >
                    <div>
                      <span className="text-xs font-mono text-cyan-400 uppercase font-semibold">
                        {course.level} · {course.lessons.length} Lessons
                      </span>
                      <h3 className="text-lg font-bold text-white mt-1 mb-2">{course.title}</h3>
                      <p className="text-xs text-slate-400 line-clamp-2 mb-4">{course.description}</p>
                    </div>
                    <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-2">
                      <button
                        onClick={() => navigate(`/courses/${course.slug}`)}
                        className="text-xs text-slate-300 hover:text-white cursor-pointer"
                      >
                        View Details
                      </button>
                      <button
                        onClick={() => {
                          enrollInCourse(course.slug);
                          setSelectedCourseSlug(course.slug);
                        }}
                        className="btn-interactive px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold cursor-pointer"
                      >
                        Enrol in Course
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-8">
          {/* Enrolled Course Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {enrolled.map((course) => {
              const prog = calculateCourseProgress(course, completedLessons);
              const isSelected = activeCourse?.slug === course.slug;

              return (
                <div
                  key={course.slug}
                  onClick={() => setSelectedCourseSlug(course.slug)}
                  className={`card-interactive bg-[#0b1329] border rounded-2xl p-6 cursor-pointer flex flex-col justify-between transition-all ${
                    isSelected
                      ? 'border-cyan-400 ring-1 ring-cyan-400/30'
                      : 'border-slate-800 hover:border-cyan-500/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3 text-xs font-mono">
                      <span className="text-cyan-400 font-semibold uppercase">{course.level}</span>
                      <span className="text-cyan-400 font-bold">
                        {prog.totalPublishedLessons === 0 ? '0 lessons' : `${prog.percentage}% Done`}
                      </span>
                    </div>

                    <h2 className="text-lg font-bold text-white mb-2">{course.title}</h2>
                    <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                      {course.description}
                    </p>

                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden mb-4">
                      <div
                        style={{ width: `${prog.percentage}%` }}
                        className="h-full bg-cyan-400 transition-[width] duration-500 ease-out"
                      />
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                    <span>
                      {prog.totalPublishedLessons === 0
                        ? 'No lessons published yet'
                        : `${prog.completedLessonsCount} of ${prog.totalPublishedLessons} lessons done`}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/courses/${course.slug}`);
                      }}
                      className="text-cyan-400 font-semibold hover:underline flex items-center cursor-pointer"
                    >
                      Syllabus <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Course Workspace: Lessons, Quizzes, Flashcards */}
          {activeCourse && (
            <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800 mb-6">
                <div>
                  <span className="text-xs font-mono text-cyan-400 uppercase font-semibold">
                    Active Course Content
                  </span>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">
                    {activeCourse.title}
                  </h2>
                </div>

                {/* Course Content Tabs */}
                <div className="flex flex-wrap gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
                  <button
                    onClick={() => setActiveCourseTab('lessons')}
                    className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      activeCourseTab === 'lessons'
                        ? 'bg-cyan-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Lessons ({activeCourse.lessons.length})
                  </button>
                  <button
                    onClick={() => setActiveCourseTab('quizzes')}
                    className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      activeCourseTab === 'quizzes'
                        ? 'bg-cyan-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Quizzes ({courseQuizzes.length})
                  </button>
                  <button
                    onClick={() => setActiveCourseTab('flashcards')}
                    className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      activeCourseTab === 'flashcards'
                        ? 'bg-cyan-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Flashcards ({courseFlashcards.length})
                  </button>
                </div>
              </div>

              {/* Tab 1: Course Lessons */}
              {activeCourseTab === 'lessons' && (
                <div>
                  {activeCourse.lessons.length === 0 ? (
                    <p className="text-xs text-slate-400 py-8 text-center">
                      No lessons have been published for this course yet.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {activeCourse.lessons.map((lesson, idx) => {
                        const isDone = completedLessons.includes(lesson.lessonId);
                        return (
                          <div
                            key={lesson.lessonId}
                            className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                          >
                            <div className="flex items-start gap-3">
                              <span className="w-7 h-7 rounded-lg bg-slate-800 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                                {idx + 1}
                              </span>
                              <div>
                                <div className="flex flex-wrap items-center gap-2">
                                  <h3 className="text-sm font-bold text-white">{lesson.title}</h3>
                                  <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono uppercase text-slate-300">
                                    {lesson.type === 'pptx'
                                      ? 'Slides (PPTX)'
                                      : lesson.type === 'video'
                                      ? 'Video'
                                      : 'Written'}
                                  </span>
                                  {isDone && (
                                    <span className="text-[11px] font-mono text-emerald-400 font-bold">
                                      ✓ Completed
                                    </span>
                                  )}
                                </div>
                                {lesson.summary && (
                                  <p className="text-xs text-slate-400 mt-1">{lesson.summary}</p>
                                )}
                              </div>
                            </div>
                            <button
                              onClick={() => navigate(`/learn/${lesson.lessonId}`)}
                              className="btn-interactive px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shrink-0 cursor-pointer"
                            >
                              {isDone ? 'Review Lesson' : 'Open Lesson'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Tab 2: Course Quizzes */}
              {activeCourseTab === 'quizzes' && (
                <div>
                  {courseQuizzes.length === 0 ? (
                    <p className="text-xs text-slate-400 py-8 text-center">
                      No quizzes are linked to this course yet.
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {courseQuizzes.map((q) => (
                        <div
                          key={q.quizId}
                          className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4"
                        >
                          <div>
                            <h3 className="text-sm font-bold text-white">{q.title}</h3>
                            <span className="text-xs font-mono text-slate-400 block mt-1">
                              {q.questions.length} Questions · Pass Score: {q.passingScore}%
                            </span>
                          </div>
                          <button
                            onClick={() => navigate(`/quiz/${q.quizId}`)}
                            className="btn-interactive px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold shrink-0 cursor-pointer"
                          >
                            Start Quiz
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Tab 3: Course Flashcards */}
              {activeCourseTab === 'flashcards' && (
                <div>
                  {courseFlashcards.length === 0 ? (
                    <p className="text-xs text-slate-400 py-8 text-center">
                      No flashcard sets are linked to this course yet.
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {courseFlashcards.map((fc) => (
                        <div
                          key={fc.setId}
                          className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4"
                        >
                          <div>
                            <h3 className="text-sm font-bold text-white">{fc.title}</h3>
                            <span className="text-xs font-mono text-slate-400 block mt-1">
                              {fc.cards.length} Revision Cards
                            </span>
                          </div>
                          <button
                            onClick={() => navigate(`/flashcards/${fc.setId}`)}
                            className="btn-interactive px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shrink-0 cursor-pointer"
                          >
                            Study Cards
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export const StudentCoursesPage = MyCoursesPage;

// 2b. Student Quizzes Page (/my-quizzes)
export const MyQuizzesPage: React.FC<StudentPageProps> = ({ navigate }) => {
  const { user, quizAttempts } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, quizzes } = useContentStore(isAdmin);

  const quizList = Object.values(quizzes);
  const attemptsByQuizId: Record<string, QuizAttemptRecord[]> = {};
  Object.values(quizAttempts).forEach((att) => {
    if (!attemptsByQuizId[att.quizId]) attemptsByQuizId[att.quizId] = [];
    attemptsByQuizId[att.quizId].push(att);
  });

  return (
    <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-mono text-purple-400 uppercase tracking-wider font-semibold">
            Formative Knowledge Checks
          </span>
          <h1 className="text-3xl font-extrabold text-white mt-1">My Quizzes</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2">
            Practice quizzes grouped by course to test your understanding and review detailed explanations.
          </p>
        </div>
        <button
          onClick={() => navigate('/history')}
          className="btn-interactive inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
        >
          <History className="w-3.5 h-3.5 text-cyan-400" />
          <span>View Attempt History</span>
        </button>
      </div>

      {quizList.length === 0 ? (
        <div className="text-center py-20 bg-[#0b1329] rounded-2xl border border-slate-800 p-8 max-w-2xl mx-auto">
          <HelpCircle className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-white mb-2">No quizzes available yet.</h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
            Quizzes published for your courses will appear here automatically.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizList.map((q) => {
            const parentCourse = courses.find((c) => c.slug === q.courseSlug);
            const pastAttempts = attemptsByQuizId[q.quizId] || [];
            const latestAttempt = pastAttempts.sort(
              (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
            )[0];

            return (
              <div
                key={q.quizId}
                className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[11px] font-mono text-cyan-400 uppercase font-semibold truncate">
                      {parentCourse ? parentCourse.title : q.courseSlug || 'General Quiz'}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 ${
                        latestAttempt
                          ? latestAttempt.passed
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {latestAttempt
                        ? `Last Score: ${latestAttempt.score}%`
                        : 'Not Attempted'}
                    </span>
                  </div>

                  <h2 className="text-lg font-bold text-white mb-2">{q.title}</h2>
                  <p className="text-xs text-slate-400 font-mono mb-4">
                    {q.questions.length} Questions · Passing Score: {q.passingScore}%
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-2">
                  {latestAttempt ? (
                    <button
                      onClick={() =>
                        navigate(`/quiz/${q.quizId}/results/${latestAttempt.attemptId}`)
                      }
                      className="text-xs text-amber-300 hover:underline font-semibold cursor-pointer"
                    >
                      Review Answers
                    </button>
                  ) : (
                    <span className="text-xs text-slate-500">Practice Mode</span>
                  )}

                  <button
                    onClick={() => navigate(`/quiz/${q.quizId}`)}
                    className="btn-interactive px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold cursor-pointer"
                  >
                    {latestAttempt ? 'Retake Quiz' : 'Start Quiz'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// 2c. Student Live Classes Page (/my-live-classes)
export const MyLiveClassesPage: React.FC<StudentPageProps> = ({ navigate }) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, liveClasses } = useContentStore(isAdmin);

  return (
    <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-mono text-emerald-400 uppercase tracking-wider font-semibold">
            Interactive Group Sessions
          </span>
          <h1 className="text-3xl font-extrabold text-white mt-1">My Live Classes</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2">
            Scheduled live sessions, agendas, and direct join links for CoinEdu students.
          </p>
        </div>
        <button
          onClick={() => navigate('/dashboard')}
          className="btn-interactive inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>
      </div>

      {liveClasses.length === 0 ? (
        <div className="text-center py-20 bg-[#0b1329] rounded-2xl border border-slate-800 p-8 max-w-2xl mx-auto">
          <Calendar className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-white mb-2">No live classes scheduled yet.</h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
            When instructors schedule upcoming live sessions, your join links and session agendas will appear here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {liveClasses.map((cls) => {
            const linkedCourse = courses.find((c) => c.slug === cls.courseSlug);
            return (
              <div
                key={cls.id}
                className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-2.5 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800/50 text-[11px] font-mono">
                      {cls.level}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-mono uppercase font-bold ${
                        cls.status === 'upcoming'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {cls.status}
                    </span>
                  </div>

                  <h2 className="text-xl font-bold text-white mb-1">{cls.title}</h2>
                  {linkedCourse && (
                    <span className="text-xs font-mono text-cyan-400 block mb-2">
                      Course: {linkedCourse.title}
                    </span>
                  )}
                  <p className="text-xs text-slate-300 mb-3">
                    Instructor: <strong>{cls.instructor}</strong> ({cls.instructorRole})
                  </p>

                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1 mb-4 font-mono">
                    <div>Date: {cls.date}</div>
                    <div>
                      Time: {cls.time} ({cls.durationMinutes} mins)
                    </div>
                  </div>

                  {cls.agenda && cls.agenda.length > 0 && (
                    <div className="mb-4">
                      <span className="text-xs font-bold text-slate-300 block mb-1.5">
                        Session Agenda:
                      </span>
                      <ul className="space-y-1 text-xs text-slate-400 list-disc list-inside">
                        {cls.agenda.map((item, i) => (
                          <li key={i}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-mono">
                    {cls.status === 'upcoming' ? 'Live Join Link Ready' : 'Session Completed'}
                  </span>
                  {cls.meetingUrl && (
                    <a
                      href={cls.meetingUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="btn-interactive inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold"
                    >
                      <span>Join Live Session</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// 2d. Learning History Page (/history) with Courses Completed, Lessons Started/Completed, and Expandable Quiz Review
export const LearningHistoryPage: React.FC<StudentPageProps> = ({ navigate }) => {
  const { user, completedLessons, startedLessons, quizAttempts } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, quizzes } = useContentStore(isAdmin);
  const [expandedAttemptId, setExpandedAttemptId] = useState<string | null>(null);

  // Courses completed: courses with >0 lessons where all lessons are completed
  const completedCourses = courses.filter((c) => {
    const prog = calculateCourseProgress(c, completedLessons);
    return prog.isCompleted;
  });

  const completedLessonDetails: Array<{ lesson: LessonItem; courseTitle: string }> = [];
  const startedLessonDetails: Array<{ lesson: LessonItem; courseTitle: string }> = [];

  for (const c of courses) {
    for (const l of c.lessons) {
      if (completedLessons.includes(l.lessonId)) {
        completedLessonDetails.push({ lesson: l, courseTitle: c.title });
      } else if (startedLessons.includes(l.lessonId)) {
        startedLessonDetails.push({ lesson: l, courseTitle: c.title });
      }
    }
  }

  const attemptsList = Object.values(quizAttempts).sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return (
    <div className="py-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold">
            Progress Record
          </span>
          <h1 className="text-3xl font-extrabold text-white mt-1">Learning History</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2">
            Your completed courses, started and completed lessons, and full quiz question reviews.
          </p>
        </div>
        <button
          onClick={() => navigate('/dashboard')}
          className="btn-interactive inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>
      </div>

      {/* Summary Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
          <span className="text-xs text-slate-400 block">Courses Completed</span>
          <span className="text-2xl font-extrabold text-emerald-400 font-mono mt-1 block">
            {completedCourses.length}
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
          <span className="text-xs text-slate-400 block">Lessons Completed</span>
          <span className="text-2xl font-extrabold text-cyan-400 font-mono mt-1 block">
            {completedLessonDetails.length}
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
          <span className="text-xs text-slate-400 block">Lessons In Progress</span>
          <span className="text-2xl font-extrabold text-amber-300 font-mono mt-1 block">
            {startedLessonDetails.length}
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-[#0b1329] border border-slate-800">
          <span className="text-xs text-slate-400 block">Quiz Attempts</span>
          <span className="text-2xl font-extrabold text-purple-400 font-mono mt-1 block">
            {attemptsList.length}
          </span>
        </div>
      </div>

      {/* Completed Courses Section */}
      {completedCourses.length > 0 && (
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 mb-8">
          <h2 className="text-lg font-bold text-white mb-4">
            Completed Courses ({completedCourses.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {completedCourses.map((c) => (
              <div
                key={c.slug}
                className="p-4 rounded-xl bg-slate-900 border border-emerald-800/40 flex items-center justify-between gap-3"
              >
                <div>
                  <span className="text-[11px] font-mono text-emerald-400 font-bold">
                    ✓ 100% Completed · {c.lessons.length} Lessons
                  </span>
                  <h3 className="text-sm font-bold text-white mt-0.5">{c.title}</h3>
                </div>
                <button
                  onClick={() => navigate(`/courses/${c.slug}`)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-cyan-400 font-semibold cursor-pointer"
                >
                  Open Course
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Completed & In-Progress Lessons */}
        <div className="space-y-6">
          <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
            <h2 className="text-lg font-bold text-white mb-4">
              Completed Lessons ({completedLessonDetails.length})
            </h2>
            {completedLessonDetails.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">
                You have not marked any lessons as completed yet.
              </p>
            ) : (
              <div className="space-y-3">
                {completedLessonDetails.map(({ lesson, courseTitle }) => (
                  <div
                    key={lesson.lessonId}
                    className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3"
                  >
                    <div>
                      <span className="text-[11px] font-mono text-emerald-400">
                        ✓ Completed · {courseTitle}
                      </span>
                      <h3 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                        {lesson.title}
                      </h3>
                    </div>
                    <button
                      onClick={() => navigate(`/learn/${lesson.lessonId}`)}
                      className="btn-interactive px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-cyan-400 font-semibold cursor-pointer shrink-0"
                    >
                      Review
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {startedLessonDetails.length > 0 && (
            <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
              <h2 className="text-lg font-bold text-white mb-4">
                Lessons Started / In Progress ({startedLessonDetails.length})
              </h2>
              <div className="space-y-3">
                {startedLessonDetails.map(({ lesson, courseTitle }) => (
                  <div
                    key={lesson.lessonId}
                    className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3"
                  >
                    <div>
                      <span className="text-[11px] font-mono text-amber-300">
                        In Progress · {courseTitle}
                      </span>
                      <h3 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                        {lesson.title}
                      </h3>
                    </div>
                    <button
                      onClick={() => navigate(`/learn/${lesson.lessonId}`)}
                      className="btn-interactive px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 text-xs font-bold cursor-pointer shrink-0"
                    >
                      Continue
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Quiz Attempts with Inline Question & Explanation Breakdown */}
        <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-4">
            Quiz Attempts ({attemptsList.length})
          </h2>
          {attemptsList.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">
              No quiz attempts recorded yet.
            </p>
          ) : (
            <div className="space-y-4">
              {attemptsList.map((att) => {
                const quiz = quizzes[att.quizId];
                const quizTitle = quiz?.title || att.quizId;
                const isExpanded = expandedAttemptId === att.attemptId;

                return (
                  <div
                    key={att.attemptId}
                    className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden"
                  >
                    <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <span className="text-xs sm:text-sm font-bold text-white block">
                          {quizTitle}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {new Date(att.timestamp).toLocaleString('en-IN')} · Score: {att.score}% (
                          {att.passed ? 'Passed' : 'Needs Review'})
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {quiz && quiz.questions.length > 0 && (
                          <button
                            onClick={() =>
                              setExpandedAttemptId(isExpanded ? null : att.attemptId)
                            }
                            className="btn-interactive px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-cyan-400 font-semibold cursor-pointer"
                          >
                            {isExpanded ? 'Hide Questions' : 'Review Questions'}
                          </button>
                        )}
                        <button
                          onClick={() => navigate(`/quiz/${att.quizId}/results/${att.attemptId}`)}
                          className="btn-interactive px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-amber-300 font-semibold cursor-pointer"
                        >
                          Full Page
                        </button>
                      </div>
                    </div>

                    {isExpanded && quiz && (
                      <div className="p-4 border-t border-slate-800 bg-slate-950/70 space-y-3">
                        {quiz.questions.map((q, idx) => {
                          const userAns = att.userAnswers[q.id];
                          const isCorrect = userAns === q.correctIndex;
                          return (
                            <div
                              key={q.id}
                              className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs space-y-1.5"
                            >
                              <div className="flex items-center justify-between font-mono">
                                <span className="text-slate-400">Question {idx + 1}</span>
                                <span
                                  className={
                                    isCorrect
                                      ? 'text-emerald-400 font-bold'
                                      : 'text-rose-400 font-bold'
                                  }
                                >
                                  {isCorrect ? 'Correct ✓' : 'Incorrect ✗'}
                                </span>
                              </div>
                              <p className="font-bold text-white">{q.question}</p>
                              <p className="text-slate-300">
                                Your Answer:{' '}
                                <strong
                                  className={
                                    isCorrect ? 'text-emerald-300' : 'text-rose-300'
                                  }
                                >
                                  {q.options[userAns] ?? 'No answer'}
                                </strong>
                              </p>
                              {!isCorrect && (
                                <p className="text-emerald-300">
                                  Correct Answer: <strong>{q.options[q.correctIndex]}</strong>
                                </p>
                              )}
                              {q.explanation && (
                                <p className="text-slate-400 pt-1 border-t border-slate-800">
                                  <strong className="text-cyan-300">Explanation: </strong>
                                  {q.explanation}
                                </p>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// 3. Lesson Viewer (/learn/:lessonId) supporting Written, PPTX Slide Decks, and Video Player with Resume
export const LessonViewPage: React.FC<{ lessonId: string; navigate: (to: string) => void }> = ({
  lessonId,
  navigate,
}) => {
  const {
    completedLessons,
    markLessonComplete,
    recordLessonVisit,
    getVideoPlaybackTime,
    saveVideoPlaybackTime,
    user,
  } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, quizzes, flashcards } = useContentStore(isAdmin);

  const [outlineOpen, setOutlineOpen] = useState(false);
  const [justCompletedToast, setJustCompletedToast] = useState(false);

  useEffect(() => {
    recordLessonVisit(lessonId);
    setJustCompletedToast(false);
  }, [lessonId]);

  let currentLesson: LessonItem | undefined;
  let parentCourse: CourseDetail | undefined;
  let lessonIndex = -1;

  for (const course of courses) {
    const idx = course.lessons.findIndex((l) => l.lessonId === lessonId);
    if (idx >= 0) {
      currentLesson = course.lessons[idx];
      parentCourse = course;
      lessonIndex = idx;
      break;
    }
  }

  if (!currentLesson || !parentCourse) {
    return (
      <div className="py-20 text-center max-w-xl mx-auto px-4 animate-fade-in">
        <h2 className="text-2xl font-bold text-white mb-2">Lesson Not Found</h2>
        <p className="text-xs text-slate-400 mb-6">
          No lesson matching ID "{lessonId}" could be located.
        </p>
        <button
          onClick={() => navigate('/dashboard')}
          className="btn-interactive px-4 py-2 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold cursor-pointer"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  const isCompleted = completedLessons.includes(currentLesson.lessonId);
  const hasLinkedFlashcards =
    currentLesson.flashcardSetId && flashcards[currentLesson.flashcardSetId];
  const hasLinkedQuiz = currentLesson.quizId && quizzes[currentLesson.quizId];

  const prevLesson = lessonIndex > 0 ? parentCourse.lessons[lessonIndex - 1] : null;
  const nextLesson =
    lessonIndex >= 0 && lessonIndex < parentCourse.lessons.length - 1
      ? parentCourse.lessons[lessonIndex + 1]
      : null;

  const handleMarkComplete = () => {
    if (!isCompleted) {
      markLessonComplete(currentLesson!.lessonId);
      setJustCompletedToast(true);
      setTimeout(() => setJustCompletedToast(false), 3000);
    }
  };

  return (
    <div className="py-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      {/* Top Breadcrumb & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-4 border-b border-slate-800">
        <button
          onClick={() => navigate(`/courses/${parentCourse!.slug}`)}
          className="btn-interactive inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Return to {parentCourse.title}</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setOutlineOpen(!outlineOpen)}
            aria-expanded={outlineOpen}
            className="btn-interactive flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 border border-slate-700 text-slate-200 cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>
              Lesson {lessonIndex + 1} of {parentCourse.lessons.length}
            </span>
            <ChevronDown
              className={`w-3.5 h-3.5 transition-transform ${outlineOpen ? 'rotate-180' : ''}`}
            />
          </button>

          {hasLinkedFlashcards && (
            <button
              onClick={() => navigate(`/flashcards/${currentLesson!.flashcardSetId}`)}
              className="btn-interactive flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 text-amber-300 border border-amber-600/30 cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Study Flashcards</span>
            </button>
          )}
          {hasLinkedQuiz && (
            <button
              onClick={() => navigate(`/quiz/${currentLesson!.quizId}`)}
              className="btn-interactive flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-cyan-950 text-cyan-300 border border-cyan-700 cursor-pointer"
            >
              <Award className="w-3.5 h-3.5" />
              <span>Take Lesson Quiz</span>
            </button>
          )}
        </div>
      </div>

      {/* Expandable Course Lesson List Drawer */}
      {outlineOpen && (
        <div className="mb-6 bg-[#0b1329] border border-slate-700 rounded-2xl p-4 animate-fade-in">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
            Course Outline: {parentCourse.title}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {parentCourse.lessons.map((l, idx) => {
              const isCurrent = l.lessonId === currentLesson!.lessonId;
              const isDone = completedLessons.includes(l.lessonId);
              return (
                <button
                  key={l.lessonId}
                  onClick={() => {
                    setOutlineOpen(false);
                    navigate(`/learn/${l.lessonId}`);
                  }}
                  className={`text-left p-2.5 rounded-xl border text-xs flex items-center justify-between cursor-pointer ${
                    isCurrent
                      ? 'bg-cyan-950/60 border-cyan-500/50 text-cyan-200 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <span className="truncate">
                    {idx + 1}. {l.title}
                  </span>
                  <span className="font-mono text-[10px] ml-2 shrink-0">
                    {isDone ? '✓ Done' : `${l.durationMinutes}m`}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-10 shadow-xl">
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-400 mb-2">
          <span className="uppercase text-cyan-400">{parentCourse.title}</span>
          <span>·</span>
          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 uppercase text-[10px]">
            {currentLesson.type === 'pptx'
              ? 'Presentation Slides'
              : currentLesson.type === 'video'
              ? 'Video Lesson'
              : 'Written Lesson'}
          </span>
          <span>·</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {currentLesson.durationMinutes} minutes
          </span>
          {currentLesson.updatedAt && (
            <>
              <span>·</span>
              <span>Updated {new Date(currentLesson.updatedAt).toLocaleDateString('en-IN')}</span>
            </>
          )}
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-white mb-4">
          {currentLesson.title}
        </h1>

        {currentLesson.summary && (
          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-cyan-200 text-xs sm:text-sm mb-8 leading-relaxed">
            <strong>What you will learn: </strong>
            {currentLesson.summary}
          </div>
        )}

        {/* 1. Video Lesson Player */}
        {currentLesson.type === 'video' && (
          <div className="mb-8">
            <VideoLessonPlayer
              lessonId={currentLesson.lessonId}
              title={currentLesson.title}
              videoUrl={currentLesson.videoUrl}
              subtitleUrl={currentLesson.subtitleUrl}
              initialTimeSeconds={getVideoPlaybackTime(currentLesson.lessonId)}
              onSaveProgressSeconds={(seconds: number) =>
                saveVideoPlaybackTime(currentLesson!.lessonId, seconds)
              }
            />
          </div>
        )}

        {/* 2. PPTX Slide Deck Viewer */}
        {currentLesson.type === 'pptx' && (
          <div className="mb-8">
            <PptxViewer
              title={currentLesson.title}
              pptxUrl={currentLesson.pptxUrl}
              pptxFileName={currentLesson.pptxFileName}
              slides={currentLesson.pptxSlides}
            />
          </div>
        )}

        {/* 3. Written Content / Lesson Notes */}
        {currentLesson.content && currentLesson.content.length > 0 && (
          <div className="space-y-8">
            {currentLesson.content.map((sec, idx) => (
              <div key={idx} className="space-y-3">
                <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-slate-800 text-cyan-400 text-xs flex items-center justify-center font-mono">
                    {idx + 1}
                  </span>
                  {sec.heading}
                </h2>
                <div className="space-y-3 text-slate-300 text-sm sm:text-base leading-relaxed">
                  {sec.paragraphs.map((p, pIdx) => (
                    <p key={pIdx}>{p}</p>
                  ))}
                </div>
                {sec.callout && (
                  <div className="mt-3 p-4 rounded-xl bg-amber-950/20 border-l-4 border-amber-400 text-amber-200 text-xs sm:text-sm">
                    <strong>Important Takeaway: </strong>
                    {sec.callout}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Completion Feedback Banner */}
        {justCompletedToast && (
          <div className="mt-8 p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-500/50 text-xs text-emerald-300 flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Lesson progress saved! Marked as completed.</span>
          </div>
        )}

        {/* Completion & Assessment Action Bar */}
        <div className="mt-10 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            onClick={handleMarkComplete}
            className={`btn-interactive flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold cursor-pointer ${
              isCompleted
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isCompleted ? 'Completed ✓' : 'Mark Lesson as Complete'}</span>
          </button>

          <div className="flex flex-wrap items-center gap-3">
            {hasLinkedFlashcards && (
              <button
                onClick={() => navigate(`/flashcards/${currentLesson!.flashcardSetId}`)}
                className="btn-interactive px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-amber-300 font-semibold cursor-pointer"
              >
                Practice Flashcards
              </button>
            )}
            {hasLinkedQuiz && (
              <button
                onClick={() => navigate(`/quiz/${currentLesson!.quizId}`)}
                className="btn-interactive flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer"
              >
                <span>Test Your Knowledge</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Previous / Next Lesson Navigation Footer */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 flex items-center justify-between gap-4">
          {prevLesson ? (
            <button
              onClick={() => navigate(`/learn/${prevLesson.lessonId}`)}
              className="btn-interactive flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4 text-cyan-400" />
              <div className="text-left">
                <span className="text-[10px] text-slate-400 block">Previous Lesson</span>
                <span className="font-bold text-white line-clamp-1">{prevLesson.title}</span>
              </div>
            </button>
          ) : (
            <div />
          )}

          {nextLesson ? (
            <button
              onClick={() => navigate(`/learn/${nextLesson.lessonId}`)}
              className="btn-interactive flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 cursor-pointer ml-auto"
            >
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">Next Lesson</span>
                <span className="font-bold text-white line-clamp-1">{nextLesson.title}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-cyan-400" />
            </button>
          ) : (
            <button
              onClick={() => navigate(`/courses/${parentCourse!.slug}`)}
              className="btn-interactive flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-cyan-300 cursor-pointer ml-auto"
            >
              <span>Finish & Return to Course</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// 4. Take Quiz (/quiz/:quizId) -> "Test Your Knowledge"
export const QuizTakePage: React.FC<{ quizId: string; navigate: (to: string) => void }> = ({
  quizId,
  navigate,
}) => {
  const { recordQuizAttempt, user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { quizzes } = useContentStore(isAdmin);
  const quiz = quizzes[quizId];

  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [error, setError] = useState<string | null>(null);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!quiz) {
    return (
      <div className="py-20 text-center max-w-xl mx-auto px-4 animate-fade-in">
        <h2 className="text-2xl font-bold text-white mb-2">No quizzes available yet.</h2>
        <p className="text-xs text-slate-400 mb-6">
          Quiz with ID "{quizId}" does not exist or has not been published.
        </p>
        <button
          onClick={() => navigate('/my-quizzes')}
          className="btn-interactive px-4 py-2 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold cursor-pointer"
        >
          Return to My Quizzes
        </button>
      </div>
    );
  }

  const handleSelect = (questionId: string, optionIdx: number) => {
    setAnswers({ ...answers, [questionId]: optionIdx });
    setError(null);
  };

  const handleRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quiz.questions.length === 0) {
      setError('This quiz has no questions yet.');
      return;
    }
    if (Object.keys(answers).length < quiz.questions.length) {
      setError('Please select an answer for every question before submitting.');
      return;
    }
    setShowConfirmSubmit(true);
  };

  const handleConfirmGrade = () => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    let correctCount = 0;
    quiz.questions.forEach((q) => {
      if (answers[q.id] === q.correctIndex) {
        correctCount++;
      }
    });

    const scorePct = Math.round((correctCount / quiz.questions.length) * 100);
    const passed = scorePct >= quiz.passingScore;
    const attemptId = 'att_' + Date.now();

    const attemptRecord: QuizAttemptRecord = {
      attemptId,
      quizId,
      score: scorePct,
      total: quiz.questions.length,
      passed,
      userAnswers: answers,
      timestamp: new Date().toISOString(),
    };

    recordQuizAttempt(attemptRecord);
    setShowConfirmSubmit(false);
    navigate(`/quiz/${quizId}/results/${attemptId}`);
  };

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins}:${rem < 10 ? '0' : ''}${rem}`;
  };

  return (
    <div className="py-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          {quiz.lessonId ? (
            <button
              onClick={() => navigate(`/learn/${quiz.lessonId}`)}
              className="btn-interactive text-xs text-cyan-400 hover:underline flex items-center gap-1 mb-2 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" /> Back to Lesson
            </button>
          ) : (
            <button
              onClick={() => navigate('/my-quizzes')}
              className="btn-interactive text-xs text-cyan-400 hover:underline flex items-center gap-1 mb-2 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" /> Back to My Quizzes
            </button>
          )}
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">{quiz.title}</h1>
          <p className="text-xs text-slate-300 mt-1">
            Passing Score Needed: <strong className="text-amber-300 font-mono">{quiz.passingScore}%</strong> ·{' '}
            {Object.keys(answers).length} of {quiz.questions.length} answered
          </p>
        </div>

        <div className="px-3.5 py-2 rounded-xl bg-[#0b1329] border border-slate-800 flex items-center gap-2 text-xs font-mono text-slate-300">
          <Clock className="w-4 h-4 text-cyan-400" />
          <span>Time: {formatTimer(elapsedSeconds)}</span>
        </div>
      </div>

      {/* Assessment Instructions Box */}
      <div className="mb-6 p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 space-y-2">
        <strong className="text-white block">Instructions & Evaluation Notice:</strong>
        <p>
          {quiz.instructions ||
            'Read each question carefully and choose the best option. Correct answers and detailed explanations will be revealed after submission for your immediate learning review.'}
        </p>
        <p className="text-[11px] text-amber-300/90 font-mono">
          Note: This assessment runs in self-study practice mode. Official certified database grading is safely disabled until trusted backend grading is deployed.
        </p>
      </div>

      {/* Question Navigation Pills */}
      {quiz.questions.length > 1 && (
        <div className="flex flex-wrap items-center gap-2 mb-6">
          <span className="text-xs text-slate-400 mr-1">Questions:</span>
          {quiz.questions.map((q, idx) => {
            const isAnswered = answers[q.id] !== undefined;
            return (
              <a
                key={q.id}
                href={`#question-${idx + 1}`}
                className={`w-7 h-7 rounded-lg text-xs font-mono font-bold flex items-center justify-center transition-colors ${
                  isAnswered
                    ? 'bg-cyan-500 text-slate-950'
                    : 'bg-slate-900 border border-slate-800 text-slate-400'
                }`}
              >
                {idx + 1}
              </a>
            );
          })}
        </div>
      )}

      {error && (
        <div className="mb-6 p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/50 text-xs text-rose-300 flex items-center gap-2 animate-fade-in">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {quiz.questions.length === 0 ? (
        <div className="p-8 text-center bg-[#0b1329] border border-slate-800 rounded-2xl">
          <p className="text-xs text-slate-400">No questions have been added to this quiz yet.</p>
        </div>
      ) : (
        <form onSubmit={handleRequestSubmit} className="space-y-6">
          {quiz.questions.map((q, qIdx) => (
            <div
              key={q.id}
              id={`question-${qIdx + 1}`}
              className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6"
            >
              <span className="text-xs font-mono text-cyan-400 block mb-2">
                Question {qIdx + 1} of {quiz.questions.length}
              </span>
              <p className="text-sm sm:text-base font-bold text-white mb-4">{q.question}</p>

              <div className="space-y-2.5">
                {q.options.map((option, optIdx) => {
                  const isSelected = answers[q.id] === optIdx;
                  return (
                    <button
                      type="button"
                      key={optIdx}
                      onClick={() => handleSelect(q.id, optIdx)}
                      className={`btn-interactive w-full text-left p-3.5 rounded-xl border text-xs sm:text-sm font-medium flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-950/80 border-cyan-400 text-cyan-100 shadow-sm'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span>{option}</span>
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ml-3 ${
                          isSelected ? 'border-cyan-400 bg-cyan-400' : 'border-slate-600'
                        }`}
                      >
                        {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          <button
            type="submit"
            disabled={isSubmitting}
            className="btn-interactive w-full py-3.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-60 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/20 cursor-pointer"
          >
            Review & Submit Answers
          </button>
        </form>
      )}

      {/* Submission Confirmation Modal */}
      {showConfirmSubmit && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="confirm-quiz-title"
        >
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 animate-modal-in">
            <h2 id="confirm-quiz-title" className="text-lg font-bold text-white">
              Submit Your Quiz Answers?
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              You have answered all {quiz.questions.length} questions. Once submitted, your score will be calculated and saved to your learning history.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmSubmit(false)}
                className="btn-interactive px-4 py-2 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 cursor-pointer"
              >
                Review Answers
              </button>
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleConfirmGrade}
                className="btn-interactive px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-xs font-bold text-slate-950 cursor-pointer"
              >
                {isSubmitting ? 'Grading...' : 'Confirm & Submit'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 5. Quiz Results (/quiz/:quizId/results/:attemptId)
export const QuizResultsPage: React.FC<{
  quizId: string;
  attemptId: string;
  navigate: (to: string) => void;
}> = ({ quizId, attemptId, navigate }) => {
  const { quizAttempts, user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { quizzes } = useContentStore(isAdmin);
  const quiz = quizzes[quizId];
  const attempt = quizAttempts[attemptId];

  if (!quiz || !attempt) {
    return (
      <div className="py-20 text-center max-w-xl mx-auto px-4 animate-fade-in">
        <h2 className="text-2xl font-bold text-white mb-2">Results Not Found</h2>
        <p className="text-xs text-slate-400 mb-6">Attempt details could not be retrieved.</p>
        <button
          onClick={() => navigate('/my-quizzes')}
          className="btn-interactive px-4 py-2 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold cursor-pointer"
        >
          Return to My Quizzes
        </button>
      </div>
    );
  }

  return (
    <div className="py-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 text-center mb-8">
        <div
          className={`w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4 ${
            attempt.passed
              ? 'bg-emerald-950 text-emerald-400 border border-emerald-600'
              : 'bg-rose-950 text-rose-400 border border-rose-600'
          }`}
        >
          <Award className="w-8 h-8" />
        </div>

        <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block mb-1">
          Your Score
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">{quiz.title}</h1>

        <div className="text-4xl font-black font-mono my-4 text-white">{attempt.score}%</div>

        <p
          className={`text-xs font-bold ${
            attempt.passed ? 'text-emerald-400' : 'text-rose-400'
          }`}
        >
          {attempt.passed
            ? 'PASSED — Great job understanding these concepts ✓'
            : 'NEEDS PRACTICE — Review the explanations below and try again'}
        </p>
        <span className="text-[11px] font-mono text-slate-500 block mt-1">
          Formative Self-Assessment · Official Server-Side Certification Disabled
        </span>

        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => navigate(`/quiz/${quizId}`)}
            className="btn-interactive flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Retake Quiz</span>
          </button>
          <button
            onClick={() => navigate('/my-quizzes')}
            className="btn-interactive px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 cursor-pointer"
          >
            My Quizzes
          </button>
          {quiz.lessonId && (
            <button
              onClick={() => navigate(`/learn/${quiz.lessonId}`)}
              className="btn-interactive px-4 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
            >
              Back to Lesson
            </button>
          )}
        </div>
      </div>

      {/* Question Review */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white mb-2">Answer Breakdown & Explanations</h2>
        {quiz.questions.map((q, idx) => {
          const userAns = attempt.userAnswers[q.id];
          const isCorrect = userAns === q.correctIndex;

          return (
            <div key={q.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-slate-400">Question {idx + 1}</span>
                <span
                  className={`text-xs font-bold ${
                    isCorrect ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isCorrect ? 'Correct ✓' : 'Incorrect ✗'}
                </span>
              </div>
              <p className="text-sm font-bold text-white mb-3">{q.question}</p>

              <div className="space-y-1.5 text-xs mb-3">
                <div
                  className={`p-2.5 rounded-lg border ${
                    isCorrect
                      ? 'bg-emerald-950/40 border-emerald-700/50 text-emerald-200'
                      : 'bg-rose-950/40 border-rose-700/50 text-rose-200'
                  }`}
                >
                  Your Answer: <strong>{q.options[userAns] ?? 'No answer selected'}</strong>
                </div>
                {!isCorrect && (
                  <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-700/50 text-emerald-300">
                    Correct Answer: <strong>{q.options[q.correctIndex]}</strong>
                  </div>
                )}
              </div>

              {q.explanation && (
                <p className="text-xs text-slate-300 leading-relaxed border-t border-slate-800/80 pt-2.5">
                  <strong className="text-cyan-300">Why this is right: </strong>
                  {q.explanation}
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// 6. Flashcard Sets (/flashcards) Grouped by Course
export const FlashcardsPage: React.FC<StudentPageProps> = ({ navigate }) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses, flashcards } = useContentStore(isAdmin);
  const sets = Object.values(flashcards);

  return (
    <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-mono text-amber-400 uppercase tracking-wider font-semibold">
            Quick Revision Cards
          </span>
          <h1 className="text-3xl font-extrabold text-white mt-1">My Flashcards</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2">
            Practice and remember key terms and concepts from your courses.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => navigate('/admin/flashcards')}
            className="btn-interactive inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md shadow-amber-400/20 cursor-pointer"
          >
            <span>Manage Flashcards</span>
          </button>
        )}
      </div>

      {sets.length === 0 ? (
        <div className="text-center py-20 bg-[#0b1329] rounded-2xl border border-slate-800 p-8 max-w-2xl mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-amber-950/50 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto mb-4">
            <Layers className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">No flashcards have been added yet.</h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-6">
            Flashcard sets created by administrators for your courses will appear here once published.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {sets.map((set) => {
            const parentCourse = courses.find((c) => c.slug === set.courseSlug);
            return (
              <div
                key={set.setId}
                onClick={() => navigate(`/flashcards/${set.setId}`)}
                className="card-interactive bg-[#0b1329] border border-slate-800 hover:border-amber-500/50 rounded-2xl p-6 cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-950/60 text-amber-400 border border-amber-800/40 flex items-center justify-center">
                      <Layers className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-mono text-cyan-400 truncate">
                      {parentCourse ? parentCourse.title : set.courseSlug || 'General'}
                    </span>
                  </div>
                  <h2 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors mb-2">
                    {set.title}
                  </h2>
                  <span className="text-xs font-mono text-slate-400">
                    {set.cards.length} Revision Cards
                  </span>
                </div>

                <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-semibold mt-4">
                  <span>Start Practice</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// 7. Study Flashcards (/flashcards/:setId) with 3D Flip & Self-Assessment
export const FlashcardStudyPage: React.FC<{ setId: string; navigate: (to: string) => void }> = ({
  setId,
  navigate,
}) => {
  const { user, flashcardAssessments, recordFlashcardAssessment } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { flashcards } = useContentStore(isAdmin);
  const set = flashcards[setId];
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  if (!set || set.cards.length === 0) {
    return (
      <div className="py-20 text-center max-w-xl mx-auto px-4 animate-fade-in">
        <h2 className="text-2xl font-bold text-white mb-2">No flashcards have been added yet.</h2>
        <p className="text-xs text-slate-400 mb-6">
          Flashcard set "{setId}" contains no cards or has not been published.
        </p>
        <button
          onClick={() => navigate('/flashcards')}
          className="btn-interactive px-4 py-2 bg-cyan-500 text-slate-950 rounded-xl text-xs font-bold cursor-pointer"
        >
          Return to My Flashcards
        </button>
      </div>
    );
  }

  const currentCard = set.cards[currentIndex];
  const knownCount = set.cards.filter((c) => flashcardAssessments[c.id] === 'know').length;
  const reviewCount = set.cards.filter((c) => flashcardAssessments[c.id] === 'review').length;

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % set.cards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + set.cards.length) % set.cards.length);
  };

  const handleAssess = (status: 'know' | 'review') => {
    recordFlashcardAssessment(currentCard.id, status);
    handleNext();
  };

  return (
    <div className="py-12 max-w-2xl mx-auto px-4 animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => navigate('/flashcards')}
          className="btn-interactive text-xs text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
        >
          <ChevronLeft className="w-3.5 h-3.5" /> Back to My Flashcards
        </button>
        <span className="text-xs font-mono text-slate-400">
          Card {currentIndex + 1} of {set.cards.length}
        </span>
      </div>

      <h1 className="text-xl font-bold text-white text-center mb-3">{set.title}</h1>

      {/* Mastery Summary Bar */}
      <div className="flex items-center justify-center gap-4 text-xs font-mono mb-6">
        <span className="text-emerald-400">Know it: {knownCount}</span>
        <span className="text-slate-600">·</span>
        <span className="text-amber-300">Review again: {reviewCount}</span>
      </div>

      {/* 3D Flippable Card Container */}
      <div
        role="button"
        tabIndex={0}
        aria-label={`Flashcard: ${isFlipped ? currentCard.back : currentCard.front}. Click or press Enter to flip.`}
        onClick={() => setIsFlipped(!isFlipped)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setIsFlipped(!isFlipped);
          } else if (e.key === 'ArrowRight') {
            handleNext();
          } else if (e.key === 'ArrowLeft') {
            handlePrev();
          }
        }}
        className="w-full h-80 perspective-1000 cursor-pointer select-none"
      >
        <div
          className={`w-full h-full relative transform-style-3d rounded-2xl ${
            isFlipped ? 'rotate-y-180' : ''
          }`}
        >
          {/* Front Face */}
          <div className="absolute inset-0 backface-hidden rounded-2xl bg-[#0b1329] border-2 border-slate-800 hover:border-amber-400/50 p-8 flex flex-col justify-between items-center text-center shadow-xl">
            <span className="text-[11px] font-mono uppercase tracking-wider text-amber-300">
              {currentCard.category} · Question / Term
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white my-auto">
              {currentCard.front}
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              Click or press Space to flip card
            </span>
          </div>

          {/* Back Face */}
          <div className="absolute inset-0 backface-hidden rotate-y-180 rounded-2xl bg-slate-900 border-2 border-amber-500/40 p-8 flex flex-col justify-between items-center text-center shadow-xl">
            <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-300">
              {currentCard.category} · Plain English Meaning
            </span>
            <p className="text-base sm:text-lg text-slate-100 leading-relaxed font-medium my-auto">
              {currentCard.back}
            </p>
            <span className="text-xs text-slate-400 font-mono">
              Rate your memory below or click to flip back
            </span>
          </div>
        </div>
      </div>

      {/* Self-Assessment Buttons ("Know it" / "Review again") */}
      <div className="grid grid-cols-2 gap-3 mt-5">
        <button
          type="button"
          onClick={() => handleAssess('review')}
          className="btn-interactive py-2.5 px-4 rounded-xl bg-amber-950/60 hover:bg-amber-900/70 border border-amber-700/60 text-amber-200 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Review Again</span>
        </button>
        <button
          type="button"
          onClick={() => handleAssess('know')}
          className="btn-interactive py-2.5 px-4 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-700/60 text-emerald-200 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Know It ✓</span>
        </button>
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-800/80">
        <button
          onClick={handlePrev}
          className="btn-interactive flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" /> Previous
        </button>

        <button
          onClick={() => setIsFlipped(!isFlipped)}
          className="btn-interactive px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold cursor-pointer"
        >
          {isFlipped ? 'Show Term' : 'Show Meaning'}
        </button>

        <button
          onClick={handleNext}
          className="btn-interactive flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700 cursor-pointer"
        >
          Next <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

// 8. Student Profile (/profile)
export const ProfilePage: React.FC<StudentPageProps> = ({ navigate }) => {
  const { user, completedLessons, startedLessons, quizAttempts, logout } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { courses } = useContentStore(isAdmin);

  const completedCoursesCount = courses.filter((c) => {
    const prog = calculateCourseProgress(c, completedLessons);
    return prog.isCompleted;
  }).length;

  return (
    <div className="py-12 max-w-3xl mx-auto px-4 animate-fade-in">
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8">
        <div className="flex items-center justify-between pb-6 border-b border-slate-800 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center font-bold text-2xl font-mono">
              {user?.name.charAt(0) || 'L'}
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">{user?.name}</h1>
              <p className="text-xs text-slate-400 font-mono">{user?.email}</p>
            </div>
          </div>

          <span className="text-xs font-mono font-bold uppercase text-cyan-300">
            Role: {user?.role || 'student'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block mb-1">Enrolled</span>
            <span className="text-2xl font-bold text-white font-mono">
              {user?.enrolledCourses?.length || 0}
            </span>
          </div>
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block mb-1">Courses Done</span>
            <span className="text-2xl font-bold text-emerald-400 font-mono">
              {completedCoursesCount}
            </span>
          </div>
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block mb-1">Lessons Done</span>
            <span className="text-2xl font-bold text-cyan-400 font-mono">
              {completedLessons.length}
            </span>
          </div>
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block mb-1">Quizzes Taken</span>
            <span className="text-2xl font-bold text-amber-300 font-mono">
              {Object.keys(quizAttempts).length}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
          <div className="flex gap-3">
            <button
              onClick={() => navigate('/settings')}
              className="btn-interactive px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 cursor-pointer"
            >
              Account Settings
            </button>
            <button
              onClick={() => navigate('/history')}
              className="btn-interactive px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-cyan-300 cursor-pointer"
            >
              Learning History
            </button>
          </div>

          <button
            onClick={() => {
              logout();
              navigate('/');
            }}
            className="btn-interactive flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-950 text-rose-300 border border-rose-800 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// 9. Account Settings (/settings) with Password Reset & Secure Account Deletion
export const SettingsPage: React.FC<StudentPageProps> = ({ navigate }) => {
  const { user, updateDisplayName, sendPasswordReset, deleteAccount } = useAuth();
  const [displayName, setDisplayName] = useState(user?.name || '');
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [resetSending, setResetSending] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setStatusMsg(null);
    const res = await updateDisplayName(displayName);
    setSaving(false);
    if (res.success) {
      setStatusMsg({ type: 'success', text: 'Display name updated and saved ✓' });
    } else {
      setStatusMsg({ type: 'error', text: res.error || 'Could not update profile.' });
    }
  };

  const handleSendPasswordReset = async () => {
    if (!user?.email || resetSending) return;
    setResetSending(true);
    setStatusMsg(null);
    const res = await sendPasswordReset(user.email);
    setResetSending(false);
    if (res.success) {
      setStatusMsg({
        type: 'success',
        text: `Password reset instructions sent to ${user.email}.`,
      });
    } else {
      setStatusMsg({
        type: 'error',
        text: res.error || 'Could not send password reset email.',
      });
    }
  };

  const handleConfirmDeleteAccount = async () => {
    if (deleteConfirmText !== 'DELETE' || isDeleting) return;
    setIsDeleting(true);
    const res = await deleteAccount();
    setIsDeleting(false);
    if (res.success) {
      setShowDeleteModal(false);
      navigate('/');
    } else {
      setStatusMsg({
        type: 'error',
        text: res.error || 'Could not delete account.',
      });
      setShowDeleteModal(false);
    }
  };

  return (
    <div className="py-12 max-w-2xl mx-auto px-4 space-y-8 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-white">Account Settings</h1>
        <button
          onClick={() => navigate('/profile')}
          className="text-xs text-cyan-400 hover:underline cursor-pointer"
        >
          Back to Profile
        </button>
      </div>

      {statusMsg && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 animate-fade-in ${
            statusMsg.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
              : 'bg-rose-950/40 border-rose-500/50 text-rose-300'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Profile Information */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
        <h2 className="text-base font-bold text-white">Profile Details</h2>
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label htmlFor="settings-display-name" className="block text-xs font-semibold text-slate-300 mb-1">
              Display Name
            </label>
            <input
              id="settings-display-name"
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label htmlFor="settings-email" className="block text-xs font-semibold text-slate-300 mb-1">
              Registered Email Address
            </label>
            <input
              id="settings-email"
              type="email"
              disabled
              value={user?.email || ''}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-500 cursor-not-allowed font-mono"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Account role: {user?.role} (Assigned automatically by server)
            </span>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="btn-interactive px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-60 text-slate-950 font-bold text-xs cursor-pointer"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      </div>

      {/* Password & Security */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
        <h2 className="text-base font-bold text-white">Password & Security</h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          If you sign in with an email and password, you can send a password reset link to your registered email address.
        </p>
        <button
          type="button"
          disabled={resetSending}
          onClick={handleSendPasswordReset}
          className="btn-interactive inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 cursor-pointer"
        >
          <KeyRound className="w-4 h-4 text-cyan-400" />
          <span>{resetSending ? 'Sending Email...' : 'Send Password Reset Email'}</span>
        </button>
      </div>

      {/* Data Privacy & Account Deletion */}
      <div className="bg-[#0b1329] border border-rose-900/40 rounded-2xl p-6 sm:p-8 space-y-4">
        <h2 className="text-base font-bold text-white">Privacy & Account Deletion</h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          Deleting your account permanently removes your student profile, course enrolments, and completed lesson history.
        </p>
        <button
          type="button"
          onClick={() => {
            setDeleteConfirmText('');
            setShowDeleteModal(true);
          }}
          className="btn-interactive inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-950/70 hover:bg-rose-900 text-xs font-bold text-rose-200 border border-rose-800 cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span>Delete My Account</span>
        </button>
      </div>

      {/* Account Deletion Confirmation Dialog */}
      {showDeleteModal && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-account-title"
        >
          <div className="bg-[#0b1329] border border-rose-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 animate-modal-in">
            <div className="flex items-center gap-2 text-rose-400">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h2 id="delete-account-title" className="text-lg font-bold text-white">
                Permanently Delete Account?
              </h2>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              This action cannot be undone. All of your enrolled courses, lesson completions, and quiz records will be permanently erased.
            </p>
            <div>
              <label htmlFor="confirm-delete-input" className="block text-xs text-slate-400 mb-1.5">
                Type <strong className="text-rose-300 font-mono">DELETE</strong> below to confirm:
              </label>
              <input
                id="confirm-delete-input"
                type="text"
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                placeholder="DELETE"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-rose-500"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="btn-interactive px-4 py-2 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deleteConfirmText !== 'DELETE' || isDeleting}
                onClick={handleConfirmDeleteAccount}
                className="btn-interactive px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-xs font-bold text-white cursor-pointer"
              >
                {isDeleting ? 'Deleting...' : 'Permanently Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
